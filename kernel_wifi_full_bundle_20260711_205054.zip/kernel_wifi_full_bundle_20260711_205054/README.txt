Kernel / Wi-Fi diagnostic bundle
Timestamp: 20260711_205054
Mode: lite

This bundle may contain device identifiers, firmware names, boot image hashes,
and kernel/runtime details. Review before publishing publicly.
