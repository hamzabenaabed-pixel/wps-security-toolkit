// Module definitions with Arabic translations
export const MODULE_INFO: Record<string, {
  name: string; icon: string; desc: string; details: string; command: string; warning?: string;
}> = {
  "net.recon": { name: "التعرف على الأجهزة", icon: "🔍", desc: "اكتشاف الأجهزة المتصلة", details: "يمسح الشبكة المحلية ويكتشف جميع الأجهزة باستخدام ARP. سلبي وآمن نسبياً.", command: "net.recon on/off" },
  "net.probe": { name: "مستكشف الشبكة", icon: "📡", desc: "إرسال حزم استكشاف نشط", details: "يرسل UDP + mDNS + NBNS لاكتشاف أجهزة مخفية. أكثر عدوانية ويمكن كشفه.", command: "net.probe on/off", warning: "قد يُكشف من أنظمة IDS" },
  "net.sniff": { name: "المتنصت", icon: "👂", desc: "التقاط حركة المرور", details: "يلتقط جميع حزم الشبكة ويحللها. يمكنه استخراج HTTP + DNS + كلمات مرور.", command: "net.sniff on/off" },
  "arp.spoof": { name: "خداع ARP", icon: "🎭", desc: "هجوم الرجل في المنتصف", details: "يخدع الأجهزة لإرسال حركتها عبرك. أساس معظم هجمات MITM.", command: "arp.spoof on/off", warning: "⚠️ يتطلب IP Forwarding" },
  "http.proxy": { name: "بروكسي HTTP", icon: "🌐", desc: "اعتراض وتعديل HTTP", details: "يعترض طلبات HTTP ويمكنه حقن JavaScript أو تجريد SSL أو تعديل المحتوى.", command: "http.proxy on/off" },
  "https.proxy": { name: "بروكسي HTTPS", icon: "🔒", desc: "اعتراض HTTPS المشفر", details: "يعترض HTTPS. يتطلب تثبيت شهادة CA على الجهاز المستهدف.", command: "https.proxy on/off", warning: "⚠️ يتطلب شهادة CA" },
  "dns.spoof": { name: "تزييف DNS", icon: "📛", desc: "توجيه لعناوين مزيفة", details: "يستجيب لطلبات DNS بعناوين مزيفة لإعادة توجيه الضحية لصفحات تصيد.", command: "dns.spoof on/off" },
  "dhcp6.spoof": { name: "خداع DHCPv6", icon: "📶", desc: "خداع IPv6 DHCP", details: "يستغل DHCPv6 لتوجيه حركة IPv6 عبرك. فعال ضد Windows.", command: "dhcp6.spoof on/off" },
  "wifi.recon": { name: "مسح الواي فاي", icon: "📻", desc: "اكتشاف شبكات WiFi", details: "يمسح نقاط الوصول والعملاء. يتطلب واجهة في Monitor Mode.", command: "wifi.recon on/off", warning: "⚠️ يتطلب Monitor Mode" },
  "wifi.deauth": { name: "فصل الواي فاي", icon: "⚡", desc: "قطع اتصال الأجهزة", details: "يرسل Deauthentication frames لفصل الأجهزة من WiFi.", command: "wifi.deauth <MAC>", warning: "⚠️ غير قانوني في معظم الدول" },
  "ble.recon": { name: "مسح البلوتوث", icon: "🦷", desc: "اكتشاف BLE", details: "يمسح أجهزة Bluetooth Low Energy القريبة (ساعات، سماعات، trackers).", command: "ble.recon on/off" },
  "syn.scan": { name: "فحص المنافذ", icon: "🔌", desc: "فحص TCP SYN", details: "يكتشف المنافذ المفتوحة على الأجهزة. أسرع وأخفى من TCP Connect.", command: "syn.scan <IP> <PORTS>" },
  "tcp.proxy": { name: "بروكسي TCP", icon: "🔀", desc: "توجيه اتصالات TCP", details: "يعيد توجيه اتصالات TCP لخادم آخر.", command: "tcp.proxy on/off" },
  "mac.changer": { name: "تغيير MAC", icon: "🎲", desc: "إخفاء الهوية", details: "يغير عنوان MAC لواجهتك لتجنب التتبع والكشف.", command: "mac.changer on/off" },
  "ticker": { name: "التحديث التلقائي", icon: "⏱️", desc: "أوامر دورية", details: "ينفذ أوامر بشكل دوري. مفيد لتشغيل net.show كل ثانية.", command: "ticker on/off" },
};

// JS Injection Payloads
export const JS_PAYLOADS: Record<string, { name: string; icon: string; desc: string; danger: number }> = {
  keylogger: { name: "مسجل المفاتيح", icon: "⌨️", desc: "يسجل كل ضغطة مفتاح ويرسلها", danger: 3 },
  cookie_stealer: { name: "سارق الكوكيز", icon: "🍪", desc: "يسرق جلسات التصفح", danger: 3 },
  fake_login: { name: "تسجيل دخول مزيف", icon: "🔐", desc: "يعرض نافذة تسجيل دخول مزيفة", danger: 2 },
  redirect: { name: "إعادة توجيه", icon: "↪️", desc: "يوجه الضحية لصفحة أخرى", danger: 1 },
  beef_hook: { name: "BeEF Hook", icon: "🪝", desc: "يربط المتصفح بـ BeEF Framework", danger: 3 },
  screenshot: { name: "لقطة شاشة", icon: "📸", desc: "يحاول التقاط شاشة المتصفح", danger: 2 },
};

// Attack Playbooks
export const PLAYBOOKS: Array<{
  id: string; name: string; icon: string; desc: string; danger: number; steps: string[];
}> = [
  {
    id: "credential_harvest", name: "حصد كلمات المرور", icon: "🔑", desc: "ARP Spoof + Sniffer + SSL Strip لالتقاط كل كلمات المرور", danger: 3,
    steps: ["set arp.spoof.targets", "set arp.spoof.fullduplex true", "set net.sniff.regexp (credentials)", "set http.proxy.sslstrip true", "arp.spoof on", "net.sniff on", "http.proxy on"],
  },
  {
    id: "full_mitm", name: "MITM الكامل", icon: "🎭", desc: "سلسلة هجوم كاملة: ARP + HTTP Proxy + Sniff", danger: 3,
    steps: ["set arp.spoof.fullduplex true", "set http.proxy.sslstrip true", "net.recon on", "net.probe on", "arp.spoof on", "net.sniff on", "http.proxy on"],
  },
  {
    id: "stealth", name: "وضع الشبح", icon: "👻", desc: "استطلاع سلبي + تغيير MAC لتجنب الكشف", danger: 1,
    steps: ["mac.changer on", "set net.sniff.local false", "net.recon on (passive only)"],
  },
  {
    id: "dns_hijack", name: "اختطاف DNS", icon: "📛", desc: "توجيه مواقع معينة لصفحات مزيفة", danger: 3,
    steps: ["set arp.spoof.targets", "set dns.spoof.domains", "set dns.spoof.address", "arp.spoof on", "dns.spoof on"],
  },
  {
    id: "full_interception", name: "الاعتراض الشامل", icon: "🕸️", desc: "كل شيء: ARP + HTTP + DNS + Sniff معاً", danger: 3,
    steps: ["set arp.spoof.fullduplex true", "set http.proxy.sslstrip true", "set dns.spoof.all true", "arp.spoof on", "net.sniff on", "http.proxy on", "dns.spoof on"],
  },
];

// Command Reference
export const CMD_REFERENCE = [
  { cat: "الشبكة والاستطلاع", icon: "🔍", cmds: [
    { cmd: "net.probe on", desc: "بدء استكشاف نشط" }, { cmd: "net.recon on", desc: "التعرف على الأجهزة" },
    { cmd: "net.show", desc: "عرض الأجهزة المكتشفة" }, { cmd: "ticker on", desc: "تفعيل التحديث الدوري" },
    { cmd: "set ticker.commands net.show", desc: "تحديد أوامر التحديث" }, { cmd: "set ticker.period 1", desc: "فترة التحديث بالثواني" },
  ]},
  { cat: "هجوم ARP / MITM", icon: "🎭", cmds: [
    { cmd: "set arp.spoof.targets <IP>", desc: "تحديد أهداف الهجوم" },
    { cmd: "set arp.spoof.fullduplex true", desc: "الوضع المزدوج الكامل" },
    { cmd: "set arp.spoof.internal true", desc: "السماح بالتجسس الداخلي" },
    { cmd: "arp.spoof on", desc: "بدء خداع ARP" }, { cmd: "arp.spoof off", desc: "إيقاف خداع ARP" },
  ]},
  { cat: "بروكسي HTTP", icon: "🌐", cmds: [
    { cmd: "http.proxy on", desc: "تشغيل البروكسي" },
    { cmd: "set http.proxy.sslstrip true", desc: "تفعيل تجريد SSL" },
    { cmd: "set http.proxy.injectjs <URL>", desc: "حقن JavaScript" },
    { cmd: "set http.proxy.port 8080", desc: "تغيير منفذ البروكسي" },
    { cmd: "http.proxy off", desc: "إيقاف البروكسي" },
  ]},
  { cat: "تزييف DNS", icon: "📛", cmds: [
    { cmd: "set dns.spoof.address <IP>", desc: "عنوان إعادة التوجيه" },
    { cmd: "set dns.spoof.domains *", desc: "جميع النطاقات" },
    { cmd: "set dns.spoof.domains facebook.com,google.com", desc: "نطاقات محددة" },
    { cmd: "set dns.spoof.all true", desc: "الرد على كل طلب" },
    { cmd: "dns.spoof on", desc: "بدء التزييف" },
  ]},
  { cat: "المتنصت (Sniffer)", icon: "👂", cmds: [
    { cmd: "net.sniff on", desc: "بدء التنصت" },
    { cmd: "set net.sniff.verbose true", desc: "تفاصيل كاملة" },
    { cmd: "set net.sniff.local true", desc: "تضمين الحركة المحلية" },
    { cmd: "set net.sniff.filter tcp port 80", desc: "فلتر HTTP فقط" },
    { cmd: "set net.sniff.filter udp port 53", desc: "فلتر DNS فقط" },
    { cmd: "set net.sniff.filter host 192.168.1.100", desc: "فلتر جهاز معين" },
    { cmd: "set net.sniff.regexp (?i)(pass|user|login)", desc: "فلتر كلمات مرور" },
  ]},
  { cat: "WiFi", icon: "📻", cmds: [
    { cmd: "wifi.recon on", desc: "بدء مسح WiFi" }, { cmd: "wifi.show", desc: "عرض الشبكات" },
    { cmd: "wifi.deauth <MAC>", desc: "فصل جهاز" },
    { cmd: "set wifi.recon.channel 6", desc: "تحديد القناة" },
  ]},
  { cat: "أوامر متقدمة", icon: "⚡", cmds: [
    { cmd: "events.clear", desc: "مسح الأحداث" }, { cmd: "get *", desc: "عرض كل الإعدادات" },
    { cmd: "set <param> <value>", desc: "تغيير إعداد" }, { cmd: "! <shell>", desc: "تنفيذ أمر shell" },
    { cmd: "help", desc: "عرض المساعدة" }, { cmd: "caplets.show", desc: "عرض Caplets المتاحة" },
  ]},
];
