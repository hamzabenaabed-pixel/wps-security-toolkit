import { pgTable, serial, text, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";

// خزنة كلمات المرور - Loot Vault
export const loot = pgTable("loot", {
  id: serial("id").primaryKey(),
  victimIp: text("victim_ip").notNull(),
  victimMac: text("victim_mac"),
  website: text("website"),
  url: text("url"),
  username: text("username"),
  password: text("password"),
  protocol: text("protocol"), // http, ftp, smtp, etc.
  rawData: text("raw_data"),
  capturedAt: timestamp("captured_at").defaultNow().notNull(),
});

// بصمات الأجهزة - Device Fingerprinting
export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  macAddress: text("mac_address").notNull().unique(),
  hostname: text("hostname"),
  vendor: text("vendor"),
  osGuess: text("os_guess"),
  openPorts: text("open_ports"),
  sentBytes: integer("sent_bytes").default(0),
  recvBytes: integer("recv_bytes").default(0),
  isTarget: boolean("is_target").default(false),
  firstSeen: timestamp("first_seen").defaultNow().notNull(),
  lastSeen: timestamp("last_seen").defaultNow().notNull(),
});

// الأحداث المحفوظة - Saved Events
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  tag: text("tag"),
  sourceIp: text("source_ip"),
  destIp: text("dest_ip"),
  data: jsonb("data"),
  rawData: text("raw_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// سيناريوهات الهجوم المحفوظة - Attack Playbooks
export const playbooks = pgTable("playbooks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  commands: jsonb("commands").notNull(), // array of commands
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// قواعد DNS المحفوظة - DNS Rules
export const dnsRules = pgTable("dns_rules", {
  id: serial("id").primaryKey(),
  domain: text("domain").notNull(),
  redirectIp: text("redirect_ip").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// إعدادات الجلسة - Session Config
export const config = pgTable("config", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
