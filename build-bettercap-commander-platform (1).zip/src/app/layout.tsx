import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bettercap Commander",
  description: "واجهة تحكم احترافية لـ Bettercap - للاختبار المصرح به فقط",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#0a0e1a] text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
