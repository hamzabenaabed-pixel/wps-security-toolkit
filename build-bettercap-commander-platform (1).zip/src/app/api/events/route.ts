import { NextResponse } from "next/server";
import { getEvents } from "@/lib/bettercap";

interface BettercapEvent {
  tag: string;
  time: string;
  data: Record<string, unknown>;
}

interface BettercapEvents {
  events?: BettercapEvent[];
}

export async function GET() {
  try {
    const result = getEvents();

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to get events" },
        { status: 500 }
      );
    }

    const eventsData = result.data as BettercapEvents;
    const events = (eventsData.events || []).slice(0, 100).map((event) => {
      // Determine event type for UI styling
      let eventType = "info";
      if (event.tag.includes("http")) eventType = "http";
      else if (event.tag.includes("dns")) eventType = "dns";
      else if (event.tag.includes("cred") || event.tag.includes("password")) eventType = "cred";
      else if (event.tag.includes("endpoint") || event.tag.includes("host")) eventType = "host";

      return {
        type: eventType,
        tag: event.tag,
        time: event.time,
        data: event.data,
      };
    });

    return NextResponse.json({ events });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
