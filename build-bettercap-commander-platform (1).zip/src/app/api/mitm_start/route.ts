import { NextRequest, NextResponse } from "next/server";
import { playbookFullMitm } from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const targets = (body.targets as string[]) || [];
    const result = playbookFullMitm(targets);
    return NextResponse.json({ success: result.success, message: "MITM attack started", targets });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 });
  }
}
