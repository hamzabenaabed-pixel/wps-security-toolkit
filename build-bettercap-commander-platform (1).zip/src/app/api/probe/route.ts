import { NextResponse } from "next/server";
import { startRecon } from "@/lib/bettercap";

export async function POST() {
  try {
    const result = startRecon();

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to start reconnaissance" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Network reconnaissance started",
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
