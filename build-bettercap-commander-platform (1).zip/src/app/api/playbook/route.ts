import { NextRequest, NextResponse } from "next/server";
import {
  playbookCredentialHarvest,
  playbookFullMitm,
  playbookStealth,
  playbookDnsHijack,
  playbookFullInterception,
} from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { playbook, targets, domain, redirectIp } = body as {
      playbook: string;
      targets?: string[];
      domain?: string;
      redirectIp?: string;
    };
    const t = targets || [];

    switch (playbook) {
      case "credential_harvest":
        return NextResponse.json(playbookCredentialHarvest(t));
      case "full_mitm":
        return NextResponse.json(playbookFullMitm(t));
      case "stealth":
        return NextResponse.json(playbookStealth());
      case "dns_hijack":
        return NextResponse.json(playbookDnsHijack(t, domain || "*", redirectIp || "127.0.0.1"));
      case "full_interception":
        return NextResponse.json(playbookFullInterception(t));
      default:
        return NextResponse.json({ error: "Unknown playbook" }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Error" }, { status: 500 });
  }
}
