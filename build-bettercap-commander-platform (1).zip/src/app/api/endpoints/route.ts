import { NextResponse } from "next/server";
import { getSession } from "@/lib/bettercap";

interface LanHost {
  ipv4: string;
  mac: string;
  hostname?: string;
  vendor?: string;
  meta?: { sent?: number; recv?: number };
}

interface BettercapSession {
  lan?: { hosts?: LanHost[] };
}

export async function GET() {
  try {
    const result = getSession();

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to get endpoints" },
        { status: 500 }
      );
    }

    const session = result.data as BettercapSession;
    const hosts = session.lan?.hosts || [];

    const endpoints = hosts.map((host) => ({
      ip: host.ipv4,
      mac: host.mac,
      hostname: host.hostname || "",
      vendor: host.vendor || "Unknown",
      sent: host.meta?.sent || 0,
      recv: host.meta?.recv || 0,
    }));

    return NextResponse.json({ endpoints });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
