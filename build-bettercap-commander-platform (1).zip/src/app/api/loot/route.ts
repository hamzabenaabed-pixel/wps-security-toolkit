import { NextResponse } from "next/server";
import { getLoot } from "@/lib/bettercap";

export async function GET() {
  try {
    const result = getLoot();
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Error" }, { status: 500 });
  }
}
