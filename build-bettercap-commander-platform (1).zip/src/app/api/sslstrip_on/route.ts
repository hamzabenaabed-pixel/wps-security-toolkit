import { NextResponse } from "next/server";
import { sendCommand } from "@/lib/bettercap";

export async function POST() {
  try {
    sendCommand("set http.proxy.sslstrip true");
    sendCommand("http.proxy on");
    return NextResponse.json({ success: true, message: "SSL stripping enabled" });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 });
  }
}
