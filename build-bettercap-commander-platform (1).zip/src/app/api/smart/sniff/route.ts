import { NextRequest, NextResponse } from "next/server";
import { smartSniffFilter } from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const result = smartSniffFilter(body);
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Error" }, { status: 500 });
  }
}
