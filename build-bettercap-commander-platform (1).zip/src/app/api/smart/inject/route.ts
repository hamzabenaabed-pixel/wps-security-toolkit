import { NextRequest, NextResponse } from "next/server";
import { smartInjectJs } from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { payload, customUrl } = body as { payload: string; customUrl?: string };
    const result = smartInjectJs(payload, customUrl);
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Error" }, { status: 500 });
  }
}
