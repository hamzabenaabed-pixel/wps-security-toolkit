import { NextRequest, NextResponse } from "next/server";
import { smartDnsSpoof } from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { rules } = body as { rules: Array<{ domain: string; ip: string }> };
    const result = smartDnsSpoof(rules);
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Error" }, { status: 500 });
  }
}
