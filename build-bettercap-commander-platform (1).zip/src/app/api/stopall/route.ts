import { NextResponse } from "next/server";
import { stopAll } from "@/lib/bettercap";

export async function POST() {
  try {
    const result = stopAll();

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to stop modules" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "All modules stopped",
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
