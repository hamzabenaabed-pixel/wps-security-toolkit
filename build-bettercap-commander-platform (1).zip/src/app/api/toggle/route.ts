import { NextRequest, NextResponse } from "next/server";
import { toggleModule } from "@/lib/bettercap";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { module, state } = body;

    if (!module || typeof state !== "boolean") {
      return NextResponse.json(
        { error: "Missing module name or state" },
        { status: 400 }
      );
    }

    const result = toggleModule(module, state);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to toggle module" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      module,
      state,
      message: `${module} ${state ? "enabled" : "disabled"}`,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
