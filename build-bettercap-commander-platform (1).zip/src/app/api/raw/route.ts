import { NextRequest, NextResponse } from "next/server";
import { sendCommand } from "@/lib/bettercap";

interface CommandResult {
  output?: string;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { command } = body;

    if (!command || typeof command !== "string") {
      return NextResponse.json(
        { error: "Missing command" },
        { status: 400 }
      );
    }

    const result = sendCommand(command);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to execute command" },
        { status: 500 }
      );
    }

    const output = (result.data as CommandResult)?.output || JSON.stringify(result.data);

    return NextResponse.json({
      success: true,
      command,
      output,
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
