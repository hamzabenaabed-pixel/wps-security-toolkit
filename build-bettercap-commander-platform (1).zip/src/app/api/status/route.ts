import { NextResponse } from "next/server";
import { getSession, getEvents } from "@/lib/bettercap";

interface BettercapModule {
  name: string;
  running: boolean;
  description?: string;
}

interface LanHost {
  ipv4: string;
  mac: string;
  hostname?: string;
  vendor?: string;
  meta?: { sent?: number; recv?: number };
}

interface BettercapSession {
  interface?: { name?: string; ipv4?: string; mac?: string };
  gateway?: { ipv4?: string; mac?: string };
  lan?: { hosts?: LanHost[] };
  modules?: BettercapModule[];
  started_at?: string;
}

interface BettercapEvents {
  events?: Array<{ tag: string; time: string; data: Record<string, unknown> }>;
}

export async function GET() {
  try {
    const sessionResult = getSession();
    const eventsResult = getEvents();

    if (!sessionResult.success) {
      return NextResponse.json(
        {
          alive: false,
          error: sessionResult.error || "Failed to connect to Bettercap",
          my_ip: null,
          gateway: null,
          modules: {},
          endpoints_count: 0,
          events_count: 0,
        },
        { status: 200 }
      );
    }

    const session = sessionResult.data as BettercapSession;
    const eventsData = (eventsResult.data as BettercapEvents) || { events: [] };

    // Parse modules - handle both array and object formats
    const modulesMap: Record<string, boolean> = {};
    if (Array.isArray(session.modules)) {
      for (const mod of session.modules) {
        modulesMap[mod.name] = mod.running;
      }
    } else if (session.modules && typeof session.modules === "object") {
      const mods = session.modules as Record<string, BettercapModule>;
      for (const key of Object.keys(mods)) {
        modulesMap[key] = mods[key].running;
      }
    }

    // Count endpoints
    const endpointsCount = session.lan?.hosts?.length || 0;
    const eventsCount = eventsData.events?.length || 0;

    // Calculate uptime
    let uptime = 0;
    if (session.started_at) {
      uptime = Math.floor((Date.now() - new Date(session.started_at).getTime()) / 1000);
    }

    return NextResponse.json({
      alive: true,
      my_ip: session.interface?.ipv4 || null,
      my_mac: session.interface?.mac || null,
      interface_name: session.interface?.name || null,
      gateway: session.gateway?.ipv4 || null,
      gateway_mac: session.gateway?.mac || null,
      modules: modulesMap,
      endpoints_count: endpointsCount,
      events_count: eventsCount,
      uptime: uptime,
    });
  } catch (error) {
    return NextResponse.json(
      {
        alive: false,
        error: error instanceof Error ? error.message : "Unknown error",
        my_ip: null,
        gateway: null,
        modules: {},
        endpoints_count: 0,
        events_count: 0,
      },
      { status: 200 }
    );
  }
}
