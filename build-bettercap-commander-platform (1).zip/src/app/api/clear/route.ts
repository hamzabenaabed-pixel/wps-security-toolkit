import { NextResponse } from "next/server";
import { clearEvents } from "@/lib/bettercap";

export async function POST() {
  try {
    const result = clearEvents();

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to clear events" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Events cleared",
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}
