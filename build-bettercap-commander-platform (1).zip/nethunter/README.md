# 🔥 Bettercap Commander - NetHunter Edition

واجهة تحكم احترافية لـ Bettercap مصممة خصيصاً لأجهزة Kali NetHunter.

## المتطلبات

- Kali NetHunter (Android)
- جهاز مروّت (Rooted)
- Bettercap مثبت (`apt install bettercap`)
- Python 3

## التثبيت

### 1. نسخ الملفات إلى NetHunter

```bash
# من Termux أو NetHunter Terminal
cd /sdcard
mkdir bettercap-commander
cd bettercap-commander

# انسخ main.py هنا
```

### 2. الدخول إلى Kali chroot

```bash
sudo nethunter
# أو
sudo nethunter -r
```

### 3. تشغيل السكريبت

```bash
cd /sdcard/bettercap-commander
sudo python3 main.py
```

## الاستخدام

```
🔍 اكتشاف الشبكة...

الواجهات المتاحة:
  [1] 📶 wlan0           IP: 192.168.1.37
  [2] 📶 wlan1           IP: غير متصل
  [3] 📱 rmnet_data0     IP: 10.0.0.1

اختر رقم الواجهة: 1

  الواجهة: wlan0
  عنواني:  192.168.1.37
  الراوتر: 192.168.1.1

هل الإعدادات صحيحة؟ [y/n]: y

منفذ المتصفح [8989]: 

[*] تشغيل Bettercap على wlan0...
  ✅ Bettercap متصل بنجاح!

╔═══════════════════════════════════════════════════════════╗
║  🌐 افتح المتصفح:                                        ║
║  http://127.0.0.1:8989                                    ║
║  http://192.168.1.37:8989                                 ║
╚═══════════════════════════════════════════════════════════╝
```

ثم افتح متصفح Chrome على هاتفك وادخل العنوان.

## المميزات

### الرئيسية (Dashboard)
- عرض حالة الاتصال
- عنوان IP والراوتر
- عدد الأجهزة المكتشفة
- أزرار الإجراءات السريعة

### الشبكة (Network Map)
- جدول الأجهزة المكتشفة
- تحديد الأهداف للهجوم
- عرض MAC و Vendor

### الأدوات (Modules)
- جميع وحدات Bettercap
- تشغيل/إيقاف بلمسة واحدة
- 15 وحدة مدعومة

### البث المباشر (Live Feed)
- الأحداث في الوقت الفعلي
- HTTP / DNS / Credentials
- تصدير JSON

### الأوامر (Console)
- إدخال أوامر مباشرة
- أزرار سريعة
- عرض المخرجات

### الدليل (Reference)
- مرجع الأوامر
- تنفيذ بلمسة واحدة

## حل المشاكل

### "Connection Refused"
```bash
# تأكد أن Bettercap يعمل
curl -u admin:admin http://127.0.0.1:8025/api/session
```

### "Permission denied"
```bash
# شغّل بصلاحيات root
sudo python3 main.py
```

### الواجهة لا تعمل
```bash
# تحقق من اللوج
cat bettercap.log
```

## الأمان

⚠️ **تحذير مهم:**
- استخدم فقط على الشبكات التي تملكها
- للاختبار المصرح به فقط
- أنت مسؤول قانونياً عن أفعالك

## المعلومات التقنية

- يستخدم `curl` عبر `subprocess` بدلاً من `urllib`
- يتجاوز مشاكل Android Proxy
- يعمل بالكامل بدون إنترنت (Offline)
- لا يحتاج أي تبعيات خارجية
