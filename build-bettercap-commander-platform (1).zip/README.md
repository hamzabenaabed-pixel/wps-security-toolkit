# 🔥 Bettercap Commander

واجهة تحكم احترافية لـ Bettercap - مصممة للاختبار الأمني المصرح به فقط.

## المميزات

- 📱 واجهة عربية RTL مُحسَّنة للهواتف
- 🌙 ثيم داكن احترافي
- 🔍 استكشاف الشبكة والأجهزة
- 🎭 هجمات MITM و ARP Spoofing
- 🔓 SSL Stripping
- 📡 مراقبة الأحداث المباشرة
- 💻 محطة أوامر تفاعلية
- 📚 دليل الأوامر المرجعي

## المتطلبات

- Node.js 18+
- Bettercap v2.x
- صلاحيات Root (للشبكة)

## التثبيت والتشغيل

### 1. تثبيت الاعتماديات

```bash
npm install
```

### 2. إعداد المتغيرات البيئية

أنشئ ملف `.env.local`:

```env
# Bettercap API settings
BETTERCAP_HOST=127.0.0.1
BETTERCAP_PORT=8025
BETTERCAP_USER=admin
BETTERCAP_PASS=admin

# Set to 'false' to connect to real Bettercap
DEMO_MODE=true
```

### 3. تشغيل Bettercap (على جهاز NetHunter)

```bash
sudo bettercap -iface wlan0 -eval "set api.rest.username admin; set api.rest.password admin; set api.rest.address 0.0.0.0; set api.rest.port 8025; api.rest on"
```

### 4. تشغيل الواجهة

```bash
npm run dev
```

ثم افتح المتصفح على: `http://localhost:3000`

## الوضع التجريبي (Demo Mode)

افتراضياً، التطبيق يعمل في الوضع التجريبي الذي يُظهر بيانات وهمية للتجربة.
لتعطيل الوضع التجريبي والاتصال بـ Bettercap الحقيقي:

```env
DEMO_MODE=false
```

## هيكل المشروع

```
src/
├── app/
│   ├── api/           # API routes
│   │   ├── status/    # حالة الاتصال
│   │   ├── endpoints/ # الأجهزة المكتشفة
│   │   ├── events/    # الأحداث
│   │   ├── toggle/    # تبديل الوحدات
│   │   ├── probe/     # بدء الاستكشاف
│   │   ├── stopall/   # إيقاف الكل
│   │   ├── mitm_start/# بدء MITM
│   │   ├── sslstrip_on/# تفعيل SSL Strip
│   │   ├── raw/       # أمر مباشر
│   │   └── clear/     # مسح الأحداث
│   ├── page.tsx       # الصفحة الرئيسية
│   ├── layout.tsx     # Layout RTL
│   └── globals.css    # الأنماط
├── lib/
│   └── bettercap.ts   # مكتبة الاتصال بـ Bettercap
└── db/
    └── schema.ts      # مخطط قاعدة البيانات
```

## التبويبات

1. **الرئيسية** - لوحة المعلومات والإجراءات السريعة
2. **الشبكة** - خريطة الأجهزة واختيار الأهداف
3. **الأدوات** - جميع وحدات Bettercap مع مفاتيح التبديل
4. **البث** - مراقبة الأحداث المباشرة
5. **الأوامر** - محطة أوامر تفاعلية
6. **الدليل** - مرجع الأوامر

## التحذيرات

⚠️ **للاختبار المصرح به فقط**

- استخدم هذه الأداة فقط على الشبكات التي تملكها أو لديك إذن باختبارها
- أنت مسؤول قانونياً عن أي استخدام غير مصرح به
- تأكد من فهمك للقوانين المحلية المتعلقة باختبار الشبكات

## الترخيص

للاستخدام التعليمي والاختبار الأمني المصرح به فقط.
