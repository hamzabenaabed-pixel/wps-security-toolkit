"use client";
import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "destructive" | "outline" | "ghost" | "link" | "success";
  size?: "sm" | "md" | "lg" | "icon";
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "md", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-md font-medium transition-all duration-200 ease-out",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
          "disabled:pointer-events-none disabled:opacity-50",
          "cursor-pointer",
          // variants
          variant === "default" && "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
          variant === "destructive" && "bg-danger text-white hover:bg-danger/90 shadow-sm",
          variant === "outline" && "border border-border bg-transparent hover:bg-surface-2 hover:border-border-hover",
          variant === "ghost" && "hover:bg-surface-2",
          variant === "link" && "text-primary underline-offset-4 hover:underline",
          variant === "success" && "bg-emerald-600 text-white hover:bg-emerald-700",
          // sizes
          size === "sm" && "h-8 px-3 text-xs",
          size === "md" && "h-9 px-4 text-sm",
          size === "lg" && "h-11 px-6 text-base",
          size === "icon" && "h-9 w-9 p-0",
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button };
