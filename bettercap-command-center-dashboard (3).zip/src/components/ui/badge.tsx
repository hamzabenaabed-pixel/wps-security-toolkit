"use client";
import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "success" | "danger" | "warning" | "info" | "outline";
}

export function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
        variant === "default" && "bg-surface-2 text-foreground",
        variant === "success" && "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20",
        variant === "danger" && "bg-red-500/15 text-red-400 border border-red-500/20",
        variant === "warning" && "bg-amber-500/15 text-amber-400 border border-amber-500/20",
        variant === "info" && "bg-blue-500/15 text-blue-400 border border-blue-500/20",
        variant === "outline" && "border border-border text-muted",
        className
      )}
      {...props}
    />
  );
}
