"use client";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { EmptyState } from "@/components/shared/EmptyState";
import {
  Bluetooth,
  Mouse,
  List,
  PenTool,
  Power,
} from "lucide-react";

const mockBLEDevices = [
  { mac: "AA:BB:CC:11:22:33", name: "Mi Band 7", vendor: "Xiaomi", rssi: -45, connectable: true, services: ["Heart Rate", "Battery"] },
  { mac: "DD:EE:FF:44:55:66", name: "AirPods Pro", vendor: "Apple", rssi: -62, connectable: false, services: ["Audio"] },
  { mac: "11:22:33:AA:BB:CC", name: "Unknown", vendor: "Unknown", rssi: -78, connectable: true, services: [] },
  { mac: "44:55:66:DD:EE:FF", name: "Smart Lock", vendor: "Nuki", rssi: -55, connectable: true, services: ["Lock", "Battery"] },
];

export function BluetoothPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.bluetooth.title}</h1>
          <p className="text-sm text-muted">{ar.bluetooth.subtitle}</p>
        </div>
        <Button variant="default" className="gap-2">
          <Power className="h-4 w-4" />
          تشغيل الاستطلاع
        </Button>
      </div>

      <Tabs defaultValue="ble">
        <TabsList>
          <TabsTrigger value="ble">
            <Bluetooth className="h-3.5 w-3.5" />
            {ar.bluetooth.bleDevices} ({mockBLEDevices.length})
          </TabsTrigger>
          <TabsTrigger value="hid">
            <Mouse className="h-3.5 w-3.5" />
            {ar.bluetooth.hidDevices}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ble">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {mockBLEDevices.map((device) => (
              <Card key={device.mac} className="hover:border-border-hover transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                      <Bluetooth className="h-5 w-5 text-cyan-400" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{device.name}</p>
                      <bdi className="ltr-content text-xs text-muted font-mono">{device.mac}</bdi>
                    </div>
                  </div>
                  <Badge variant={device.connectable ? "success" : "outline"}>
                    {device.connectable ? "قابل للاتصال" : "غير قابل"}
                  </Badge>
                </div>

                <div className="flex items-center gap-4 text-xs text-muted mb-3">
                  <span>الشركة: {device.vendor}</span>
                  <span className="ltr-content" dir="ltr">RSSI: {device.rssi}dBm</span>
                </div>

                {device.services.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {device.services.map((s) => (
                      <Badge key={s} variant="info" className="text-[10px]">
                        {s}
                      </Badge>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2 pt-3 border-t border-border">
                  <Button variant="outline" size="sm" className="gap-1 text-xs flex-1">
                    <List className="h-3 w-3" />
                    {ar.bluetooth.enumerate}
                  </Button>
                  {device.connectable && (
                    <Button variant="outline" size="sm" className="gap-1 text-xs flex-1">
                      <PenTool className="h-3 w-3" />
                      {ar.bluetooth.writeValue}
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="hid">
          <EmptyState
            icon={Mouse}
            title="لم يتم اكتشاف أجهزة HID"
            description="قم بتشغيل hid.recon لاكتشاف أجهزة الإدخال اللاسلكية 2.4GHz"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
