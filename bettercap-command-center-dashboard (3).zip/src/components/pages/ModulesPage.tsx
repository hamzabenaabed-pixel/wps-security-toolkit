"use client";
import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { getCategoryLabel, getCategoryColor } from "@/lib/bettercap/modules";
import type { ModuleCategory } from "@/lib/bettercap/types";
import Link from "next/link";
import {
  Search,
  Settings2,
  Puzzle,
} from "lucide-react";

const categories: Array<{ key: string; label: string }> = [
  { key: "all", label: ar.modules.all },
  { key: "core", label: ar.modules.core },
  { key: "network", label: ar.modules.network },
  { key: "spoofing", label: ar.modules.spoofing },
  { key: "http", label: ar.modules.http },
  { key: "wifi", label: ar.modules.wifi },
  { key: "bluetooth", label: ar.modules.bluetooth },
  { key: "c2", label: ar.modules.c2 },
];

export function ModulesPage() {
  const { modules, toggleModule } = useAppStore();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");

  const filtered = modules.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.description.includes(search);
    const matchesCategory = category === "all" || m.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* العنوان */}
      <div>
        <h1 className="text-2xl font-bold">{ar.modules.title}</h1>
        <p className="text-sm text-muted">{ar.modules.subtitle}</p>
      </div>

      {/* البحث والفلترة */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input
            placeholder={ar.modules.search}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
      </div>

      {/* التبويبات */}
      <Tabs defaultValue="all" value={category} onValueChange={setCategory}>
        <TabsList className="flex-wrap">
          {categories.map((cat) => (
            <TabsTrigger key={cat.key} value={cat.key}>
              {cat.label}
              <span className="mr-1 text-[10px] text-muted-foreground">
                ({cat.key === "all"
                  ? modules.length
                  : modules.filter((m) => m.category === cat.key).length})
              </span>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {/* شبكة البطاقات */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filtered.map((mod) => (
          <Card
            key={mod.id}
            className="group flex flex-col hover:border-border-hover transition-all duration-200"
          >
            {/* رأس البطاقة */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${getCategoryColor(mod.category)} bg-opacity-20`}>
                  <Puzzle className="h-4 w-4 text-white" />
                </div>
                <div>
                  <bdi className="ltr-content text-sm font-semibold">{mod.name}</bdi>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className={`inline-block h-1.5 w-1.5 rounded-full ${getCategoryColor(mod.category)}`} />
                    <span className="text-[10px] text-muted-foreground">
                      {getCategoryLabel(mod.category)}
                    </span>
                  </div>
                </div>
              </div>
              <Switch
                checked={mod.running}
                onCheckedChange={() => toggleModule(mod.id)}
                aria-label={`${mod.running ? "إيقاف" : "تشغيل"} ${mod.name}`}
              />
            </div>

            {/* الوصف */}
            <p className="text-xs text-muted leading-relaxed mb-3 flex-1 line-clamp-2">
              {mod.description}
            </p>

            {/* التذييل */}
            <div className="flex items-center justify-between pt-3 border-t border-border">
              <div className="flex items-center gap-2">
                <StatusBadge running={mod.running} />
                {mod.parameters.length > 0 && (
                  <Badge variant="outline">
                    {mod.parameters.length} {ar.modules.paramCount}
                  </Badge>
                )}
              </div>
              <Link href={`/modules/${encodeURIComponent(mod.id)}`}>
                <Button variant="ghost" size="sm" className="gap-1">
                  <Settings2 className="h-3 w-3" />
                  {ar.modules.configure}
                </Button>
              </Link>
            </div>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center text-sm text-muted">{ar.common.noResults}</div>
      )}
    </div>
  );
}
