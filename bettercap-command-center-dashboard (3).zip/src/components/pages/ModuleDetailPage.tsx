"use client";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { getCategoryLabel } from "@/lib/bettercap/modules";
import { EmptyState } from "@/components/shared/EmptyState";
import {
  Play,
  Square,
  Copy,
  RotateCcw,
  Terminal,
  Settings2,
  FileText,
  Puzzle,
} from "lucide-react";
import { useState } from "react";

interface ModuleDetailPageProps {
  moduleId: string;
}

export function ModuleDetailPage({ moduleId }: ModuleDetailPageProps) {
  const { modules, toggleModule, setModuleParameter } = useAppStore();
  const mod = modules.find((m) => m.id === moduleId);
  const [copiedParam, setCopiedParam] = useState<string | null>(null);

  if (!mod) {
    return (
      <EmptyState
        icon={Puzzle}
        title="الوحدة غير موجودة"
        description="لم يتم العثور على الوحدة المطلوبة"
      />
    );
  }

  const copyCommand = (paramName: string, value: string) => {
    navigator.clipboard.writeText(`set ${paramName} ${value}`);
    setCopiedParam(paramName);
    setTimeout(() => setCopiedParam(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* رأس الصفحة */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <bdi className="ltr-content text-2xl font-bold">{mod.name}</bdi>
            <StatusBadge running={mod.running} />
            <Badge variant="outline">{getCategoryLabel(mod.category)}</Badge>
          </div>
          <p className="text-sm text-muted">{mod.description}</p>
        </div>
        <Button
          variant={mod.running ? "destructive" : "success"}
          size="lg"
          onClick={() => toggleModule(mod.id)}
          className="gap-2"
        >
          {mod.running ? (
            <>
              <Square className="h-4 w-4" />
              {ar.modules.stop}
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              {ar.modules.start}
            </>
          )}
        </Button>
      </div>

      {/* التبويبات */}
      <Tabs defaultValue="parameters">
        <TabsList>
          <TabsTrigger value="parameters">
            <Settings2 className="h-3.5 w-3.5" />
            {ar.modules.parameters} ({mod.parameters.length})
          </TabsTrigger>
          <TabsTrigger value="commands">
            <Terminal className="h-3.5 w-3.5" />
            {ar.modules.commands} ({mod.commands.length})
          </TabsTrigger>
          <TabsTrigger value="output">
            <FileText className="h-3.5 w-3.5" />
            {ar.modules.liveOutput}
          </TabsTrigger>
        </TabsList>

        {/* المتغيرات */}
        <TabsContent value="parameters">
          {mod.parameters.length === 0 ? (
            <EmptyState
              icon={Settings2}
              title="لا توجد متغيرات"
              description="هذه الوحدة لا تحتوي على متغيرات قابلة للتعديل"
            />
          ) : (
            <div className="space-y-3">
              {mod.parameters.map((param) => (
                <Card key={param.name} className="p-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <bdi className="ltr-content text-sm font-mono font-semibold text-primary">
                          {param.name}
                        </bdi>
                        <Badge variant="outline" className="text-[10px]">
                          {param.type}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted">{param.description}</p>
                    </div>
                    <div className="flex items-center gap-2 sm:w-72">
                      {param.type === "bool" ? (
                        <Switch
                          checked={param.defaultValue === "true"}
                          onCheckedChange={(checked) =>
                            setModuleParameter(mod.id, param.name, checked ? "true" : "false")
                          }
                          aria-label={param.name}
                        />
                      ) : param.type === "enum" && param.options ? (
                        <select
                          value={param.defaultValue}
                          onChange={(e) =>
                            setModuleParameter(mod.id, param.name, e.target.value)
                          }
                          className="flex h-9 w-full rounded-md border border-border bg-surface-2 px-3 py-2 text-sm"
                        >
                          {param.options.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      ) : param.type === "int" || param.type === "float" ? (
                        <Input
                          type="number"
                          value={param.defaultValue}
                          onChange={(e) =>
                            setModuleParameter(mod.id, param.name, e.target.value)
                          }
                          className="ltr-content"
                          dir="ltr"
                        />
                      ) : (
                        <Input
                          value={param.defaultValue}
                          onChange={(e) =>
                            setModuleParameter(mod.id, param.name, e.target.value)
                          }
                          className="ltr-content"
                          dir="ltr"
                        />
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyCommand(param.name, param.defaultValue)}
                        title={ar.modules.copyCommand}
                      >
                        <Copy className={`h-3.5 w-3.5 ${copiedParam === param.name ? "text-primary" : ""}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title={ar.modules.resetDefault}
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* الأوامر */}
        <TabsContent value="commands">
          <div className="space-y-3">
            {mod.commands.map((cmd) => (
              <Card key={cmd.command} className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <bdi className="ltr-content text-sm font-mono font-semibold text-emerald-400">
                      {cmd.command}
                    </bdi>
                    <p className="text-xs text-muted mt-1">{cmd.description}</p>
                    {cmd.example && (
                      <p className="text-xs text-muted-foreground mt-1 ltr-content" dir="ltr">
                        مثال: <code className="text-primary">{cmd.example}</code>
                      </p>
                    )}
                  </div>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Play className="h-3 w-3" />
                    تنفيذ
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* الإخراج المباشر */}
        <TabsContent value="output">
          <Card className="p-4">
            <div className="rounded-lg bg-background p-4 font-mono text-xs text-muted ltr-content min-h-[200px]" dir="ltr">
              {mod.running ? (
                <div className="space-y-1">
                  <p className="text-emerald-400">
                    [{new Date().toLocaleTimeString("en")}] {mod.name} started
                  </p>
                  <p className="text-muted">Waiting for output...</p>
                  <span className="inline-block w-2 h-4 bg-emerald-400 animate-pulse" />
                </div>
              ) : (
                <p className="text-muted-foreground">
                  الوحدة متوقفة — قم بتشغيلها لرؤية الإخراج المباشر
                </p>
              )}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
