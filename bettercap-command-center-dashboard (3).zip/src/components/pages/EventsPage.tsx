"use client";
import { useState, useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ScrollText,
  Pause,
  Play,
  Trash2,
  Download,
  Search,
  Filter,
} from "lucide-react";

const eventTypeLabels: Record<string, string> = {
  "session.started": "بدء الجلسة",
  "session.stopped": "إيقاف الجلسة",
  "endpoint.new": "جهاز جديد",
  "endpoint.lost": "جهاز مفقود",
  "wifi.ap.new": "نقطة وصول جديدة",
  "wifi.client.new": "عميل واي فاي جديد",
  "mod.started": "تشغيل وحدة",
  "mod.stopped": "إيقاف وحدة",
  "net.sniff.credentials": "بيانات اعتماد",
  "sys.log": "سجل النظام",
};

function getEventVariant(type: string): "success" | "danger" | "warning" | "info" | "outline" {
  if (type.includes("new") || type.includes("started")) return "success";
  if (type.includes("lost") || type.includes("stopped")) return "danger";
  if (type.includes("credential")) return "warning";
  if (type.includes("wifi") || type.includes("ble")) return "info";
  return "outline";
}

export function EventsPage() {
  const { events, addEvent } = useAppStore();
  const [paused, setPaused] = useState(false);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<string>("");

  // إضافة أحداث تجريبية بشكل دوري
  useEffect(() => {
    if (paused) return;
    const interval = setInterval(() => {
      const types = ["endpoint.new", "wifi.ap.new", "sys.log", "mod.started"];
      const type = types[Math.floor(Math.random() * types.length)];
      addEvent({
        id: `evt-${Date.now()}`,
        type,
        time: new Date().toISOString(),
        data: { message: `حدث جديد: ${eventTypeLabels[type] || type}` },
        tag: type.split(".")[0],
      });
    }, 5000);
    return () => clearInterval(interval);
  }, [paused, addEvent]);

  const uniqueTypes = Array.from(new Set(events.map((e) => e.type)));

  const filtered = events.filter((e) => {
    const matchesSearch = search
      ? e.type.includes(search) || JSON.stringify(e.data).includes(search)
      : true;
    const matchesType = filterType ? e.type === filterType : true;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.events.title}</h1>
          <p className="text-sm text-muted">{ar.events.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={paused ? "default" : "outline"}
            size="sm"
            onClick={() => setPaused(!paused)}
            className="gap-1"
          >
            {paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            {paused ? ar.events.resume : ar.events.pause}
          </Button>
          <Button variant="outline" size="sm" className="gap-1">
            <Download className="h-3.5 w-3.5" />
            {ar.events.export}
          </Button>
        </div>
      </div>

      {/* البحث والفلترة */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input
            placeholder={ar.events.search}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <div className="flex flex-wrap gap-1">
          <Button
            variant={filterType === "" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("")}
            className="text-xs"
          >
            {ar.events.allEvents}
          </Button>
          {uniqueTypes.slice(0, 6).map((type) => (
            <Button
              key={type}
              variant={filterType === type ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterType(type)}
              className="text-xs"
            >
              <bdi className="ltr-content">{type}</bdi>
            </Button>
          ))}
        </div>
      </div>

      {/* قائمة الأحداث */}
      <div className="space-y-2">
        {!paused && (
          <div className="flex items-center gap-2 text-xs text-emerald-400 mb-2">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse-dot" />
            بث مباشر — {filtered.length} حدث
          </div>
        )}

        {filtered.map((event) => (
          <Card key={event.id} className="p-3 hover:border-border-hover transition-colors">
            <div className="flex items-center gap-3">
              <Badge variant={getEventVariant(event.type)} className="shrink-0">
                <bdi className="ltr-content text-[10px]">{event.type}</bdi>
              </Badge>
              <span className="flex-1 text-sm text-muted truncate">
                {typeof event.data?.message === "string" ? event.data.message : eventTypeLabels[event.type] || event.type}
              </span>
              <span className="text-[10px] text-muted-foreground font-mono ltr-content shrink-0" dir="ltr">
                {new Date(event.time).toLocaleTimeString("en")}
              </span>
            </div>
          </Card>
        ))}

        {filtered.length === 0 && (
          <div className="py-16 text-center text-sm text-muted">{ar.common.noResults}</div>
        )}
      </div>
    </div>
  );
}
