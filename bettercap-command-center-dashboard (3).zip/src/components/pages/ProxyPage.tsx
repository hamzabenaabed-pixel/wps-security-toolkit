"use client";
import { useState } from "react";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Globe,
  Lock,
  ArrowRightLeft,
  Code,
  FileCode,
  Power,
} from "lucide-react";

const jsTemplates = [
  { name: "Keylogger", description: "تسجيل ضغطات المفاتيح", code: "function onRequest(req, res) {\n  // inject keylogger\n}" },
  { name: "Image Replacer", description: "استبدال جميع الصور", code: "function onResponse(req, res) {\n  // replace images\n}" },
  { name: "BeEF Hook", description: "حقن BeEF Framework", code: "function onResponse(req, res) {\n  // inject beef hook\n}" },
];

export function ProxyPage() {
  const [httpEnabled, setHttpEnabled] = useState(false);
  const [httpsEnabled, setHttpsEnabled] = useState(false);
  const [sslStrip, setSslStrip] = useState(false);
  const [scriptContent, setScriptContent] = useState("// اكتب سكربت JavaScript هنا\nfunction onRequest(req, res) {\n  log('Request: ' + req.Method + ' ' + req.URL);\n}\n\nfunction onResponse(req, res) {\n  log('Response: ' + res.Status);\n}");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{ar.proxy.title}</h1>
        <p className="text-sm text-muted">{ar.proxy.subtitle}</p>
      </div>

      <Tabs defaultValue="http">
        <TabsList>
          <TabsTrigger value="http">
            <Globe className="h-3.5 w-3.5" />
            {ar.proxy.httpProxy}
          </TabsTrigger>
          <TabsTrigger value="https">
            <Lock className="h-3.5 w-3.5" />
            {ar.proxy.httpsProxy}
          </TabsTrigger>
          <TabsTrigger value="tcp">
            <ArrowRightLeft className="h-3.5 w-3.5" />
            {ar.proxy.tcpProxy}
          </TabsTrigger>
          <TabsTrigger value="scripts">
            <Code className="h-3.5 w-3.5" />
            {ar.proxy.scriptEditor}
          </TabsTrigger>
        </TabsList>

        {/* HTTP Proxy */}
        <TabsContent value="http">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">بروكسي HTTP</CardTitle>
                  <Switch checked={httpEnabled} onCheckedChange={setHttpEnabled} aria-label="HTTP Proxy" />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <label className="text-xs text-muted mb-1 block">عنوان الاستماع</label>
                  <Input defaultValue="0.0.0.0" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">المنفذ</label>
                  <Input type="number" defaultValue="8080" className="ltr-content" dir="ltr" />
                </div>
                <div className="flex items-center justify-between rounded-lg border border-border p-3">
                  <span className="text-sm">SSL Strip</span>
                  <Switch checked={sslStrip} onCheckedChange={setSslStrip} aria-label="SSL Strip" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">الطلبات المعترضة</CardTitle>
              </CardHeader>
              <CardContent>
                {httpEnabled ? (
                  <div className="space-y-2">
                    {[
                      { method: "GET", url: "http://example.com/login", status: 200 },
                      { method: "POST", url: "http://api.example.com/data", status: 301 },
                      { method: "GET", url: "http://cdn.example.com/style.css", status: 200 },
                    ].map((req, i) => (
                      <div key={i} className="flex items-center gap-2 rounded-lg border border-border bg-surface-2 p-2 text-xs">
                        <Badge variant={req.method === "POST" ? "warning" : "info"} className="text-[9px]">
                          {req.method}
                        </Badge>
                        <span className="flex-1 truncate font-mono ltr-content" dir="ltr">
                          {req.url}
                        </span>
                        <Badge variant={req.status === 200 ? "success" : "warning"}>
                          {req.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted text-center py-8">
                    قم بتشغيل البروكسي لرؤية الطلبات
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* HTTPS Proxy */}
        <TabsContent value="https">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">بروكسي HTTPS</CardTitle>
                <Switch checked={httpsEnabled} onCheckedChange={setHttpsEnabled} aria-label="HTTPS Proxy" />
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="text-xs text-muted mb-1 block">عنوان الاستماع</label>
                  <Input defaultValue="0.0.0.0" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">المنفذ</label>
                  <Input type="number" defaultValue="8083" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">مسار الشهادة</label>
                  <Input placeholder="/path/to/cert.pem" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">مسار المفتاح</label>
                  <Input placeholder="/path/to/key.pem" className="ltr-content" dir="ltr" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TCP Proxy */}
        <TabsContent value="tcp">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">بروكسي TCP/UDP</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="text-xs text-muted mb-1 block">عنوان المصدر</label>
                  <Input placeholder="0.0.0.0" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">منفذ المصدر</label>
                  <Input type="number" defaultValue="8080" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">عنوان الوجهة</label>
                  <Input placeholder="127.0.0.1" className="ltr-content" dir="ltr" />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1 block">منفذ الوجهة</label>
                  <Input type="number" defaultValue="80" className="ltr-content" dir="ltr" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* محرر السكربتات */}
        <TabsContent value="scripts">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">{ar.proxy.scriptEditor}</CardTitle>
                </CardHeader>
                <CardContent>
                  <textarea
                    value={scriptContent}
                    onChange={(e) => setScriptContent(e.target.value)}
                    className="w-full h-64 rounded-lg border border-border bg-background p-4 font-mono text-xs text-emerald-400 resize-none ltr-content"
                    dir="ltr"
                    spellCheck={false}
                  />
                  <div className="flex justify-end mt-3">
                    <Button variant="default" className="gap-1">
                      <Power className="h-3.5 w-3.5" />
                      تطبيق السكربت
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">{ar.proxy.templates}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {jsTemplates.map((tmpl) => (
                  <button
                    key={tmpl.name}
                    onClick={() => setScriptContent(tmpl.code)}
                    className="w-full flex items-start gap-3 rounded-lg border border-border p-3 text-right hover:border-border-hover transition-colors cursor-pointer"
                  >
                    <FileCode className="h-4 w-4 text-muted shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">{tmpl.name}</p>
                      <p className="text-xs text-muted">{tmpl.description}</p>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
