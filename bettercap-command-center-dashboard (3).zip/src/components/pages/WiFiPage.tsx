"use client";
import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn, rssiToPercentage } from "@/lib/utils";
import {
  Wifi,
  WifiOff,
  Users,
  Shield,
  Zap,
  Search,
  Radio,
  Lock,
  Unlock,
} from "lucide-react";

export function WiFiPage() {
  const { wifiAPs } = useAppStore();
  const [search, setSearch] = useState("");

  const filteredAPs = wifiAPs.filter(
    (ap) =>
      ap.ssid.toLowerCase().includes(search.toLowerCase()) ||
      ap.bssid.toLowerCase().includes(search.toLowerCase())
  );

  const channels2g = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  const channels5g = [36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{ar.wifi.title}</h1>
        <p className="text-sm text-muted">{ar.wifi.subtitle}</p>
      </div>

      <Tabs defaultValue="aps">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <TabsList>
            <TabsTrigger value="aps">
              <Wifi className="h-3.5 w-3.5" />
              {ar.wifi.accessPoints} ({wifiAPs.length})
            </TabsTrigger>
            <TabsTrigger value="clients">
              <Users className="h-3.5 w-3.5" />
              {ar.wifi.clients}
            </TabsTrigger>
            <TabsTrigger value="channels">
              <Radio className="h-3.5 w-3.5" />
              {ar.wifi.channelHopper}
            </TabsTrigger>
            <TabsTrigger value="handshakes">
              <Shield className="h-3.5 w-3.5" />
              {ar.wifi.handshakes}
            </TabsTrigger>
          </TabsList>

          <div className="relative max-w-xs">
            <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              placeholder={ar.common.search}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-10"
            />
          </div>
        </div>

        {/* نقاط الوصول */}
        <TabsContent value="aps">
          <Card className="overflow-hidden p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-surface-2 text-xs text-muted">
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.ssid}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.bssid}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.channel}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.rssi}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.encryption}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.wifi.clientsCount}</th>
                    <th className="px-4 py-3 text-right font-medium">{ar.common.actions}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAPs.map((ap) => {
                    const pct = rssiToPercentage(ap.rssi);
                    return (
                      <tr
                        key={ap.bssid}
                        className="border-b border-border hover:bg-surface-2 transition-colors"
                      >
                        <td className="px-4 py-3 font-medium">
                          <div className="flex items-center gap-2">
                            {ap.encryption === "Open" ? (
                              <Unlock className="h-3.5 w-3.5 text-amber-400" />
                            ) : (
                              <Lock className="h-3.5 w-3.5 text-emerald-400" />
                            )}
                            <bdi className="ltr-content">{ap.ssid}</bdi>
                            {ap.handshake && (
                              <Badge variant="success" className="text-[9px]">
                                مصافحة
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <bdi className="ltr-content font-mono text-xs">{ap.bssid}</bdi>
                        </td>
                        <td className="px-4 py-3 text-center">{ap.channel}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 w-16 rounded-full bg-surface-2">
                              <div
                                className={cn(
                                  "h-full rounded-full transition-all",
                                  pct >= 70
                                    ? "bg-emerald-500"
                                    : pct >= 40
                                    ? "bg-amber-500"
                                    : "bg-red-500"
                                )}
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                            <span className="text-xs text-muted ltr-content" dir="ltr">
                              {ap.rssi}dBm
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <Badge
                            variant={
                              ap.encryption === "Open"
                                ? "warning"
                                : ap.encryption === "WEP"
                                ? "danger"
                                : "success"
                            }
                          >
                            {ap.encryption}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-center">{ap.clientsCount}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="sm" className="gap-1 text-xs text-red-400">
                              <WifiOff className="h-3 w-3" />
                              {ar.wifi.deauth}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* العملاء */}
        <TabsContent value="clients">
          <Card className="p-8 text-center">
            <Users className="mx-auto h-12 w-12 text-muted mb-4" />
            <p className="text-sm text-muted">لم يتم اكتشاف عملاء بعد</p>
            <p className="text-xs text-muted-foreground mt-1">
              قم بتشغيل wifi.recon لاكتشاف العملاء
            </p>
          </Card>
        </TabsContent>

        {/* تغيير القنوات */}
        <TabsContent value="channels">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">قنوات 2.4GHz</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {channels2g.map((ch) => {
                    const apCount = wifiAPs.filter((ap) => ap.channel === ch).length;
                    return (
                      <Button
                        key={ch}
                        variant={apCount > 0 ? "default" : "outline"}
                        size="sm"
                        className="relative w-12"
                      >
                        {ch}
                        {apCount > 0 && (
                          <span className="absolute -top-1 -left-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                            {apCount}
                          </span>
                        )}
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">قنوات 5GHz</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {channels5g.map((ch) => {
                    const apCount = wifiAPs.filter((ap) => ap.channel === ch).length;
                    return (
                      <Button
                        key={ch}
                        variant={apCount > 0 ? "default" : "outline"}
                        size="sm"
                        className="relative w-12"
                      >
                        {ch}
                        {apCount > 0 && (
                          <span className="absolute -top-1 -left-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                            {apCount}
                          </span>
                        )}
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* المصافحات */}
        <TabsContent value="handshakes">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-surface-2 text-xs text-muted">
                      <th className="px-4 py-3 text-right font-medium">{ar.wifi.ssid}</th>
                      <th className="px-4 py-3 text-right font-medium">{ar.wifi.bssid}</th>
                      <th className="px-4 py-3 text-right font-medium">الحالة</th>
                      <th className="px-4 py-3 text-right font-medium">{ar.common.actions}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {wifiAPs
                      .filter((ap) => ap.handshake)
                      .map((ap) => (
                        <tr key={ap.bssid} className="border-b border-border hover:bg-surface-2">
                          <td className="px-4 py-3 font-medium">
                            <bdi className="ltr-content">{ap.ssid}</bdi>
                          </td>
                          <td className="px-4 py-3">
                            <bdi className="ltr-content font-mono text-xs">{ap.bssid}</bdi>
                          </td>
                          <td className="px-4 py-3">
                            <Badge variant="success">تم الالتقاط</Badge>
                          </td>
                          <td className="px-4 py-3">
                            <Button variant="outline" size="sm" className="gap-1 text-xs">
                              <Zap className="h-3 w-3" />
                              تنزيل
                            </Button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
