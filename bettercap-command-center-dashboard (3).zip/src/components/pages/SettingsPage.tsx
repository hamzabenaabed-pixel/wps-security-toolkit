"use client";
import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Wifi,
  Moon,
  Sun,
  Monitor,
  Keyboard,
  Save,
  TestTube,
  Check,
  Smartphone,
  Copy,
  Shield,
  Terminal,
  Globe,
  X,
} from "lucide-react";

export function SettingsPage() {
  const { connected } = useAppStore();
  const [apiUrl, setApiUrl] = useState("http://127.0.0.1:8081");
  const [username, setUsername] = useState("user");
  const [password, setPassword] = useState("pass");
  const [theme, setTheme] = useState<"dark" | "light" | "auto">("dark");
  const [testResult, setTestResult] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [copied, setCopied] = useState<string | null>(null);

  const handleThemeChange = (t: "dark" | "light" | "auto") => {
    setTheme(t);
    document.documentElement.setAttribute("data-theme", t === "auto" ? "dark" : t);
    localStorage.setItem("theme", t);
  };

  const testConnection = async () => {
    setTestResult("testing");
    try {
      const response = await fetch("/api/bettercap/session");
      if (response.ok) {
        setTestResult("success");
      } else {
        setTestResult("error");
      }
    } catch {
      setTestResult("error");
    }
    setTimeout(() => setTestResult("idle"), 3000);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  // أوامر إعداد NetHunter - تشغيل محلي على نفس الهاتف
  const nethunterSetup = [
    {
      id: "install",
      title: "١. تثبيت Bettercap",
      desc: "تثبيت Bettercap على Kali NetHunter",
      cmd: "apt update && apt install -y bettercap nodejs npm",
    },
    {
      id: "gateway",
      title: "٢. إصلاح مشكلة Gateway (إن وجدت)",
      desc: "إذا ظهر خطأ 'could not detect gateway'",
      cmd: "ip route add default via 192.168.1.1 dev wlan0",
    },
    {
      id: "start-bettercap",
      title: "٣. تشغيل Bettercap مع API",
      desc: "في Terminal منفصل - اتركه يعمل",
      cmd: "bettercap -caplet http-ui",
    },
    {
      id: "clone-app",
      title: "٤. تحميل التطبيق",
      desc: "في Terminal جديد",
      cmd: `cd ~
git clone https://github.com/user/bettercap-command-center.git
cd bettercap-command-center
npm install`,
    },
    {
      id: "run-app",
      title: "٥. تشغيل التطبيق",
      desc: "ثم افتح المتصفح على localhost:3000",
      cmd: "npm run dev",
    },
  ];

  const customCaplet = `# حفظ في: /usr/local/share/bettercap/caplets/local-api.cap
# للتشغيل المحلي على نفس الهاتف

set api.rest.address 127.0.0.1
set api.rest.port 8081
set api.rest.username ${username}
set api.rest.password ${password}
set api.rest.websocket true

api.rest on
net.recon on
events.stream on`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{ar.settings.title}</h1>
        <p className="text-sm text-muted">{ar.settings.subtitle}</p>
      </div>

      <Tabs defaultValue="nethunter">
        <TabsList>
          <TabsTrigger value="nethunter">
            <Smartphone className="h-3.5 w-3.5" />
            إعداد NetHunter
          </TabsTrigger>
          <TabsTrigger value="connection">
            <Wifi className="h-3.5 w-3.5" />
            الاتصال
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Monitor className="h-3.5 w-3.5" />
            المظهر
          </TabsTrigger>
          <TabsTrigger value="shortcuts">
            <Keyboard className="h-3.5 w-3.5" />
            الاختصارات
          </TabsTrigger>
        </TabsList>

        {/* إعداد NetHunter */}
        <TabsContent value="nethunter">
          <div className="space-y-4">
            {/* معلومات عامة */}
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">تشغيل كل شيء على نفس الهاتف</h3>
                    <p className="text-sm text-muted leading-relaxed">
                      ستحتاج فتح Terminal في NetHunter. شغّل Bettercap في تبويب، والتطبيق في تبويب آخر.
                      الاتصال سيكون على <code className="text-primary">127.0.0.1:8081</code>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* خطوات الإعداد */}
            {nethunterSetup.map((step) => (
              <Card key={step.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Terminal className="h-4 w-4 text-primary" />
                    {step.title}
                  </CardTitle>
                  <p className="text-xs text-muted">{step.desc}</p>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <pre className="rounded-lg bg-background p-3 text-xs font-mono text-emerald-400 overflow-x-auto ltr-content" dir="ltr">
                      {step.cmd}
                    </pre>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 left-2 h-7 w-7"
                      onClick={() => copyToClipboard(step.cmd, step.id)}
                    >
                      {copied === step.id ? (
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Caplet مخصص */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Terminal className="h-4 w-4 text-amber-400" />
                  ٦. Caplet مخصص (اختياري)
                </CardTitle>
                <p className="text-xs text-muted">
                  أنشئ ملف caplet مخصص للاتصال المباشر مع هذا التطبيق
                </p>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <pre className="rounded-lg bg-background p-3 text-xs font-mono text-amber-400 overflow-x-auto max-h-64 ltr-content" dir="ltr">
                    {customCaplet}
                  </pre>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 left-2 h-7 w-7"
                    onClick={() => copyToClipboard(customCaplet, "caplet")}
                  >
                    {copied === "caplet" ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted mt-2">
                  شغّله بـ: <code className="text-primary">bettercap -caplet remote-ui</code>
                </p>
              </CardContent>
            </Card>

            {/* ملاحظات مهمة */}
            <Card className="border-amber-500/30 bg-amber-500/5">
              <CardContent className="p-4">
                <h4 className="font-semibold text-amber-400 mb-2">ملاحظات مهمة:</h4>
                <ul className="text-sm text-muted space-y-1 list-disc list-inside">
                  <li>شغّل Bettercap أولاً في Terminal منفصل</li>
                  <li>ثم شغّل التطبيق في Terminal آخر</li>
                  <li>افتح المتصفح على <code>http://localhost:3000</code></li>
                  <li>API يعمل على <code>http://127.0.0.1:8081</code></li>
                  <li>لوضع Monitor: تحتاج محول WiFi خارجي يدعمه</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* إعدادات الاتصال */}
        <TabsContent value="connection">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Wifi className="h-4 w-4 text-primary" />
                    اتصال Bettercap API
                  </CardTitle>
                  <Badge variant={connected ? "success" : "danger"}>
                    {connected ? "متصل" : "غير متصل"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-xs text-muted mb-1.5 block">{ar.settings.apiUrl}</label>
                  <Input
                    value={apiUrl}
                    onChange={(e) => setApiUrl(e.target.value)}
                    placeholder="https://192.168.1.100:8083"
                    className="ltr-content"
                    dir="ltr"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    مثال: https://[IP الهاتف]:8083
                  </p>
                </div>
                <div>
                  <label className="text-xs text-muted mb-1.5 block">{ar.settings.username}</label>
                  <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="ltr-content"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted mb-1.5 block">{ar.settings.password}</label>
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="ltr-content"
                    dir="ltr"
                  />
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <Button variant="default" className="gap-1 flex-1">
                    <Save className="h-3.5 w-3.5" />
                    {ar.settings.save}
                  </Button>
                  <Button
                    variant="outline"
                    className="gap-1"
                    onClick={testConnection}
                    disabled={testResult === "testing"}
                  >
                    {testResult === "testing" ? (
                      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
                    ) : testResult === "success" ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : testResult === "error" ? (
                      <X className="h-3.5 w-3.5 text-red-400" />
                    ) : (
                      <TestTube className="h-3.5 w-3.5" />
                    )}
                    {ar.settings.test}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">معلومات الاتصال</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="rounded-lg border border-border bg-surface-2 p-3">
                  <p className="text-xs text-muted mb-1">رابط API</p>
                  <p className="text-sm font-mono ltr-content" dir="ltr">{apiUrl}/api/session</p>
                </div>
                <div className="rounded-lg border border-border bg-surface-2 p-3">
                  <p className="text-xs text-muted mb-1">Events Stream (SSE)</p>
                  <p className="text-sm font-mono ltr-content" dir="ltr">{apiUrl}/api/events</p>
                </div>
                <div className="rounded-lg border border-border bg-surface-2 p-3">
                  <p className="text-xs text-muted mb-1">WebSocket</p>
                  <p className="text-sm font-mono ltr-content" dir="ltr">{apiUrl.replace("https://", "wss://").replace("http://", "ws://")}/api/events</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* إعدادات المظهر */}
        <TabsContent value="appearance">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Monitor className="h-4 w-4 text-primary" />
                  {ar.settings.appearance}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-xs text-muted mb-2 block">{ar.settings.theme}</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { key: "dark" as const, label: ar.settings.dark, icon: Moon },
                      { key: "light" as const, label: ar.settings.light, icon: Sun },
                      { key: "auto" as const, label: ar.settings.auto, icon: Monitor },
                    ].map((t) => {
                      const Icon = t.icon;
                      return (
                        <button
                          key={t.key}
                          onClick={() => handleThemeChange(t.key)}
                          className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm transition-colors cursor-pointer ${
                            theme === t.key
                              ? "border-primary bg-primary/5 text-primary"
                              : "border-border hover:border-border-hover"
                          }`}
                        >
                          <Icon className="h-4 w-4" />
                          {t.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="text-xs text-muted mb-2 block">{ar.settings.language}</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="flex items-center justify-center gap-2 rounded-lg border border-primary bg-primary/5 p-3 text-sm text-primary cursor-pointer">
                      <Globe className="h-4 w-4" />
                      العربية
                    </button>
                    <button className="flex items-center justify-center gap-2 rounded-lg border border-border p-3 text-sm text-muted hover:border-border-hover transition-colors cursor-pointer">
                      <Globe className="h-4 w-4" />
                      English
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* اختصارات لوحة المفاتيح */}
        <TabsContent value="shortcuts">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Keyboard className="h-4 w-4 text-primary" />
                {ar.settings.shortcuts}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  { keys: "⌘ + K", desc: "فتح لوحة الأوامر" },
                  { keys: "⌘ + /", desc: "فتح الطرفية" },
                  { keys: "⌘ + D", desc: "لوحة التحكم" },
                  { keys: "⌘ + M", desc: "الوحدات" },
                  { keys: "⌘ + N", desc: "الشبكة" },
                  { keys: "Esc", desc: "إغلاق النوافذ" },
                ].map((shortcut) => (
                  <div
                    key={shortcut.keys}
                    className="flex items-center justify-between rounded-lg border border-border bg-surface-2 px-3 py-2"
                  >
                    <span className="text-sm text-muted">{shortcut.desc}</span>
                    <kbd className="rounded border border-border bg-surface px-2 py-0.5 text-xs font-mono ltr-content" dir="ltr">
                      {shortcut.keys}
                    </kbd>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
