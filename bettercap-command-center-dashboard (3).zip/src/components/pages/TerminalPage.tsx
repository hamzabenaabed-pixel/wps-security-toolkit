"use client";
import { useState, useRef, useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Terminal,
  Trash2,
  Download,
  ChevronLeft,
} from "lucide-react";

const BETTERCAP_COMMANDS = [
  "help", "net.show", "net.recon on", "net.recon off", "net.probe on", "net.probe off",
  "wifi.show", "wifi.recon on", "wifi.recon off", "wifi.deauth",
  "arp.spoof on", "arp.spoof off", "dns.spoof on", "dns.spoof off",
  "http.proxy on", "http.proxy off", "https.proxy on", "https.proxy off",
  "net.sniff on", "net.sniff off", "ble.recon on", "ble.recon off",
  "set", "get", "clear", "quit", "events.show", "events.clear",
  "caplets.show", "caplets.update", "ticker on", "ticker off",
];

interface TerminalLine {
  type: "input" | "output" | "error" | "info";
  text: string;
  time: string;
}

export function TerminalPage() {
  const { addTerminalCommand } = useAppStore();
  const [input, setInput] = useState("");
  const [lines, setLines] = useState<TerminalLine[]>([
    { type: "info", text: "مرحباً بك في طرفية Bettercap Command Center", time: new Date().toLocaleTimeString("en") },
    { type: "info", text: "اكتب 'help' للحصول على قائمة الأوامر المتوفرة", time: new Date().toLocaleTimeString("en") },
    { type: "output", text: "", time: "" },
  ]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [history, setHistory] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines]);

  const executeCommand = (cmd: string) => {
    if (!cmd.trim()) return;

    const now = new Date().toLocaleTimeString("en");
    const newLines: TerminalLine[] = [
      ...lines,
      { type: "input", text: cmd, time: now },
    ];

    // إخراج وهمي
    if (cmd === "help") {
      newLines.push({
        type: "output",
        text: `الأوامر المتوفرة:\n${BETTERCAP_COMMANDS.join("\n")}`,
        time: now,
      });
    } else if (cmd === "clear") {
      setLines([]);
      setInput("");
      return;
    } else if (cmd === "net.show") {
      newLines.push({
        type: "output",
        text: `┌──────────────────┬───────────────────┬───────────────┬──────────┐
│   IP Address     │    MAC Address    │    Hostname   │  Vendor  │
├──────────────────┼───────────────────┼───────────────┼──────────┤
│  192.168.1.1     │  AA:BB:CC:DD:EE:FF │  gateway     │  Cisco   │
│  192.168.1.5     │  11:22:33:44:55:66 │  workstation │  Dell    │
│  192.168.1.10    │  77:88:99:AA:BB:CC │  phone       │  Apple   │
└──────────────────┴───────────────────┴───────────────┴──────────┘
3 hosts found.`,
        time: now,
      });
    } else if (cmd.startsWith("set ")) {
      newLines.push({ type: "output", text: `» ${cmd.slice(4)}`, time: now });
    } else if (cmd.endsWith(" on")) {
      newLines.push({ type: "output", text: `[✓] ${cmd.split(" ")[0]} started`, time: now });
    } else if (cmd.endsWith(" off")) {
      newLines.push({ type: "output", text: `[✗] ${cmd.split(" ")[0]} stopped`, time: now });
    } else {
      newLines.push({ type: "error", text: `unknown command: ${cmd}`, time: now });
    }

    setLines(newLines);
    setHistory((prev) => [...prev, cmd]);
    setHistoryIdx(-1);
    setInput("");
    setSuggestions([]);
    addTerminalCommand(cmd);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      executeCommand(input);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (history.length > 0) {
        const newIdx = historyIdx < history.length - 1 ? historyIdx + 1 : historyIdx;
        setHistoryIdx(newIdx);
        setInput(history[history.length - 1 - newIdx]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIdx > 0) {
        const newIdx = historyIdx - 1;
        setHistoryIdx(newIdx);
        setInput(history[history.length - 1 - newIdx]);
      } else {
        setHistoryIdx(-1);
        setInput("");
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      if (suggestions.length === 1) {
        setInput(suggestions[0]);
        setSuggestions([]);
      }
    }
  };

  const handleInputChange = (value: string) => {
    setInput(value);
    if (value.length > 0) {
      const matches = BETTERCAP_COMMANDS.filter((c) => c.startsWith(value.toLowerCase()));
      setSuggestions(matches.slice(0, 5));
    } else {
      setSuggestions([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.terminal.title}</h1>
          <p className="text-sm text-muted">{ar.terminal.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1" onClick={() => setLines([])}>
            <Trash2 className="h-3.5 w-3.5" />
            {ar.terminal.clear}
          </Button>
          <Button variant="outline" size="sm" className="gap-1">
            <Download className="h-3.5 w-3.5" />
            {ar.terminal.record}
          </Button>
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        {/* شريط عنوان الطرفية */}
        <div className="flex items-center gap-2 border-b border-border bg-surface-2 px-4 py-2">
          <div className="flex gap-1.5">
            <span className="h-3 w-3 rounded-full bg-red-500" />
            <span className="h-3 w-3 rounded-full bg-amber-500" />
            <span className="h-3 w-3 rounded-full bg-emerald-500" />
          </div>
          <span className="text-xs text-muted font-mono ltr-content" dir="ltr">
            bettercap@localhost ~ $
          </span>
        </div>

        {/* محتوى الطرفية */}
        <div
          className="h-[500px] overflow-y-auto bg-background p-4 font-mono text-sm ltr-content"
          dir="ltr"
          onClick={() => inputRef.current?.focus()}
        >
          {lines.map((line, i) => (
            <div key={i} className="mb-1">
              {line.type === "input" && (
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">❯</span>
                  <span className="text-foreground">{line.text}</span>
                </div>
              )}
              {line.type === "output" && (
                <pre className="text-muted whitespace-pre-wrap">{line.text}</pre>
              )}
              {line.type === "error" && (
                <span className="text-red-400">[!] {line.text}</span>
              )}
              {line.type === "info" && (
                <span className="text-cyan-400">[*] {line.text}</span>
              )}
            </div>
          ))}

          {/* سطر الإدخال */}
          <div className="flex items-center gap-2 mt-1">
            <span className="text-emerald-400">❯</span>
            <div className="relative flex-1">
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full bg-transparent outline-none text-foreground caret-emerald-400"
                autoFocus
                spellCheck={false}
              />
              {/* اقتراحات */}
              {suggestions.length > 0 && input.length > 0 && (
                <div className="absolute bottom-full left-0 mb-1 rounded-md border border-border bg-surface shadow-lg">
                  {suggestions.map((s) => (
                    <button
                      key={s}
                      onClick={() => {
                        setInput(s);
                        setSuggestions([]);
                        inputRef.current?.focus();
                      }}
                      className="block w-full px-3 py-1.5 text-left text-xs hover:bg-surface-2 transition-colors cursor-pointer"
                    >
                      <span className="text-primary">{s.slice(0, input.length)}</span>
                      <span className="text-muted">{s.slice(input.length)}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div ref={endRef} />
        </div>
      </Card>
    </div>
  );
}
