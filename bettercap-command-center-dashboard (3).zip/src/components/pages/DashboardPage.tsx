"use client";
import { useEffect, useState, useCallback } from "react";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LiveIndicator } from "@/components/shared/LiveIndicator";
import {
  Monitor,
  Wifi,
  Users,
  Puzzle,
  Radar,
  Swords,
  Terminal,
  Activity,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";

interface BettercapHost {
  ipv4?: string;
  ipv6?: string;
  ip?: string;
  mac: string;
  hostname: string;
  alias: string;
  vendor: string;
  first_seen?: string;
  last_seen?: string;
  meta?: Record<string, string>;
}

interface BettercapAP {
  ssid: string;
  bssid: string;
  channel: number;
  rssi: number;
  clients?: Array<{ mac: string }>;
}

interface BettercapModule {
  name: string;
  running: boolean;
}

interface SessionData {
  interface?: string;
  gateway?: BettercapHost;
  lan?: { hosts: Record<string, BettercapHost> | BettercapHost[] };
  wifi?: { aps: Record<string, BettercapAP> | BettercapAP[] };
  modules?: BettercapModule[];
}

interface EventData {
  tag: string;
  time: string;
  data: Record<string, unknown>;
}

// تحويل كائنات Bettercap إلى مصفوفات
function hostsToArray(hostsObj: Record<string, BettercapHost> | BettercapHost[] | undefined): BettercapHost[] {
  if (!hostsObj) return [];
  if (Array.isArray(hostsObj)) return hostsObj;
  return Object.values(hostsObj);
}

function apsToArray(apsObj: Record<string, BettercapAP> | BettercapAP[] | undefined): BettercapAP[] {
  if (!apsObj) return [];
  if (Array.isArray(apsObj)) return apsObj;
  return Object.values(apsObj);
}

// الحصول على IP من host (يدعم ipv4, ip, أو key)
function getHostIP(host: BettercapHost): string {
  return host.ipv4 || host.ip || "unknown";
}

export function DashboardPage() {
  const [session, setSession] = useState<SessionData | null>(null);
  const [events, setEvents] = useState<EventData[]>([]);
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const [sessionRes, eventsRes] = await Promise.all([
        fetch("/api/bettercap/session"),
        fetch("/api/bettercap/events"),
      ]);

      if (sessionRes.ok) {
        const data = await sessionRes.json();
        if (!data.error) {
          setSession(data);
          setConnected(true);
          setError(null);
        } else {
          setConnected(false);
          setError(data.error);
        }
      } else {
        setConnected(false);
        setError("فشل الاتصال بـ Bettercap");
      }

      if (eventsRes.ok) {
        const evData = await eventsRes.json();
        if (Array.isArray(evData)) {
          setEvents(evData.slice(-20).reverse());
        }
      }
    } catch (err) {
      setConnected(false);
      setError("لا يمكن الاتصال بـ Bettercap API");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // حساب الإحصائيات من البيانات الحقيقية
  const hosts = hostsToArray(session?.lan?.hosts);
  const aps = apsToArray(session?.wifi?.aps);
  const hostsCount = hosts.length;
  const apsCount = aps.length;
  const clientsCount = aps.reduce((sum, ap) => sum + (ap.clients?.length || 0), 0);
  const activeModules = session?.modules?.filter((m) => m.running).length || 0;

  const stats = [
    {
      label: ar.dashboard.hosts,
      value: hostsCount,
      icon: Monitor,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
    },
    {
      label: ar.dashboard.accessPoints,
      value: apsCount,
      icon: Wifi,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
    },
    {
      label: ar.dashboard.clients,
      value: clientsCount,
      icon: Users,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
    },
    {
      label: ar.dashboard.activeModules,
      value: activeModules,
      icon: Puzzle,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
  ] as const;

  return (
    <div className="space-y-6">
      {/* العنوان */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.dashboard.title}</h1>
          <p className="text-sm text-muted">{ar.dashboard.subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={fetchData} className="gap-1">
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </Button>
          <LiveIndicator
            connected={connected}
            label={connected ? ar.dashboard.connected : ar.dashboard.disconnected}
          />
        </div>
      </div>

      {/* رسالة الخطأ */}
      {error && (
        <Card className="border-amber-500/30 bg-amber-500/5 p-4">
          <div className="flex items-center gap-3 text-amber-400">
            <AlertTriangle className="h-5 w-5 shrink-0" />
            <div>
              <p className="font-medium">{error}</p>
              <p className="text-xs text-muted mt-1">
                تأكد أن Bettercap يعمل مع: <code>net.recon on</code>
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* معلومات الواجهة */}
      {session?.interface && (
        <Card className="border-primary/30 bg-primary/5 p-4">
          <div className="flex items-center gap-3">
            <Wifi className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm">
                الواجهة: <code className="text-primary font-bold">{session.interface}</code>
              </p>
              {session.gateway && (
                <p className="text-xs text-muted mt-1">
                  البوابة: {getHostIP(session.gateway)} ({session.gateway.vendor || "غير معروف"})
                </p>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* بطاقات KPI */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="hover:border-border-hover transition-colors">
              <div className="flex items-center gap-4">
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${stat.bg}`}>
                  <Icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted">{stat.label}</p>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* الأجهزة المكتشفة */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Monitor className="h-4 w-4 text-primary" />
              الأجهزة المكتشفة ({hostsCount})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {hostsCount > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {hosts.map((host) => (
                  <div
                    key={host.mac}
                    className="flex items-center justify-between rounded-lg border border-border bg-surface-2 px-3 py-2"
                  >
                    <div>
                      <p className="text-sm font-mono ltr-content" dir="ltr">
                        {getHostIP(host)}
                      </p>
                      <p className="text-xs text-muted">
                        {host.hostname || host.alias || host.vendor || "غير معروف"}
                      </p>
                    </div>
                    <code className="text-[10px] text-muted-foreground ltr-content" dir="ltr">
                      {host.mac}
                    </code>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted text-center py-8">
                {loading ? "جارٍ التحميل..." : connected ? "لم يتم اكتشاف أجهزة بعد..." : "غير متصل"}
              </p>
            )}
          </CardContent>
        </Card>

        {/* إجراءات سريعة */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{ar.dashboard.quickActions}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-start gap-2">
              <Radar className="h-4 w-4 text-blue-400" />
              {ar.dashboard.startScan}
            </Button>
            <Button variant="outline" className="w-full justify-start gap-2">
              <Swords className="h-4 w-4 text-red-400" />
              {ar.dashboard.startArpSpoof}
            </Button>
            <Button variant="outline" className="w-full justify-start gap-2">
              <Terminal className="h-4 w-4 text-emerald-400" />
              {ar.dashboard.openTerminal}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* آخر الأحداث */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4 text-primary" />
            {ar.dashboard.recentEvents} ({events.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {events.length > 0 ? (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {events.map((event, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm"
                >
                  <Badge
                    variant={
                      event.tag?.includes("endpoint")
                        ? "success"
                        : event.tag?.includes("wifi")
                        ? "info"
                        : "outline"
                    }
                  >
                    <bdi className="ltr-content text-[10px]">{event.tag}</bdi>
                  </Badge>
                  <span className="flex-1 text-xs text-muted truncate">
                    {JSON.stringify(event.data).slice(0, 60)}...
                  </span>
                  <span className="text-[10px] text-muted-foreground ltr-content" dir="ltr">
                    {new Date(event.time).toLocaleTimeString("en")}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted text-center py-8">
              لا توجد أحداث
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
