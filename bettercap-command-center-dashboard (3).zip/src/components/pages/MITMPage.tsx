"use client";
import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Swords,
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  OctagonX,
  Target,
  Zap,
  Shield,
} from "lucide-react";

type AttackType = "arp.spoof" | "dns.spoof" | "dhcp6.spoof" | "ndp.spoof";

const attackTypes: Array<{ id: AttackType; name: string; description: string; icon: typeof Swords }> = [
  { id: "arp.spoof", name: "ARP Spoofing", description: "اعتراض حركة الشبكة عبر تسميم جداول ARP", icon: Swords },
  { id: "dns.spoof", name: "DNS Spoofing", description: "توجيه طلبات DNS إلى عناوين مزيفة", icon: Target },
  { id: "dhcp6.spoof", name: "DHCPv6 Spoofing", description: "الاستجابة لطلبات DHCPv6 بعناوين مزيفة", icon: Zap },
  { id: "ndp.spoof", name: "NDP Spoofing", description: "اعتراض حركة IPv6 عبر بروتوكول NDP", icon: Shield },
];

export function MITMPage() {
  const { hosts } = useAppStore();
  const [step, setStep] = useState(1);
  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [selectedAttack, setSelectedAttack] = useState<AttackType>("arp.spoof");
  const [fullDuplex, setFullDuplex] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [attacking, setAttacking] = useState(false);

  const toggleTarget = (ip: string) => {
    setSelectedTargets((prev) =>
      prev.includes(ip) ? prev.filter((t) => t !== ip) : [...prev, ip]
    );
  };

  const totalSteps = 4;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.mitm.title}</h1>
          <p className="text-sm text-muted">{ar.mitm.subtitle}</p>
        </div>
        {attacking && (
          <Button
            variant="destructive"
            size="lg"
            className="gap-2 animate-pulse"
            onClick={() => setAttacking(false)}
          >
            <OctagonX className="h-5 w-5" />
            {ar.mitm.panic}
          </Button>
        )}
      </div>

      {/* حالة الهجوم النشط */}
      {attacking && (
        <Card className="border-red-500/30 bg-red-500/5 p-4">
          <div className="flex items-center gap-3">
            <span className="h-3 w-3 rounded-full bg-red-500 animate-pulse-dot" />
            <span className="font-semibold text-red-400">{ar.mitm.attackActive}</span>
            <Badge variant="danger">{selectedAttack}</Badge>
            <span className="text-sm text-muted">
              {selectedTargets.length} هدف
            </span>
          </div>
        </Card>
      )}

      {!attacking && (
        <Card>
          {/* شريط التقدم */}
          <div className="flex items-center justify-between mb-6 px-1">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-colors ${
                    s <= step
                      ? "bg-primary text-white"
                      : "bg-surface-2 text-muted"
                  }`}
                >
                  {s < step ? <CheckCircle2 className="h-4 w-4" /> : s}
                </div>
                <span className={`text-xs ${s <= step ? "text-foreground" : "text-muted"}`}>
                  {s === 1 && ar.mitm.selectTargets}
                  {s === 2 && ar.mitm.selectAttack}
                  {s === 3 && ar.mitm.advancedOptions}
                  {s === 4 && ar.mitm.summary}
                </span>
                {s < 4 && <div className={`h-px w-8 ${s < step ? "bg-primary" : "bg-border"}`} />}
              </div>
            ))}
          </div>

          {/* الخطوة 1: اختيار الأهداف */}
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-sm text-muted mb-4">اختر الأجهزة المستهدفة من الشبكة:</p>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3 max-h-64 overflow-y-auto">
                {hosts.slice(1).map((host) => (
                  <button
                    key={host.ip}
                    onClick={() => toggleTarget(host.ip)}
                    className={`flex items-center gap-3 rounded-lg border p-3 text-right transition-colors cursor-pointer ${
                      selectedTargets.includes(host.ip)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-border-hover"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedTargets.includes(host.ip)}
                      readOnly
                      className="accent-primary"
                    />
                    <div>
                      <bdi className="ltr-content text-sm font-mono">{host.ip}</bdi>
                      <p className="text-[10px] text-muted">{host.hostname} — {host.vendor}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* الخطوة 2: نوع الهجوم */}
          {step === 2 && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {attackTypes.map((atk) => {
                const Icon = atk.icon;
                return (
                  <button
                    key={atk.id}
                    onClick={() => setSelectedAttack(atk.id)}
                    className={`flex items-start gap-3 rounded-xl border p-4 text-right transition-colors cursor-pointer ${
                      selectedAttack === atk.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-border-hover"
                    }`}
                  >
                    <Icon className={`h-5 w-5 shrink-0 ${selectedAttack === atk.id ? "text-primary" : "text-muted"}`} />
                    <div>
                      <bdi className="ltr-content font-semibold text-sm">{atk.name}</bdi>
                      <p className="text-xs text-muted mt-1">{atk.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* الخطوة 3: خيارات متقدمة */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border border-border p-4">
                <div>
                  <p className="text-sm font-medium">{ar.mitm.fullDuplex}</p>
                  <p className="text-xs text-muted">انتحال ثنائي الاتجاه (الهدف والبوابة)</p>
                </div>
                <Switch checked={fullDuplex} onCheckedChange={setFullDuplex} aria-label="Full Duplex" />
              </div>
            </div>
          )}

          {/* الخطوة 4: الملخص */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold text-amber-400 mb-2">{ar.legal.title}</p>
                    <p className="text-xs text-muted leading-relaxed">{ar.legal.warning}</p>
                  </div>
                </div>
              </div>

              <div className="rounded-lg border border-border bg-surface-2 p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted">نوع الهجوم:</span>
                  <Badge variant="danger">{selectedAttack}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted">الأهداف:</span>
                  <span>{selectedTargets.length} جهاز</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted">ثنائي الاتجاه:</span>
                  <span>{fullDuplex ? "نعم" : "لا"}</span>
                </div>
              </div>

              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  className="accent-primary"
                />
                <span className="text-sm text-muted">{ar.legal.checkbox}</span>
              </label>
            </div>
          )}

          {/* أزرار التنقل */}
          <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
            <Button
              variant="outline"
              onClick={() => setStep((s) => Math.max(1, s - 1))}
              disabled={step === 1}
              className="gap-1"
            >
              <ChevronRight className="h-4 w-4" />
              {ar.mitm.previous}
            </Button>

            {step < totalSteps ? (
              <Button
                onClick={() => setStep((s) => Math.min(totalSteps, s + 1))}
                disabled={step === 1 && selectedTargets.length === 0}
                className="gap-1"
              >
                {ar.mitm.next}
                <ChevronLeft className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                variant="destructive"
                onClick={() => setAttacking(true)}
                disabled={!confirmed}
                className="gap-2"
              >
                <Swords className="h-4 w-4" />
                {ar.mitm.launch}
              </Button>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
