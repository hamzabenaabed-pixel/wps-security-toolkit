"use client";
import { useState } from "react";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  FileCode,
  Play,
  Code,
  Package,
  Clock,
} from "lucide-react";

const builtInCaplets = [
  {
    name: "http-ui",
    description: "واجهة ويب لـ Bettercap عبر HTTP",
    content: "set api.rest.address 0.0.0.0\nset api.rest.port 8081\napi.rest on\nset http.server.address 0.0.0.0\nset http.server.port 80\nhttp.server on",
  },
  {
    name: "https-ui",
    description: "واجهة ويب لـ Bettercap عبر HTTPS",
    content: "set api.rest.address 0.0.0.0\nset api.rest.port 8083\napi.rest on\nset https.server.address 0.0.0.0\nset https.server.port 443\nhttps.server on",
  },
  {
    name: "mitm6",
    description: "هجوم MITM6 عبر DHCPv6 و DNS",
    content: "net.recon on\nset dhcp6.spoof.domains *\ndhcp6.spoof on\nset dns.spoof.domains *\ndns.spoof on",
  },
  {
    name: "fb-phish",
    description: "صفحة تصيد Facebook وهمية",
    content: "set http.server.address 0.0.0.0\nset http.server.port 80\nset http.server.path /path/to/phish\nhttp.server on",
  },
  {
    name: "massdeauth",
    description: "إلغاء مصادقة جماعي لكل الشبكات",
    content: "wifi.recon on\nsleep 5\nwifi.deauth *",
  },
  {
    name: "pita",
    description: "Probe Information Tracker and Analyzer",
    content: "set wifi.interface wlan0\nwifi.recon on\nticker on",
  },
];

export function CapletsPage() {
  const [selectedCaplet, setSelectedCaplet] = useState<typeof builtInCaplets[0] | null>(null);
  const [editorContent, setEditorContent] = useState("# كابلت مخصص\n# اكتب أوامر Bettercap هنا\n\nnet.recon on\nnet.probe on\n");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{ar.caplets.title}</h1>
        <p className="text-sm text-muted">{ar.caplets.subtitle}</p>
      </div>

      <Tabs defaultValue="available">
        <TabsList>
          <TabsTrigger value="available">
            <Package className="h-3.5 w-3.5" />
            {ar.caplets.available} ({builtInCaplets.length})
          </TabsTrigger>
          <TabsTrigger value="editor">
            <Code className="h-3.5 w-3.5" />
            {ar.caplets.editor}
          </TabsTrigger>
        </TabsList>

        {/* الكابلتس المتوفرة */}
        <TabsContent value="available">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {builtInCaplets.map((caplet) => (
              <Card key={caplet.name} className="hover:border-border-hover transition-colors flex flex-col">
                <div className="flex items-start gap-3 mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/20">
                    <FileCode className="h-5 w-5 text-amber-400" />
                  </div>
                  <div>
                    <bdi className="ltr-content font-semibold text-sm">{caplet.name}</bdi>
                    <p className="text-xs text-muted mt-0.5">{caplet.description}</p>
                  </div>
                </div>

                <pre className="flex-1 rounded-lg bg-background p-3 text-[10px] font-mono text-muted overflow-x-auto mb-3 ltr-content" dir="ltr">
                  {caplet.content}
                </pre>

                <div className="flex items-center gap-2 pt-3 border-t border-border">
                  <Button variant="default" size="sm" className="gap-1 flex-1">
                    <Play className="h-3 w-3" />
                    {ar.caplets.run}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1"
                    onClick={() => {
                      setSelectedCaplet(caplet);
                      setEditorContent(caplet.content);
                    }}
                  >
                    <Code className="h-3 w-3" />
                    تحرير
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* المحرر */}
        <TabsContent value="editor">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  {selectedCaplet ? (
                    <span className="flex items-center gap-2">
                      تحرير: <bdi className="ltr-content text-primary">{selectedCaplet.name}</bdi>
                    </span>
                  ) : (
                    "كابلت مخصص جديد"
                  )}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {ar.caplets.schedule}
                  </Button>
                  <Button variant="default" size="sm" className="gap-1">
                    <Play className="h-3.5 w-3.5" />
                    {ar.caplets.run}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <textarea
                value={editorContent}
                onChange={(e) => setEditorContent(e.target.value)}
                className="w-full h-96 rounded-lg border border-border bg-background p-4 font-mono text-sm text-emerald-400 resize-none ltr-content"
                dir="ltr"
                spellCheck={false}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
