"use client";
import { useState, useEffect, useCallback } from "react";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Download,
  RefreshCw,
  Monitor,
  AlertTriangle,
} from "lucide-react";

interface NetworkHost {
  ipv4?: string;
  ip?: string;
  mac: string;
  hostname: string;
  alias: string;
  vendor: string;
  first_seen?: string;
  last_seen?: string;
}

function getHostIP(host: NetworkHost): string {
  return host.ipv4 || host.ip || "unknown";
}

function hostsToArray(hostsObj: Record<string, NetworkHost> | NetworkHost[] | undefined): NetworkHost[] {
  if (!hostsObj) return [];
  if (Array.isArray(hostsObj)) return hostsObj;
  return Object.values(hostsObj);
}

export function NetworkPage() {
  const [hosts, setHosts] = useState<NetworkHost[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);

  const fetchHosts = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/bettercap/session");
      if (res.ok) {
        const data = await res.json();
        if (!data.error) {
          const hostsArray = hostsToArray(data.lan?.hosts);
          setHosts(hostsArray);
          setConnected(true);
        } else {
          setConnected(false);
        }
      } else {
        setConnected(false);
      }
    } catch {
      setConnected(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHosts();
    const interval = setInterval(fetchHosts, 5000);
    return () => clearInterval(interval);
  }, [fetchHosts]);

  const filtered = hosts.filter(
    (h) =>
      (h.ipv4 || h.ip || "").includes(search) ||
      h.mac.toLowerCase().includes(search.toLowerCase()) ||
      (h.hostname || "").toLowerCase().includes(search.toLowerCase()) ||
      (h.vendor || "").toLowerCase().includes(search.toLowerCase())
  );

  const exportCSV = () => {
    const csv = [
      ["IP", "MAC", "Hostname", "Vendor", "First Seen", "Last Seen"].join(","),
      ...filtered.map((h) =>
        [getHostIP(h), h.mac, h.hostname || "", h.vendor || "", h.first_seen || "", h.last_seen || ""].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "network-hosts.csv";
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.network.title}</h1>
          <p className="text-sm text-muted">{ar.network.subtitle}</p>
        </div>
        <Badge variant={connected ? "success" : "danger"}>
          {connected ? "متصل" : "غير متصل"}
        </Badge>
      </div>

      {!connected && (
        <Card className="border-amber-500/30 bg-amber-500/5 p-4">
          <div className="flex items-center gap-3 text-amber-400">
            <AlertTriangle className="h-5 w-5" />
            <p>تأكد أن Bettercap يعمل مع <code>net.recon on</code></p>
          </div>
        </Card>
      )}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input
            placeholder={ar.common.search}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={fetchHosts} className="gap-1">
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </Button>
          <Button variant="outline" size="sm" onClick={exportCSV} className="gap-1">
            <Download className="h-3.5 w-3.5" />
            {ar.network.exportCSV}
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-surface-2 text-xs text-muted">
                <th className="px-4 py-3 text-right font-medium">{ar.network.ip}</th>
                <th className="px-4 py-3 text-right font-medium">{ar.network.mac}</th>
                <th className="px-4 py-3 text-right font-medium">{ar.network.hostname}</th>
                <th className="px-4 py-3 text-right font-medium">{ar.network.vendor}</th>
                <th className="px-4 py-3 text-right font-medium">{ar.network.lastSeen}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((host) => (
                <tr
                  key={host.mac}
                  className="border-b border-border hover:bg-surface-2 transition-colors"
                >
                  <td className="px-4 py-3">
                    <bdi className="ltr-content font-mono text-primary">{getHostIP(host)}</bdi>
                  </td>
                  <td className="px-4 py-3">
                    <bdi className="ltr-content font-mono text-xs">{host.mac}</bdi>
                  </td>
                  <td className="px-4 py-3 text-xs">{host.hostname || "—"}</td>
                  <td className="px-4 py-3 text-xs text-muted">{host.vendor || "—"}</td>
                  <td className="px-4 py-3 text-xs text-muted ltr-content" dir="ltr">
                    {host.last_seen ? new Date(host.last_seen).toLocaleTimeString("en") : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <Monitor className="mx-auto h-10 w-10 text-muted mb-3" />
            <p className="text-sm text-muted">
              {loading ? "جارٍ البحث..." : "لم يتم اكتشاف أجهزة"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              شغّل <code>net.recon on</code> في Bettercap
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
