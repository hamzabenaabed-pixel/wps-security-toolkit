"use client";
import { useState } from "react";
import { ar } from "@/lib/i18n/ar";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Eye,
  Play,
  Square,
  Download,
  AlertTriangle,
  Key,
  Filter,
} from "lucide-react";

const bpfExamples = [
  { label: "HTTP فقط", filter: "tcp port 80" },
  { label: "DNS فقط", filter: "udp port 53" },
  { label: "جميع TCP", filter: "tcp" },
  { label: "IP محدد", filter: "host 192.168.1.1" },
  { label: "FTP", filter: "tcp port 21" },
  { label: "SSH", filter: "tcp port 22" },
];

const mockPackets = [
  { time: "14:32:01", src: "192.168.1.5", dst: "8.8.8.8", proto: "DNS", size: 64, info: "Query A google.com" },
  { time: "14:32:02", src: "192.168.1.5", dst: "142.250.180.46", proto: "TCP", size: 66, info: "SYN → 443" },
  { time: "14:32:02", src: "142.250.180.46", dst: "192.168.1.5", proto: "TCP", size: 66, info: "SYN-ACK ← 443" },
  { time: "14:32:03", src: "192.168.1.10", dst: "192.168.1.1", proto: "HTTP", size: 420, info: "GET /login.php" },
  { time: "14:32:04", src: "192.168.1.10", dst: "192.168.1.1", proto: "HTTP", size: 230, info: "POST /login.php (credentials)" },
];

const mockCredentials = [
  { time: "14:32:04", src: "192.168.1.10", protocol: "HTTP", url: "http://example.com/login", username: "admin", password: "pass123" },
  { time: "14:30:15", src: "192.168.1.8", protocol: "FTP", url: "ftp://files.local", username: "user", password: "ftp2024" },
];

export function SnifferPage() {
  const [sniffing, setSniffing] = useState(false);
  const [bpfFilter, setBpfFilter] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{ar.sniffer.title}</h1>
          <p className="text-sm text-muted">{ar.sniffer.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1">
            <Download className="h-3.5 w-3.5" />
            {ar.sniffer.recordPcap}
          </Button>
          <Button
            variant={sniffing ? "destructive" : "success"}
            onClick={() => setSniffing(!sniffing)}
            className="gap-2"
          >
            {sniffing ? <Square className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            {sniffing ? "إيقاف" : "بدء التنصت"}
          </Button>
        </div>
      </div>

      {/* مرشح BPF */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Filter className="h-4 w-4 text-primary" />
            {ar.sniffer.bpfFilter}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={bpfFilter}
            onChange={(e) => setBpfFilter(e.target.value)}
            placeholder="tcp port 80 or udp port 53"
            className="font-mono ltr-content"
            dir="ltr"
          />
          <div className="flex flex-wrap gap-2">
            {bpfExamples.map((ex) => (
              <Button
                key={ex.filter}
                variant="outline"
                size="sm"
                onClick={() => setBpfFilter(ex.filter)}
                className="text-xs gap-1"
              >
                {ex.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="packets">
        <TabsList>
          <TabsTrigger value="packets">
            <Eye className="h-3.5 w-3.5" />
            {ar.sniffer.livePackets}
          </TabsTrigger>
          <TabsTrigger value="credentials">
            <Key className="h-3.5 w-3.5" />
            {ar.sniffer.credentials} ({mockCredentials.length})
          </TabsTrigger>
        </TabsList>

        {/* الحزم المباشرة */}
        <TabsContent value="packets">
          <Card className="overflow-hidden p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-surface-2 text-muted">
                    <th className="px-3 py-2 text-right font-medium">الوقت</th>
                    <th className="px-3 py-2 text-right font-medium">المصدر</th>
                    <th className="px-3 py-2 text-right font-medium">الوجهة</th>
                    <th className="px-3 py-2 text-right font-medium">البروتوكول</th>
                    <th className="px-3 py-2 text-right font-medium">الحجم</th>
                    <th className="px-3 py-2 text-right font-medium">المعلومات</th>
                  </tr>
                </thead>
                <tbody>
                  {mockPackets.map((pkt, i) => (
                    <tr key={i} className="border-b border-border hover:bg-surface-2 transition-colors">
                      <td className="px-3 py-2 font-mono ltr-content" dir="ltr">{pkt.time}</td>
                      <td className="px-3 py-2 font-mono ltr-content text-primary" dir="ltr">{pkt.src}</td>
                      <td className="px-3 py-2 font-mono ltr-content" dir="ltr">{pkt.dst}</td>
                      <td className="px-3 py-2">
                        <Badge variant={pkt.proto === "HTTP" ? "warning" : pkt.proto === "DNS" ? "info" : "outline"}>
                          {pkt.proto}
                        </Badge>
                      </td>
                      <td className="px-3 py-2 ltr-content" dir="ltr">{pkt.size}B</td>
                      <td className="px-3 py-2 font-mono ltr-content text-muted" dir="ltr">{pkt.info}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {/* بيانات الاعتماد */}
        <TabsContent value="credentials">
          {mockCredentials.length > 0 && (
            <Card className="border-amber-500/30 bg-amber-500/5 p-3 mb-4">
              <div className="flex items-center gap-2 text-sm text-amber-400">
                <AlertTriangle className="h-4 w-4" />
                تم اكتشاف {mockCredentials.length} من بيانات الاعتماد
              </div>
            </Card>
          )}
          <div className="space-y-3">
            {mockCredentials.map((cred, i) => (
              <Card key={i} className="border-red-500/20 p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="danger">{cred.protocol}</Badge>
                      <span className="text-xs text-muted ltr-content" dir="ltr">{cred.time}</span>
                    </div>
                    <bdi className="ltr-content text-xs font-mono text-muted block" dir="ltr">{cred.url}</bdi>
                    <div className="flex gap-4 text-sm">
                      <span>المستخدم: <code className="text-primary">{cred.username}</code></span>
                      <span>كلمة المرور: <code className="text-red-400">{cred.password}</code></span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
