"use client";
import { cn } from "@/lib/utils";

interface LiveIndicatorProps {
  connected: boolean;
  label?: string;
  className?: string;
}

export function LiveIndicator({ connected, label, className }: LiveIndicatorProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span
        className={cn(
          "h-2.5 w-2.5 rounded-full",
          connected ? "bg-emerald-500 animate-pulse-dot" : "bg-red-500"
        )}
      />
      {label && <span className="text-xs text-muted">{label}</span>}
    </div>
  );
}
