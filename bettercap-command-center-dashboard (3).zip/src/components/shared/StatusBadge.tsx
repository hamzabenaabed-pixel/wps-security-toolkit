"use client";
import { Badge } from "@/components/ui/badge";

interface StatusBadgeProps {
  running: boolean;
}

export function StatusBadge({ running }: StatusBadgeProps) {
  return (
    <Badge variant={running ? "success" : "outline"}>
      {running && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-dot" />}
      {running ? "نشط" : "متوقف"}
    </Badge>
  );
}
