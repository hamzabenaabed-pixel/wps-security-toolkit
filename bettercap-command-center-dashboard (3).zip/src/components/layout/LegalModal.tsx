"use client";
import { useState, useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Shield } from "lucide-react";

export function LegalModal() {
  const { legalAccepted, setLegalAccepted } = useAppStore();
  const [checked, setChecked] = useState(false);
  const [mounted, setMounted] = useState(false);

  // التحقق من localStorage عند التحميل
  useEffect(() => {
    setMounted(true);
    const accepted = localStorage.getItem("bcc_legal_accepted");
    if (accepted === "true") {
      setLegalAccepted(true);
    }
  }, [setLegalAccepted]);

  const handleAccept = () => {
    localStorage.setItem("bcc_legal_accepted", "true");
    setLegalAccepted(true);
  };

  if (!mounted || legalAccepted) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-lg rounded-2xl border border-border bg-surface p-6 shadow-2xl">
        {/* أيقونة */}
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-500/10 border border-amber-500/20">
          <AlertTriangle className="h-8 w-8 text-amber-400" />
        </div>

        {/* العنوان */}
        <h2 className="mb-3 text-center text-xl font-bold">{ar.legal.title}</h2>

        {/* النص */}
        <p className="mb-6 text-center text-sm leading-relaxed text-muted">
          {ar.legal.warning}
        </p>

        {/* الموافقة */}
        <label className="mb-6 flex items-start gap-3 rounded-lg border border-border bg-surface-2 p-3 cursor-pointer">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            className="mt-0.5 h-4 w-4 rounded border-border accent-primary"
          />
          <span className="text-sm text-muted">{ar.legal.checkbox}</span>
        </label>

        {/* زر القبول */}
        <Button
          onClick={handleAccept}
          disabled={!checked}
          className="w-full"
          size="lg"
        >
          <Shield className="h-4 w-4" />
          {ar.legal.accept}
        </Button>
      </div>
    </div>
  );
}
