"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Puzzle,
  Network,
  Wifi,
  Bluetooth,
  Swords,
  Globe,
  Eye,
  Terminal,
  ScrollText,
  FileCode,
  Settings,
  ChevronRight,
  ChevronLeft,
  Shield,
  Menu,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  badge?: number;
}

const navItems: NavItem[] = [
  { href: "/", label: ar.nav.dashboard, icon: LayoutDashboard },
  { href: "/modules", label: ar.nav.modules, icon: Puzzle },
  { href: "/network", label: ar.nav.network, icon: Network },
  { href: "/wifi", label: ar.nav.wifi, icon: Wifi },
  { href: "/bluetooth", label: ar.nav.bluetooth, icon: Bluetooth },
  { href: "/mitm", label: ar.nav.mitm, icon: Swords },
  { href: "/proxy", label: ar.nav.proxy, icon: Globe },
  { href: "/sniffer", label: ar.nav.sniffer, icon: Eye },
  { href: "/terminal", label: ar.nav.terminal, icon: Terminal },
  { href: "/events", label: ar.nav.events, icon: ScrollText },
  { href: "/caplets", label: ar.nav.caplets, icon: FileCode },
  { href: "/settings", label: ar.nav.settings, icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const { connected, modules } = useAppStore();
  const activeCount = modules.filter((m) => m.running).length;
  
  // الشريط مغلق افتراضياً
  const [isOpen, setIsOpen] = useState(false);

  // حفظ حالة الشريط في localStorage
  useEffect(() => {
    const saved = localStorage.getItem("sidebar_open");
    if (saved === "true") {
      setIsOpen(true);
    }
  }, []);

  const toggleSidebar = () => {
    const newState = !isOpen;
    setIsOpen(newState);
    localStorage.setItem("sidebar_open", String(newState));
  };

  return (
    <aside
      className={cn(
        "fixed top-0 right-0 z-40 flex h-screen flex-col border-l border-border bg-surface transition-all duration-300",
        isOpen ? "w-56" : "w-14"
      )}
    >
      {/* رأس الشريط الجانبي - انقر هنا للفتح/الإغلاق */}
      <button
        onClick={toggleSidebar}
        className="flex h-14 items-center justify-between border-b border-border px-3 hover:bg-surface-2 transition-colors cursor-pointer w-full"
        title={isOpen ? "طي القائمة" : "توسيع القائمة"}
      >
        {isOpen ? (
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-4 w-4 text-white" />
            </div>
            <div className="text-right">
              <h1 className="text-sm font-bold leading-none">BCC</h1>
              <p className="text-[10px] text-muted">مركز القيادة</p>
            </div>
          </div>
        ) : (
          <div className="mx-auto flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Shield className="h-4 w-4 text-white" />
          </div>
        )}
        {isOpen && (
          <ChevronLeft className="h-4 w-4 text-muted" />
        )}
      </button>

      {/* عناصر التنقل */}
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-3">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium transition-all duration-200",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted hover:bg-surface-2 hover:text-foreground",
                !isOpen && "justify-center px-0"
              )}
              title={!isOpen ? item.label : undefined}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {isOpen && <span className="truncate">{item.label}</span>}
              {isOpen && item.href === "/modules" && activeCount > 0 && (
                <span className="mr-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-primary/20 px-1.5 text-[10px] font-bold text-primary">
                  {activeCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* حالة الاتصال */}
      <div className="border-t border-border p-3">
        <div className={cn("flex items-center gap-2", !isOpen && "justify-center")}>
          <span
            className={cn(
              "h-2.5 w-2.5 rounded-full shrink-0",
              connected ? "bg-emerald-500 animate-pulse-dot" : "bg-red-500"
            )}
          />
          {isOpen && (
            <span className="text-xs text-muted">
              {connected ? ar.dashboard.connected : ar.dashboard.disconnected}
            </span>
          )}
        </div>
      </div>
    </aside>
  );
}
