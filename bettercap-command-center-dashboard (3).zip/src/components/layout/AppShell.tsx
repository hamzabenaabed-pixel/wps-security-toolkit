"use client";
import type { ReactNode } from "react";
import { useState, useEffect } from "react";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { CommandPalette } from "./CommandPalette";
import { LegalModal } from "./LegalModal";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // مزامنة مع localStorage
  useEffect(() => {
    const checkSidebar = () => {
      const saved = localStorage.getItem("sidebar_open");
      setSidebarOpen(saved === "true");
    };
    
    checkSidebar();
    window.addEventListener("storage", checkSidebar);
    
    // مراقبة التغييرات
    const interval = setInterval(checkSidebar, 100);
    setTimeout(() => clearInterval(interval), 2000);
    
    return () => {
      window.removeEventListener("storage", checkSidebar);
      clearInterval(interval);
    };
  }, []);

  return (
    <>
      <LegalModal />
      <CommandPalette />
      <Sidebar />
      <div
        className={cn(
          "min-h-screen transition-all duration-300",
          sidebarOpen ? "mr-56" : "mr-14"
        )}
      >
        <Topbar />
        <main className="p-4 lg:p-6">{children}</main>
      </div>
    </>
  );
}
