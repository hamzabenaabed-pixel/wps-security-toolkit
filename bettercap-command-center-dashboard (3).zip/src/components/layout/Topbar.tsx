"use client";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { Button } from "@/components/ui/button";
import {
  Search,
  Bell,
  Sun,
  Moon,
  Smartphone,
} from "lucide-react";
import { useEffect, useState } from "react";

export function Topbar() {
  const { setCommandPaletteOpen, events, connected } = useAppStore();
  const [isDark, setIsDark] = useState(true);
  const recentAlerts = events.filter((e) => e.type.includes("credential") || e.type.includes("new")).slice(0, 5);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? localStorage.getItem("theme") : null;
    if (stored === "light") {
      setIsDark(false);
      document.documentElement.setAttribute("data-theme", "light");
    }
  }, []);

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.setAttribute("data-theme", next ? "dark" : "light");
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-surface/80 backdrop-blur-xl px-4">
      {/* حالة الاتصال بـ NetHunter */}
      <div className="flex items-center gap-2 text-xs">
        <Smartphone className="h-3.5 w-3.5 text-primary" />
        <span className={connected ? "text-emerald-400" : "text-red-400"}>
          {connected ? "متصل بـ Bettercap" : "غير متصل"}
        </span>
      </div>

      {/* الأزرار */}
      <div className="flex items-center gap-2 mr-auto">
        {/* بحث ⌘K */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCommandPaletteOpen(true)}
          className="gap-2 text-muted"
          aria-label={ar.common.openCommandPalette}
        >
          <Search className="h-3.5 w-3.5" />
          <span className="hidden sm:inline text-xs">{ar.common.commandPalette}</span>
          <kbd className="hidden sm:inline-flex h-5 items-center gap-0.5 rounded border border-border bg-surface-2 px-1.5 text-[10px] text-muted-foreground">
            ⌘K
          </kbd>
        </Button>

        {/* تبديل السمة */}
        <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="تبديل السمة">
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>

        {/* الإشعارات */}
        <div className="relative">
          <Button variant="ghost" size="icon" aria-label="الإشعارات">
            <Bell className="h-4 w-4" />
          </Button>
          {recentAlerts.length > 0 && (
            <span className="absolute -top-0.5 -left-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-danger text-[9px] font-bold text-white">
              {recentAlerts.length}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
