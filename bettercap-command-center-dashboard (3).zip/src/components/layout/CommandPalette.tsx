"use client";
import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAppStore } from "@/lib/store";
import { ar } from "@/lib/i18n/ar";
import { cn } from "@/lib/utils";
import {
  Search,
  LayoutDashboard,
  Puzzle,
  Network,
  Wifi,
  Bluetooth,
  Swords,
  Globe,
  Eye,
  Terminal,
  ScrollText,
  FileCode,
  Settings,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface PaletteItem {
  id: string;
  label: string;
  sublabel?: string;
  icon: LucideIcon;
  action: () => void;
  category: string;
}

export function CommandPalette() {
  const router = useRouter();
  const { commandPaletteOpen, setCommandPaletteOpen, modules } = useAppStore();
  const [query, setQuery] = useState("");

  // التنقل بين الصفحات
  const navItems: PaletteItem[] = [
    { id: "nav-dashboard", label: ar.nav.dashboard, icon: LayoutDashboard, action: () => router.push("/"), category: "التنقل" },
    { id: "nav-modules", label: ar.nav.modules, icon: Puzzle, action: () => router.push("/modules"), category: "التنقل" },
    { id: "nav-network", label: ar.nav.network, icon: Network, action: () => router.push("/network"), category: "التنقل" },
    { id: "nav-wifi", label: ar.nav.wifi, icon: Wifi, action: () => router.push("/wifi"), category: "التنقل" },
    { id: "nav-bluetooth", label: ar.nav.bluetooth, icon: Bluetooth, action: () => router.push("/bluetooth"), category: "التنقل" },
    { id: "nav-mitm", label: ar.nav.mitm, icon: Swords, action: () => router.push("/mitm"), category: "التنقل" },
    { id: "nav-proxy", label: ar.nav.proxy, icon: Globe, action: () => router.push("/proxy"), category: "التنقل" },
    { id: "nav-sniffer", label: ar.nav.sniffer, icon: Eye, action: () => router.push("/sniffer"), category: "التنقل" },
    { id: "nav-terminal", label: ar.nav.terminal, icon: Terminal, action: () => router.push("/terminal"), category: "التنقل" },
    { id: "nav-events", label: ar.nav.events, icon: ScrollText, action: () => router.push("/events"), category: "التنقل" },
    { id: "nav-caplets", label: ar.nav.caplets, icon: FileCode, action: () => router.push("/caplets"), category: "التنقل" },
    { id: "nav-settings", label: ar.nav.settings, icon: Settings, action: () => router.push("/settings"), category: "التنقل" },
  ];

  // الوحدات
  const moduleItems: PaletteItem[] = modules.map((m) => ({
    id: `mod-${m.id}`,
    label: m.name,
    sublabel: m.description,
    icon: Puzzle,
    action: () => router.push(`/modules/${encodeURIComponent(m.id)}`),
    category: "الوحدات",
  }));

  const allItems = [...navItems, ...moduleItems];

  const filtered = query.trim()
    ? allItems.filter(
        (item) =>
          item.label.toLowerCase().includes(query.toLowerCase()) ||
          (item.sublabel && item.sublabel.includes(query))
      )
    : allItems.slice(0, 15);

  // اختصار لوحة المفاتيح
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
      }
      if (e.key === "Escape" && commandPaletteOpen) {
        setCommandPaletteOpen(false);
      }
    },
    [commandPaletteOpen, setCommandPaletteOpen]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  if (!commandPaletteOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh]">
      {/* خلفية */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm"
        onClick={() => setCommandPaletteOpen(false)}
      />
      {/* اللوحة */}
      <div className="relative w-full max-w-lg rounded-xl border border-border bg-surface shadow-2xl">
        {/* حقل البحث */}
        <div className="flex items-center gap-3 border-b border-border px-4 py-3">
          <Search className="h-4 w-4 text-muted shrink-0" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن صفحة، وحدة، أو أمر..."
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <button onClick={() => setCommandPaletteOpen(false)} className="text-muted hover:text-foreground cursor-pointer">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* النتائج */}
        <div className="max-h-80 overflow-y-auto p-2">
          {filtered.length === 0 && (
            <p className="py-8 text-center text-sm text-muted">{ar.common.noResults}</p>
          )}
          {(() => {
            const groups: Record<string, PaletteItem[]> = {};
            filtered.forEach((item) => {
              if (!groups[item.category]) groups[item.category] = [];
              groups[item.category].push(item);
            });
            return Object.entries(groups).map(([category, items]) => (
              <div key={category}>
                <p className="px-2 py-1.5 text-[10px] font-semibold uppercase text-muted-foreground">
                  {category}
                </p>
                {items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        item.action();
                        setCommandPaletteOpen(false);
                        setQuery("");
                      }}
                      className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm hover:bg-surface-2 transition-colors text-right cursor-pointer"
                    >
                      <Icon className="h-4 w-4 text-muted shrink-0" />
                      <div className="flex-1 truncate">
                        <bdi className="ltr-content font-medium">{item.label}</bdi>
                        {item.sublabel && (
                          <p className="text-xs text-muted truncate">{item.sublabel}</p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            ));
          })()}
        </div>

        {/* تذييل */}
        <div className="flex items-center gap-4 border-t border-border px-4 py-2 text-[10px] text-muted-foreground">
          <span>↑↓ للتنقل</span>
          <span>↵ للفتح</span>
          <span>ESC للإغلاق</span>
        </div>
      </div>
    </div>
  );
}
