"use client";
import { AppShell } from "@/components/layout/AppShell";
import { SnifferPage } from "@/components/pages/SnifferPage";

export default function Page() {
  return (
    <AppShell>
      <SnifferPage />
    </AppShell>
  );
}
