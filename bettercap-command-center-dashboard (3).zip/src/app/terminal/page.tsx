"use client";
import { AppShell } from "@/components/layout/AppShell";
import { TerminalPage } from "@/components/pages/TerminalPage";

export default function Page() {
  return (
    <AppShell>
      <TerminalPage />
    </AppShell>
  );
}
