"use client";
import { AppShell } from "@/components/layout/AppShell";
import { EventsPage } from "@/components/pages/EventsPage";

export default function Page() {
  return (
    <AppShell>
      <EventsPage />
    </AppShell>
  );
}
