"use client";
import { AppShell } from "@/components/layout/AppShell";
import { SettingsPage } from "@/components/pages/SettingsPage";

export default function Page() {
  return (
    <AppShell>
      <SettingsPage />
    </AppShell>
  );
}
