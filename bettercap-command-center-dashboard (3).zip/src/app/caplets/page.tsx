"use client";
import { AppShell } from "@/components/layout/AppShell";
import { CapletsPage } from "@/components/pages/CapletsPage";

export default function Page() {
  return (
    <AppShell>
      <CapletsPage />
    </AppShell>
  );
}
