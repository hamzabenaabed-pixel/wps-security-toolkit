"use client";
import { AppShell } from "@/components/layout/AppShell";
import { BluetoothPage } from "@/components/pages/BluetoothPage";

export default function Page() {
  return (
    <AppShell>
      <BluetoothPage />
    </AppShell>
  );
}
