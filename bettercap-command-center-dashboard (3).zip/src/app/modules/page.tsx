"use client";
import { AppShell } from "@/components/layout/AppShell";
import { ModulesPage } from "@/components/pages/ModulesPage";

export default function Page() {
  return (
    <AppShell>
      <ModulesPage />
    </AppShell>
  );
}
