"use client";
import { use } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ModuleDetailPage } from "@/components/pages/ModuleDetailPage";

export default function Page({ params }: { params: Promise<{ module: string }> }) {
  const { module } = use(params);
  return (
    <AppShell>
      <ModuleDetailPage moduleId={decodeURIComponent(module)} />
    </AppShell>
  );
}
