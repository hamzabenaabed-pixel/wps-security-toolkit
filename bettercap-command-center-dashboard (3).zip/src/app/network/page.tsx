"use client";
import { AppShell } from "@/components/layout/AppShell";
import { NetworkPage } from "@/components/pages/NetworkPage";

export default function Page() {
  return (
    <AppShell>
      <NetworkPage />
    </AppShell>
  );
}
