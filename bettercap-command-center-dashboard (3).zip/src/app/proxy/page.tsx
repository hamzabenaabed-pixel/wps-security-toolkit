"use client";
import { AppShell } from "@/components/layout/AppShell";
import { ProxyPage } from "@/components/pages/ProxyPage";

export default function Page() {
  return (
    <AppShell>
      <ProxyPage />
    </AppShell>
  );
}
