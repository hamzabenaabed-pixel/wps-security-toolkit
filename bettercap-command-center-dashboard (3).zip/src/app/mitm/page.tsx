"use client";
import { AppShell } from "@/components/layout/AppShell";
import { MITMPage } from "@/components/pages/MITMPage";

export default function Page() {
  return (
    <AppShell>
      <MITMPage />
    </AppShell>
  );
}
