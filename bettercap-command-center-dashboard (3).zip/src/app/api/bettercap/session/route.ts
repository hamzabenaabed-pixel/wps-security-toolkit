import { NextRequest, NextResponse } from "next/server";

const BETTERCAP_URL = process.env.BETTERCAP_API_URL || "http://127.0.0.1:8081";
const BETTERCAP_USER = process.env.BETTERCAP_USERNAME || "user";
const BETTERCAP_PASS = process.env.BETTERCAP_PASSWORD || "pass";

function getAuthHeader(): string {
  const credentials = Buffer.from(`${BETTERCAP_USER}:${BETTERCAP_PASS}`).toString("base64");
  return `Basic ${credentials}`;
}

/**
 * GET /api/bettercap/session
 * جلب حالة الجلسة من Bettercap
 */
export async function GET() {
  try {
    const response = await fetch(`${BETTERCAP_URL}/api/session`, {
      headers: {
        Authorization: getAuthHeader(),
      },
      cache: "no-store",
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: "فشل الاتصال بـ Bettercap", status: response.status },
        { status: response.status }
      );
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: "لا يمكن الاتصال بـ Bettercap API", connected: false },
      { status: 503 }
    );
  }
}

/**
 * POST /api/bettercap/session
 * تنفيذ أمر في Bettercap
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { cmd } = body as { cmd: string };

    if (!cmd) {
      return NextResponse.json({ error: "الأمر مطلوب" }, { status: 400 });
    }

    const response = await fetch(`${BETTERCAP_URL}/api/session`, {
      method: "POST",
      headers: {
        Authorization: getAuthHeader(),
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ cmd }),
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: "فشل تنفيذ الأمر" },
        { status: response.status }
      );
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      { error: "خطأ في الاتصال" },
      { status: 503 }
    );
  }
}
