import { NextResponse } from "next/server";

const BETTERCAP_URL = process.env.BETTERCAP_API_URL || "http://127.0.0.1:8081";
const BETTERCAP_USER = process.env.BETTERCAP_USERNAME || "user";
const BETTERCAP_PASS = process.env.BETTERCAP_PASSWORD || "pass";

function getAuthHeader(): string {
  const credentials = Buffer.from(`${BETTERCAP_USER}:${BETTERCAP_PASS}`).toString("base64");
  return `Basic ${credentials}`;
}

/**
 * GET /api/bettercap/events
 * جلب الأحداث من Bettercap
 */
export async function GET() {
  try {
    const response = await fetch(`${BETTERCAP_URL}/api/events`, {
      headers: {
        Authorization: getAuthHeader(),
      },
      cache: "no-store",
    });

    if (!response.ok) {
      return NextResponse.json([], { status: response.status });
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch {
    return NextResponse.json([]);
  }
}
