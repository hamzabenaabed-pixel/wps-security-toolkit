"use client";
import { AppShell } from "@/components/layout/AppShell";
import { WiFiPage } from "@/components/pages/WiFiPage";

export default function Page() {
  return (
    <AppShell>
      <WiFiPage />
    </AppShell>
  );
}
