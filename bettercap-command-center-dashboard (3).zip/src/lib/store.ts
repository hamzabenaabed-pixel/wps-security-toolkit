/** مخزن Zustand لحالة التطبيق */
import { create } from "zustand";
import type { BettercapModule, NetworkHost, WiFiAccessPoint, WiFiClient, BLEDevice, BettercapEvent, TrafficDataPoint } from "./bettercap/types";
import { BETTERCAP_MODULES } from "./bettercap/modules";

// ═══════ بيانات وهمية للمعاينة ═══════
function generateMockHosts(): NetworkHost[] {
  const vendors = ["Apple", "Samsung", "Dell", "Intel", "Cisco", "TP-Link", "Huawei", "Xiaomi", "Google", "Microsoft"];
  const oses = ["macOS 15", "Windows 11", "Linux", "Android 15", "iOS 18", "ChromeOS", "Unknown"];
  const hosts: NetworkHost[] = [];
  for (let i = 1; i <= 18; i++) {
    const h = Math.floor(Math.random() * 256);
    hosts.push({
      ip: `192.168.1.${i}`,
      mac: `${h.toString(16).padStart(2, "0")}:${Math.floor(Math.random() * 256).toString(16).padStart(2, "0")}:${Math.floor(Math.random() * 256).toString(16).padStart(2, "0")}:${Math.floor(Math.random() * 256).toString(16).padStart(2, "0")}:${Math.floor(Math.random() * 256).toString(16).padStart(2, "0")}:${Math.floor(Math.random() * 256).toString(16).padStart(2, "0")}`.toUpperCase(),
      hostname: i === 1 ? "gateway" : `device-${i}`,
      vendor: vendors[i % vendors.length],
      os: oses[i % oses.length],
      ports: i === 1 ? [80, 443, 53] : i % 3 === 0 ? [22, 80] : [],
      firstSeen: new Date(Date.now() - Math.random() * 86400000 * 7).toISOString(),
      lastSeen: new Date(Date.now() - Math.random() * 60000).toISOString(),
    });
  }
  return hosts;
}

function generateMockAPs(): WiFiAccessPoint[] {
  const ssids = ["HomeNetwork", "CafeWiFi", "STARBUCKS", "AndroidAP", "Office-5G", "FreeWiFi", "Neighbor_Net", "IoT-Network"];
  return ssids.map((ssid, i) => ({
    ssid,
    bssid: `AA:BB:CC:${i.toString(16).padStart(2, "0")}:${(i + 10).toString(16).padStart(2, "0")}:FF`.toUpperCase(),
    channel: [1, 6, 11, 36, 40, 44, 48, 149][i % 8],
    rssi: -30 - Math.floor(Math.random() * 60),
    encryption: ["WPA2", "WPA3", "WPA2", "Open", "WPA2", "Open", "WEP", "WPA2"][i],
    wps: i % 3 === 0,
    clientsCount: Math.floor(Math.random() * 10),
    firstSeen: new Date(Date.now() - Math.random() * 86400000).toISOString(),
    lastSeen: new Date(Date.now() - Math.random() * 60000).toISOString(),
    handshake: i < 3,
  }));
}

function generateMockEvents(): BettercapEvent[] {
  const types = ["session.started", "endpoint.new", "endpoint.lost", "wifi.ap.new", "wifi.client.new", "mod.started", "mod.stopped", "net.sniff.credentials", "sys.log"];
  return Array.from({ length: 25 }, (_, i) => ({
    id: `evt-${i}`,
    type: types[i % types.length],
    time: new Date(Date.now() - i * 30000).toISOString(),
    data: { message: `حدث تجريبي رقم ${i + 1}` },
    tag: types[i % types.length].split(".")[0],
  }));
}

function generateTrafficData(): TrafficDataPoint[] {
  return Array.from({ length: 30 }, (_, i) => ({
    time: new Date(Date.now() - (29 - i) * 2000).toISOString().slice(11, 19),
    sent: Math.floor(Math.random() * 500) + 50,
    received: Math.floor(Math.random() * 800) + 100,
  }));
}

// ═══════ أنواع المخزن ═══════
interface AppState {
  // حالة الاتصال
  connected: boolean;
  apiUrl: string;
  sidebarOpen: boolean;
  commandPaletteOpen: boolean;
  legalAccepted: boolean;

  // البيانات
  modules: BettercapModule[];
  hosts: NetworkHost[];
  wifiAPs: WiFiAccessPoint[];
  wifiClients: WiFiClient[];
  bleDevices: BLEDevice[];
  events: BettercapEvent[];
  trafficData: TrafficDataPoint[];
  terminalHistory: string[];

  // إجراءات
  setSidebarOpen: (open: boolean) => void;
  setCommandPaletteOpen: (open: boolean) => void;
  setLegalAccepted: (accepted: boolean) => void;
  toggleModule: (id: string) => void;
  setModuleParameter: (moduleId: string, paramName: string, value: string) => void;
  addEvent: (event: BettercapEvent) => void;
  addTerminalCommand: (cmd: string) => void;
  updateTrafficData: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  connected: true,
  apiUrl: "http://127.0.0.1:8081",
  sidebarOpen: true,
  commandPaletteOpen: false,
  legalAccepted: false,

  modules: BETTERCAP_MODULES,
  hosts: generateMockHosts(),
  wifiAPs: generateMockAPs(),
  wifiClients: [],
  bleDevices: [],
  events: generateMockEvents(),
  trafficData: generateTrafficData(),
  terminalHistory: [],

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),
  setLegalAccepted: (accepted) => set({ legalAccepted: accepted }),

  toggleModule: (id) =>
    set((state) => ({
      modules: state.modules.map((m) =>
        m.id === id ? { ...m, running: !m.running } : m
      ),
    })),

  setModuleParameter: (moduleId, paramName, value) =>
    set((state) => ({
      modules: state.modules.map((m) =>
        m.id === moduleId
          ? {
              ...m,
              parameters: m.parameters.map((p) =>
                p.name === paramName ? { ...p, defaultValue: value } : p
              ),
            }
          : m
      ),
    })),

  addEvent: (event) =>
    set((state) => ({
      events: [event, ...state.events].slice(0, 200),
    })),

  addTerminalCommand: (cmd) =>
    set((state) => ({
      terminalHistory: [...state.terminalHistory, cmd],
    })),

  updateTrafficData: () =>
    set((state) => ({
      trafficData: [
        ...state.trafficData.slice(1),
        {
          time: new Date().toISOString().slice(11, 19),
          sent: Math.floor(Math.random() * 500) + 50,
          received: Math.floor(Math.random() * 800) + 100,
        },
      ],
    })),
}));
