/** قاعدة بيانات جميع وحدات Bettercap مع الوصف العربي */
import type { BettercapModule } from "./types";

export const BETTERCAP_MODULES: BettercapModule[] = [
  // ═══════════════════════════════════════════
  // 🔧 Core Modules
  // ═══════════════════════════════════════════
  {
    id: "events.stream",
    name: "events.stream",
    description: "سجل الأحداث — يعرض ويسجل جميع الأحداث والسجلات في الجلسة الحالية",
    category: "core",
    icon: "ScrollText",
    running: false,
    parameters: [
      { name: "events.stream.output", type: "filepath", defaultValue: "", description: "ملف حفظ الأحداث (اتركه فارغاً لعدم الحفظ)" },
      { name: "events.stream.output.rotate", type: "bool", defaultValue: "true", description: "تفعيل دوران ملف السجل" },
      { name: "events.stream.output.rotate.how", type: "enum", defaultValue: "size", description: "طريقة دوران الملف", options: ["size", "time"] },
      { name: "events.stream.output.rotate.when", type: "string", defaultValue: "10485760", description: "حد الدوران (حجم بالبايت أو مدة)" },
      { name: "events.stream.output.rotate.format", type: "string", defaultValue: "2006-01-02T15:04:05", description: "تنسيق اسم الملف المُدوَّر" },
      { name: "events.stream.output.rotate.compress", type: "bool", defaultValue: "true", description: "ضغط ملفات السجل المُدوَّرة" },
      { name: "events.stream.time.format", type: "string", defaultValue: "15:04:05", description: "تنسيق الوقت في السجل" },
      { name: "events.stream.http.request.dump", type: "bool", defaultValue: "false", description: "عرض محتوى طلبات HTTP الكامل" },
      { name: "events.stream.http.response.dump", type: "bool", defaultValue: "false", description: "عرض محتوى استجابات HTTP الكامل" },
    ],
    commands: [
      { command: "events.stream on", description: "تشغيل بث الأحداث" },
      { command: "events.stream off", description: "إيقاف بث الأحداث" },
      { command: "events.show", description: "عرض الأحداث المخزنة", example: "events.show 20" },
      { command: "events.clear", description: "مسح جميع الأحداث" },
      { command: "events.waitfor", description: "الانتظار حتى وقوع حدث معين", example: "events.waitfor wifi.ap.new" },
    ],
  },
  {
    id: "ticker",
    name: "ticker",
    description: "مؤقت التنفيذ الدوري — ينفذ أوامر محددة بشكل متكرر كل فترة زمنية",
    category: "core",
    icon: "Timer",
    running: false,
    parameters: [
      { name: "ticker.period", type: "int", defaultValue: "1", description: "الفترة بين كل تنفيذ (بالثواني)" },
      { name: "ticker.commands", type: "string", defaultValue: "clear; net.show", description: "الأوامر المراد تنفيذها (مفصولة بفاصلة منقوطة)" },
    ],
    commands: [
      { command: "ticker on", description: "تشغيل المؤقت" },
      { command: "ticker off", description: "إيقاف المؤقت" },
    ],
  },
  {
    id: "mac.changer",
    name: "mac.changer",
    description: "مُغيِّر عنوان MAC — يغير العنوان الفيزيائي لواجهة الشبكة",
    category: "core",
    icon: "Shuffle",
    running: false,
    parameters: [
      { name: "mac.changer.iface", type: "string", defaultValue: "", description: "واجهة الشبكة المراد تغيير عنوانها" },
      { name: "mac.changer.address", type: "string", defaultValue: "random", description: "العنوان الجديد (أو random لعنوان عشوائي)" },
    ],
    commands: [
      { command: "mac.changer on", description: "تشغيل مُغيِّر MAC" },
      { command: "mac.changer off", description: "إيقاف مُغيِّر MAC واستعادة العنوان الأصلي" },
    ],
  },
  {
    id: "gps",
    name: "gps",
    description: "نظام تحديد المواقع — يقرأ إحداثيات GPS من جهاز متصل",
    category: "core",
    icon: "MapPin",
    running: false,
    parameters: [
      { name: "gps.device", type: "filepath", defaultValue: "/dev/ttyUSB0", description: "مسار جهاز GPS المتسلسل" },
      { name: "gps.baud_rate", type: "int", defaultValue: "4800", description: "معدل البود للاتصال التسلسلي" },
    ],
    commands: [
      { command: "gps on", description: "تشغيل قراءة GPS" },
      { command: "gps off", description: "إيقاف قراءة GPS" },
      { command: "gps.show", description: "عرض الإحداثيات الحالية" },
    ],
  },
  {
    id: "any.proxy",
    name: "any.proxy",
    description: "بروكسي عام — يحوِّل أي حركة TCP/UDP إلى عنوان ومنفذ آخر",
    category: "core",
    icon: "ArrowRightLeft",
    running: false,
    parameters: [
      { name: "any.proxy.iface", type: "string", defaultValue: "", description: "واجهة الشبكة" },
      { name: "any.proxy.protocol", type: "enum", defaultValue: "TCP", description: "البروتوكول", options: ["TCP", "UDP"] },
      { name: "any.proxy.src_address", type: "string", defaultValue: "", description: "عنوان المصدر للاستماع" },
      { name: "any.proxy.src_port", type: "int", defaultValue: "8080", description: "منفذ المصدر" },
      { name: "any.proxy.dst_address", type: "string", defaultValue: "", description: "عنوان الوجهة" },
      { name: "any.proxy.dst_port", type: "int", defaultValue: "80", description: "منفذ الوجهة" },
    ],
    commands: [
      { command: "any.proxy on", description: "تشغيل البروكسي العام" },
      { command: "any.proxy off", description: "إيقاف البروكسي العام" },
    ],
  },
  {
    id: "syn.scan",
    name: "syn.scan",
    description: "ماسح المنافذ SYN — يفحص المنافذ المفتوحة على الأهداف باستخدام حزم SYN",
    category: "core",
    icon: "Radar",
    running: false,
    parameters: [
      { name: "syn.scan.show-progress", type: "bool", defaultValue: "false", description: "عرض تقدم عملية المسح" },
    ],
    commands: [
      { command: "syn.scan", description: "مسح هدف محدد", example: "syn.scan 192.168.1.1 1-1024" },
    ],
  },
  {
    id: "update",
    name: "update",
    description: "التحديثات — يتحقق تلقائياً من وجود إصدارات جديدة",
    category: "core",
    icon: "RefreshCw",
    running: false,
    parameters: [
      { name: "update.check.enabled", type: "bool", defaultValue: "true", description: "تفعيل التحقق التلقائي من التحديثات" },
      { name: "update.check.interval", type: "int", defaultValue: "6", description: "فترة التحقق (بالساعات)" },
    ],
    commands: [
      { command: "update.check", description: "التحقق من التحديثات الآن" },
    ],
  },

  // ═══════════════════════════════════════════
  // 🌐 Network Modules
  // ═══════════════════════════════════════════
  {
    id: "net.recon",
    name: "net.recon",
    description: "اكتشاف ARP — يكتشف الأجهزة على الشبكة المحلية عبر مراقبة حزم ARP",
    category: "network",
    icon: "Network",
    running: true,
    parameters: [
      { name: "net.show.meta", type: "bool", defaultValue: "false", description: "عرض البيانات الوصفية للأجهزة" },
      { name: "net.show.filter", type: "string", defaultValue: "", description: "تصفية الأجهزة المعروضة" },
      { name: "net.show.sort", type: "string", defaultValue: "ip asc", description: "ترتيب الأجهزة (ip/mac/seen/sent/rcvd + asc/desc)" },
      { name: "net.show.limit", type: "int", defaultValue: "0", description: "الحد الأقصى للأجهزة المعروضة (0 = بلا حد)" },
    ],
    commands: [
      { command: "net.recon on", description: "تشغيل اكتشاف الشبكة" },
      { command: "net.recon off", description: "إيقاف اكتشاف الشبكة" },
      { command: "net.show", description: "عرض قائمة الأجهزة المكتشفة" },
      { command: "net.clear", description: "مسح قائمة الأجهزة" },
    ],
  },
  {
    id: "net.probe",
    name: "net.probe",
    description: "الاستكشاف النشط — يرسل حزم استكشاف mDNS/NBNS/UPNP/WSD لاكتشاف أجهزة إضافية",
    category: "network",
    icon: "Search",
    running: false,
    parameters: [
      { name: "net.probe.mdns", type: "bool", defaultValue: "true", description: "إرسال استعلامات mDNS" },
      { name: "net.probe.nbns", type: "bool", defaultValue: "true", description: "إرسال استعلامات NBNS" },
      { name: "net.probe.upnp", type: "bool", defaultValue: "true", description: "إرسال استعلامات UPnP" },
      { name: "net.probe.wsd", type: "bool", defaultValue: "true", description: "إرسال استعلامات WSD" },
      { name: "net.probe.throttle", type: "int", defaultValue: "10", description: "التأخير بين الحزم (بالمللي ثانية)" },
    ],
    commands: [
      { command: "net.probe on", description: "تشغيل الاستكشاف النشط" },
      { command: "net.probe off", description: "إيقاف الاستكشاف النشط" },
    ],
  },
  {
    id: "net.sniff",
    name: "net.sniff",
    description: "التنصت على الشبكة — يلتقط ويحلل حزم الشبكة بشكل مباشر",
    category: "network",
    icon: "Eye",
    running: false,
    parameters: [
      { name: "net.sniff.verbose", type: "bool", defaultValue: "true", description: "عرض تفاصيل إضافية للحزم" },
      { name: "net.sniff.local", type: "bool", defaultValue: "false", description: "التقاط الحزم المحلية أيضاً" },
      { name: "net.sniff.filter", type: "string", defaultValue: "", description: "مرشح BPF للحزم" },
      { name: "net.sniff.regexp", type: "string", defaultValue: "", description: "تعبير نمطي لتصفية المحتوى" },
      { name: "net.sniff.output", type: "filepath", defaultValue: "", description: "ملف حفظ الحزم (pcap)" },
      { name: "net.sniff.source", type: "filepath", defaultValue: "", description: "قراءة من ملف pcap بدلاً من الشبكة" },
    ],
    commands: [
      { command: "net.sniff on", description: "تشغيل التنصت" },
      { command: "net.sniff off", description: "إيقاف التنصت" },
    ],
  },
  {
    id: "net.fuzz",
    name: "net.fuzz",
    description: "إرسال حزم مشوهة — يرسل حزم عشوائية مُعدَّلة لاختبار استقرار الأجهزة",
    category: "network",
    icon: "Zap",
    running: false,
    parameters: [
      { name: "net.fuzz.silent", type: "bool", defaultValue: "false", description: "عدم عرض سجل الحزم المرسلة" },
      { name: "net.fuzz.rate", type: "float", defaultValue: "0.2", description: "نسبة تشويه الحزم (0.0 - 1.0)" },
      { name: "net.fuzz.layers", type: "string", defaultValue: "", description: "طبقات الشبكة المستهدفة" },
      { name: "net.fuzz.filter", type: "string", defaultValue: "", description: "مرشح BPF للحزم المراد تشويهها" },
    ],
    commands: [
      { command: "net.fuzz on", description: "تشغيل إرسال الحزم المشوهة" },
      { command: "net.fuzz off", description: "إيقاف إرسال الحزم المشوهة" },
    ],
  },
  {
    id: "zerogod",
    name: "zerogod",
    description: "مستكشف mDNS/DNS-SD — يكتشف ويحلل خدمات الشبكة المحلية",
    category: "network",
    icon: "Globe",
    running: false,
    parameters: [
      { name: "zerogod.verbose", type: "bool", defaultValue: "false", description: "عرض معلومات تفصيلية" },
      { name: "zerogod.ignore", type: "string", defaultValue: "", description: "تجاهل خدمات معينة" },
      { name: "zerogod.advertise.directory", type: "filepath", defaultValue: "", description: "مجلد الإعلان عن الخدمات" },
    ],
    commands: [
      { command: "zerogod on", description: "تشغيل مستكشف mDNS" },
      { command: "zerogod off", description: "إيقاف مستكشف mDNS" },
      { command: "zerogod.show", description: "عرض الخدمات المكتشفة" },
    ],
  },

  // ═══════════════════════════════════════════
  // ⚔️ Spoofing Modules
  // ═══════════════════════════════════════════
  {
    id: "arp.spoof",
    name: "arp.spoof",
    description: "انتحال ARP — يعترض حركة الشبكة عبر تسميم جداول ARP",
    category: "spoofing",
    icon: "Swords",
    running: false,
    parameters: [
      { name: "arp.spoof.targets", type: "string", defaultValue: "", description: "عناوين IP المستهدفة (مفصولة بفاصلة)" },
      { name: "arp.spoof.whitelist", type: "string", defaultValue: "", description: "عناوين IP المستثناة" },
      { name: "arp.spoof.internal", type: "bool", defaultValue: "false", description: "تفعيل الانتحال الداخلي بين الأهداف" },
      { name: "arp.spoof.fullduplex", type: "bool", defaultValue: "false", description: "انتحال ثنائي الاتجاه (الهدف والبوابة)" },
      { name: "arp.spoof.skip_restore", type: "bool", defaultValue: "false", description: "عدم استعادة جداول ARP عند الإيقاف" },
    ],
    commands: [
      { command: "arp.spoof on", description: "تشغيل انتحال ARP" },
      { command: "arp.spoof off", description: "إيقاف انتحال ARP واستعادة الجداول" },
    ],
  },
  {
    id: "dhcp6.spoof",
    name: "dhcp6.spoof",
    description: "انتحال DHCPv6 — يستجيب لطلبات DHCPv6 بعناوين مزيفة",
    category: "spoofing",
    icon: "ServerCrash",
    running: false,
    parameters: [
      { name: "dhcp6.spoof.domains", type: "string", defaultValue: "*", description: "النطاقات المستهدفة (مفصولة بفاصلة)" },
      { name: "dhcp6.spoof.address", type: "string", defaultValue: "", description: "عنوان IPv6 المزيف للاستجابة" },
    ],
    commands: [
      { command: "dhcp6.spoof on", description: "تشغيل انتحال DHCPv6" },
      { command: "dhcp6.spoof off", description: "إيقاف انتحال DHCPv6" },
    ],
  },
  {
    id: "dns.spoof",
    name: "dns.spoof",
    description: "انتحال DNS — يعترض طلبات DNS ويستجيب بعناوين مزيفة",
    category: "spoofing",
    icon: "Globe",
    running: false,
    parameters: [
      { name: "dns.spoof.hosts", type: "filepath", defaultValue: "", description: "ملف hosts مخصص للانتحال" },
      { name: "dns.spoof.domains", type: "string", defaultValue: "*", description: "النطاقات المستهدفة" },
      { name: "dns.spoof.address", type: "string", defaultValue: "", description: "عنوان IP للاستجابة المزيفة" },
      { name: "dns.spoof.all", type: "bool", defaultValue: "false", description: "انتحال جميع الطلبات بغض النظر عن المصدر" },
      { name: "dns.spoof.ttl", type: "int", defaultValue: "1024", description: "مدة بقاء السجل في الذاكرة المؤقتة" },
    ],
    commands: [
      { command: "dns.spoof on", description: "تشغيل انتحال DNS" },
      { command: "dns.spoof off", description: "إيقاف انتحال DNS" },
    ],
  },
  {
    id: "ndp.spoof",
    name: "ndp.spoof",
    description: "انتحال NDP — يعترض حركة IPv6 عبر تسميم بروتوكول اكتشاف الجيران",
    category: "spoofing",
    icon: "Shield",
    running: false,
    parameters: [
      { name: "ndp.spoof.targets", type: "string", defaultValue: "", description: "عناوين IPv6 المستهدفة" },
      { name: "ndp.spoof.whitelist", type: "string", defaultValue: "", description: "عناوين IPv6 المستثناة" },
      { name: "ndp.spoof.neighbour", type: "bool", defaultValue: "true", description: "انتحال إعلانات الجيران" },
      { name: "ndp.spoof.router", type: "bool", defaultValue: "true", description: "انتحال إعلانات الموجه" },
    ],
    commands: [
      { command: "ndp.spoof on", description: "تشغيل انتحال NDP" },
      { command: "ndp.spoof off", description: "إيقاف انتحال NDP" },
    ],
  },
  {
    id: "fw.rule",
    name: "fw.rule",
    description: "قواعد جدار الحماية — ينفذ أوامر iptables لتوجيه حركة الشبكة",
    category: "spoofing",
    icon: "ShieldCheck",
    running: false,
    parameters: [],
    commands: [
      { command: "fw.rule", description: "إضافة قاعدة iptables", example: "fw.rule nat PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8080" },
    ],
  },

  // ═══════════════════════════════════════════
  // 🔐 HTTP/HTTPS Modules
  // ═══════════════════════════════════════════
  {
    id: "http.proxy",
    name: "http.proxy",
    description: "بروكسي HTTP — يعترض ويعدل طلبات HTTP غير المشفرة",
    category: "http",
    icon: "Globe",
    running: false,
    parameters: [
      { name: "http.proxy.address", type: "string", defaultValue: "0.0.0.0", description: "عنوان الاستماع" },
      { name: "http.proxy.port", type: "int", defaultValue: "8080", description: "منفذ البروكسي" },
      { name: "http.proxy.redirect", type: "bool", defaultValue: "true", description: "تحويل حركة HTTP تلقائياً" },
      { name: "http.proxy.script", type: "filepath", defaultValue: "", description: "سكربت JavaScript للتعديل" },
      { name: "http.proxy.injectjs", type: "string", defaultValue: "", description: "كود JavaScript للحقن في الصفحات" },
      { name: "http.proxy.blacklist", type: "string", defaultValue: "", description: "قائمة المواقع المحظورة" },
      { name: "http.proxy.whitelist", type: "string", defaultValue: "", description: "قائمة المواقع المسموحة فقط" },
      { name: "http.proxy.sslstrip", type: "bool", defaultValue: "false", description: "تفعيل SSL Strip لتخفيض HTTPS" },
    ],
    commands: [
      { command: "http.proxy on", description: "تشغيل بروكسي HTTP" },
      { command: "http.proxy off", description: "إيقاف بروكسي HTTP" },
    ],
  },
  {
    id: "https.proxy",
    name: "https.proxy",
    description: "بروكسي HTTPS — يعترض حركة HTTPS المشفرة باستخدام شهادة CA مخصصة",
    category: "http",
    icon: "Lock",
    running: false,
    parameters: [
      { name: "https.proxy.address", type: "string", defaultValue: "0.0.0.0", description: "عنوان الاستماع" },
      { name: "https.proxy.port", type: "int", defaultValue: "8083", description: "منفذ البروكسي" },
      { name: "https.proxy.redirect", type: "bool", defaultValue: "true", description: "تحويل حركة HTTPS تلقائياً" },
      { name: "https.proxy.certificate", type: "filepath", defaultValue: "", description: "مسار شهادة CA" },
      { name: "https.proxy.key", type: "filepath", defaultValue: "", description: "مسار المفتاح الخاص" },
      { name: "https.proxy.script", type: "filepath", defaultValue: "", description: "سكربت JavaScript للتعديل" },
      { name: "https.proxy.injectjs", type: "string", defaultValue: "", description: "كود JavaScript للحقن" },
      { name: "https.proxy.blacklist", type: "string", defaultValue: "", description: "قائمة المواقع المحظورة" },
      { name: "https.proxy.whitelist", type: "string", defaultValue: "", description: "قائمة المواقع المسموحة فقط" },
      { name: "https.proxy.sslstrip", type: "bool", defaultValue: "false", description: "تفعيل SSL Strip" },
    ],
    commands: [
      { command: "https.proxy on", description: "تشغيل بروكسي HTTPS" },
      { command: "https.proxy off", description: "إيقاف بروكسي HTTPS" },
    ],
  },
  {
    id: "http.server",
    name: "http.server",
    description: "خادم HTTP — يقدم ملفات ثابتة عبر HTTP",
    category: "http",
    icon: "Server",
    running: false,
    parameters: [
      { name: "http.server.address", type: "string", defaultValue: "0.0.0.0", description: "عنوان الاستماع" },
      { name: "http.server.port", type: "int", defaultValue: "80", description: "منفذ الخادم" },
      { name: "http.server.path", type: "filepath", defaultValue: ".", description: "مسار المجلد المراد تقديمه" },
    ],
    commands: [
      { command: "http.server on", description: "تشغيل خادم HTTP" },
      { command: "http.server off", description: "إيقاف خادم HTTP" },
    ],
  },
  {
    id: "https.server",
    name: "https.server",
    description: "خادم HTTPS — يقدم ملفات ثابتة عبر اتصال مشفر",
    category: "http",
    icon: "ShieldCheck",
    running: false,
    parameters: [
      { name: "https.server.address", type: "string", defaultValue: "0.0.0.0", description: "عنوان الاستماع" },
      { name: "https.server.port", type: "int", defaultValue: "443", description: "منفذ الخادم" },
      { name: "https.server.path", type: "filepath", defaultValue: ".", description: "مسار المجلد المراد تقديمه" },
      { name: "https.server.certificate", type: "filepath", defaultValue: "", description: "مسار شهادة SSL" },
      { name: "https.server.key", type: "filepath", defaultValue: "", description: "مسار المفتاح الخاص" },
    ],
    commands: [
      { command: "https.server on", description: "تشغيل خادم HTTPS" },
      { command: "https.server off", description: "إيقاف خادم HTTPS" },
    ],
  },
  {
    id: "rest.api",
    name: "rest.api",
    description: "واجهة REST API — توفر واجهة برمجية للتحكم عن بُعد",
    category: "http",
    icon: "Code",
    running: true,
    parameters: [
      { name: "api.rest.address", type: "string", defaultValue: "127.0.0.1", description: "عنوان الاستماع" },
      { name: "api.rest.port", type: "int", defaultValue: "8081", description: "منفذ API" },
      { name: "api.rest.alloworigin", type: "string", defaultValue: "*", description: "عناوين CORS المسموحة" },
      { name: "api.rest.username", type: "string", defaultValue: "user", description: "اسم المستخدم للمصادقة" },
      { name: "api.rest.password", type: "string", defaultValue: "pass", description: "كلمة مرور المصادقة" },
      { name: "api.rest.certificate", type: "filepath", defaultValue: "", description: "مسار شهادة SSL" },
      { name: "api.rest.key", type: "filepath", defaultValue: "", description: "مسار المفتاح الخاص" },
      { name: "api.rest.websocket", type: "bool", defaultValue: "false", description: "تفعيل WebSocket" },
      { name: "api.rest.record", type: "bool", defaultValue: "false", description: "تسجيل الأوامر والأحداث" },
      { name: "api.rest.replay", type: "bool", defaultValue: "false", description: "وضع إعادة التشغيل" },
    ],
    commands: [
      { command: "api.rest on", description: "تشغيل واجهة REST API" },
      { command: "api.rest off", description: "إيقاف واجهة REST API" },
    ],
  },

  // ═══════════════════════════════════════════
  // 📶 WiFi Modules
  // ═══════════════════════════════════════════
  {
    id: "wifi.recon",
    name: "wifi.recon",
    description: "استطلاع الواي فاي — يكتشف نقاط الوصول والعملاء القريبة",
    category: "wifi",
    icon: "Wifi",
    running: false,
    parameters: [
      { name: "wifi.interface", type: "string", defaultValue: "", description: "واجهة الواي فاي (وضع المراقبة)" },
      { name: "wifi.source.file", type: "filepath", defaultValue: "", description: "قراءة من ملف pcap بدلاً من المباشر" },
      { name: "wifi.hop.period", type: "int", defaultValue: "250", description: "فترة تغيير القناة (مللي ثانية)" },
      { name: "wifi.channel", type: "string", defaultValue: "", description: "قناة محددة أو قائمة قنوات" },
      { name: "wifi.region", type: "string", defaultValue: "", description: "منطقة الترددات التنظيمية" },
      { name: "wifi.txpower", type: "int", defaultValue: "30", description: "قوة الإرسال (dBm)" },
      { name: "wifi.rssi.min", type: "int", defaultValue: "-200", description: "الحد الأدنى لقوة الإشارة" },
      { name: "wifi.show.sort", type: "string", defaultValue: "rssi asc", description: "ترتيب العرض" },
      { name: "wifi.show.limit", type: "int", defaultValue: "0", description: "حد العرض" },
      { name: "wifi.show.filter", type: "string", defaultValue: "", description: "مرشح العرض" },
      { name: "wifi.skip-broken", type: "bool", defaultValue: "true", description: "تجاوز الحزم التالفة" },
    ],
    commands: [
      { command: "wifi.recon on", description: "تشغيل استطلاع الواي فاي" },
      { command: "wifi.recon off", description: "إيقاف الاستطلاع" },
      { command: "wifi.show", description: "عرض نقاط الوصول المكتشفة" },
      { command: "wifi.recon.channel", description: "تغيير القناة", example: "wifi.recon.channel 6" },
    ],
  },
  {
    id: "wifi.ap",
    name: "wifi.ap",
    description: "نقطة وصول وهمية — يُنشئ نقطة وصول WiFi مزيفة",
    category: "wifi",
    icon: "Router",
    running: false,
    parameters: [
      { name: "wifi.ap.ssid", type: "string", defaultValue: "FreeWiFi", description: "اسم الشبكة الوهمية" },
      { name: "wifi.ap.bssid", type: "string", defaultValue: "", description: "عنوان BSSID (تلقائي إن ترك فارغاً)" },
      { name: "wifi.ap.channel", type: "int", defaultValue: "1", description: "قناة البث" },
      { name: "wifi.ap.encryption", type: "bool", defaultValue: "true", description: "تفعيل التشفير" },
      { name: "wifi.ap.ttl", type: "int", defaultValue: "300", description: "مدة بقاء الحزمة (ثواني)" },
    ],
    commands: [
      { command: "wifi.ap on", description: "تشغيل نقطة الوصول الوهمية" },
      { command: "wifi.ap off", description: "إيقاف نقطة الوصول الوهمية" },
    ],
  },
  {
    id: "wifi.deauth",
    name: "wifi.deauth",
    description: "إلغاء المصادقة — يرسل حزم deauth لقطع اتصال العملاء",
    category: "wifi",
    icon: "WifiOff",
    running: false,
    parameters: [
      { name: "wifi.deauth.skip", type: "string", defaultValue: "", description: "عناوين MAC المستثناة" },
      { name: "wifi.deauth.silent", type: "bool", defaultValue: "false", description: "وضع صامت بدون سجل" },
      { name: "wifi.deauth.open", type: "bool", defaultValue: "true", description: "استهداف الشبكات المفتوحة" },
      { name: "wifi.deauth.acquired", type: "bool", defaultValue: "false", description: "إيقاف بعد التقاط المصافحة" },
    ],
    commands: [
      { command: "wifi.deauth", description: "إرسال deauth لهدف", example: "wifi.deauth AA:BB:CC:DD:EE:FF" },
    ],
  },
  {
    id: "wifi.assoc",
    name: "wifi.assoc",
    description: "هجوم الارتباط — يرسل حزم association لاختبار نقاط الوصول",
    category: "wifi",
    icon: "Link",
    running: false,
    parameters: [
      { name: "wifi.assoc.skip", type: "string", defaultValue: "", description: "عناوين MAC المستثناة" },
      { name: "wifi.assoc.silent", type: "bool", defaultValue: "false", description: "وضع صامت" },
      { name: "wifi.assoc.open", type: "bool", defaultValue: "false", description: "استهداف الشبكات المفتوحة فقط" },
    ],
    commands: [
      { command: "wifi.assoc", description: "إرسال association لهدف", example: "wifi.assoc all" },
    ],
  },
  {
    id: "wifi.handshakes",
    name: "wifi.handshakes",
    description: "التقاط المصافحات — يلتقط ويحفظ مصافحات WPA من الشبكات",
    category: "wifi",
    icon: "HandMetal",
    running: false,
    parameters: [
      { name: "wifi.handshakes.file", type: "filepath", defaultValue: "~/bettercap-wifi-handshakes.pcap", description: "ملف حفظ المصافحات" },
      { name: "wifi.handshakes.aggregate", type: "bool", defaultValue: "true", description: "دمج جميع المصافحات في ملف واحد" },
    ],
    commands: [
      { command: "wifi.handshakes.show", description: "عرض المصافحات الملتقطة" },
    ],
  },
  {
    id: "wifi.client.probe",
    name: "wifi.client.probe",
    description: "استقصاء العملاء — يرسل حزم probe لاكتشاف عملاء محددين",
    category: "wifi",
    icon: "UserSearch",
    running: false,
    parameters: [
      { name: "wifi.client.probe.mac", type: "string", defaultValue: "", description: "عنوان MAC للعميل المستهدف" },
      { name: "wifi.client.probe.bssid", type: "string", defaultValue: "", description: "عنوان BSSID لنقطة الوصول" },
    ],
    commands: [
      { command: "wifi.client.probe", description: "إرسال probe للعميل" },
    ],
  },
  {
    id: "wifi.bruteforce",
    name: "wifi.bruteforce",
    description: "كسر كلمات المرور — يختبر كلمات مرور WPA باستخدام قاموس",
    category: "wifi",
    icon: "KeyRound",
    running: false,
    parameters: [
      { name: "wifi.bruteforce.target", type: "string", defaultValue: "", description: "BSSID الشبكة المستهدفة" },
      { name: "wifi.bruteforce.wordlist", type: "filepath", defaultValue: "", description: "ملف قاموس كلمات المرور" },
      { name: "wifi.bruteforce.timeout", type: "int", defaultValue: "10", description: "مهلة كل محاولة (ثواني)" },
      { name: "wifi.bruteforce.stop_at_first_result", type: "bool", defaultValue: "true", description: "إيقاف عند أول نتيجة ناجحة" },
    ],
    commands: [
      { command: "wifi.bruteforce on", description: "بدء كسر كلمة المرور" },
      { command: "wifi.bruteforce off", description: "إيقاف كسر كلمة المرور" },
    ],
  },

  // ═══════════════════════════════════════════
  // 📱 Bluetooth/HID Modules
  // ═══════════════════════════════════════════
  {
    id: "ble.recon",
    name: "ble.recon",
    description: "استطلاع BLE — يكتشف أجهزة Bluetooth Low Energy القريبة",
    category: "bluetooth",
    icon: "Bluetooth",
    running: false,
    parameters: [
      { name: "ble.device", type: "string", defaultValue: "hci0", description: "واجهة البلوتوث" },
      { name: "ble.show.sort", type: "string", defaultValue: "rssi asc", description: "ترتيب العرض" },
      { name: "ble.show.limit", type: "int", defaultValue: "0", description: "حد العرض" },
    ],
    commands: [
      { command: "ble.recon on", description: "تشغيل استطلاع BLE" },
      { command: "ble.recon off", description: "إيقاف الاستطلاع" },
      { command: "ble.show", description: "عرض الأجهزة المكتشفة" },
    ],
  },
  {
    id: "ble.enum",
    name: "ble.enum",
    description: "استعراض خدمات BLE — يعرض خدمات وخصائص جهاز BLE معين",
    category: "bluetooth",
    icon: "List",
    running: false,
    parameters: [],
    commands: [
      { command: "ble.enum", description: "استعراض خدمات جهاز BLE", example: "ble.enum AA:BB:CC:DD:EE:FF" },
    ],
  },
  {
    id: "ble.write",
    name: "ble.write",
    description: "كتابة BLE — يكتب بيانات على خاصية BLE محددة",
    category: "bluetooth",
    icon: "PenTool",
    running: false,
    parameters: [],
    commands: [
      { command: "ble.write", description: "كتابة قيمة hex على خاصية", example: "ble.write AA:BB:CC:DD:EE:FF 1234-5678 0102030405" },
    ],
  },
  {
    id: "hid.recon",
    name: "hid.recon",
    description: "استطلاع HID — يكتشف أجهزة الإدخال اللاسلكية 2.4GHz (ماوس/لوحة مفاتيح)",
    category: "bluetooth",
    icon: "Mouse",
    running: false,
    parameters: [
      { name: "hid.hop.period", type: "int", defaultValue: "100", description: "فترة تغيير القناة (مللي ثانية)" },
      { name: "hid.show.sort", type: "string", defaultValue: "rssi asc", description: "ترتيب العرض" },
      { name: "hid.show.limit", type: "int", defaultValue: "0", description: "حد العرض" },
      { name: "hid.show.filter", type: "string", defaultValue: "", description: "مرشح العرض" },
    ],
    commands: [
      { command: "hid.recon on", description: "تشغيل استطلاع HID" },
      { command: "hid.recon off", description: "إيقاف الاستطلاع" },
      { command: "hid.show", description: "عرض الأجهزة المكتشفة" },
    ],
  },

  // ═══════════════════════════════════════════
  // 🎯 C2 / Automation Modules
  // ═══════════════════════════════════════════
  {
    id: "c2",
    name: "c2",
    description: "القيادة والتحكم — يتصل بخادم IRC للتحكم عن بُعد",
    category: "c2",
    icon: "Radio",
    running: false,
    parameters: [
      { name: "c2.server", type: "string", defaultValue: "", description: "عنوان خادم IRC" },
      { name: "c2.nick", type: "string", defaultValue: "bettercap", description: "الاسم المستعار IRC" },
      { name: "c2.channel", type: "string", defaultValue: "", description: "قناة IRC" },
      { name: "c2.password", type: "string", defaultValue: "", description: "كلمة مرور القناة" },
      { name: "c2.sasl.user", type: "string", defaultValue: "", description: "مستخدم SASL" },
      { name: "c2.sasl.password", type: "string", defaultValue: "", description: "كلمة مرور SASL" },
      { name: "c2.operator", type: "string", defaultValue: "", description: "مشغل IRC المسموح" },
      { name: "c2.output", type: "filepath", defaultValue: "", description: "ملف حفظ السجل" },
    ],
    commands: [
      { command: "c2 on", description: "تشغيل اتصال C2" },
      { command: "c2 off", description: "إيقاف اتصال C2" },
    ],
  },
  {
    id: "graph",
    name: "graph",
    description: "الرسم البياني — يُنشئ رسماً بيانياً تفاعلياً للشبكة",
    category: "c2",
    icon: "GitGraph",
    running: false,
    parameters: [
      { name: "graph.path", type: "filepath", defaultValue: "", description: "مسار حفظ الرسم البياني" },
      { name: "graph.gateway_color", type: "color", defaultValue: "#f00", description: "لون البوابة" },
      { name: "graph.host_color", type: "color", defaultValue: "#0f0", description: "لون الأجهزة" },
      { name: "graph.access_point_color", type: "color", defaultValue: "#00f", description: "لون نقاط الوصول" },
      { name: "graph.wifi_client_color", type: "color", defaultValue: "#ff0", description: "لون عملاء الواي فاي" },
      { name: "graph.ble_device_color", type: "color", defaultValue: "#f0f", description: "لون أجهزة BLE" },
      { name: "graph.settings", type: "string", defaultValue: "", description: "إعدادات إضافية للرسم" },
    ],
    commands: [
      { command: "graph on", description: "تشغيل توليد الرسم البياني" },
      { command: "graph off", description: "إيقاف توليد الرسم البياني" },
    ],
  },
  {
    id: "packet.proxy",
    name: "packet.proxy",
    description: "بروكسي الحزم — يعترض ويعالج حزم الشبكة على مستوى النواة",
    category: "c2",
    icon: "Box",
    running: false,
    parameters: [
      { name: "packet.proxy.queue.num", type: "int", defaultValue: "0", description: "رقم طابور NFQUEUE" },
      { name: "packet.proxy.chain", type: "enum", defaultValue: "OUTPUT", description: "سلسلة iptables", options: ["INPUT", "OUTPUT", "FORWARD"] },
      { name: "packet.proxy.rule", type: "string", defaultValue: "", description: "قاعدة iptables إضافية" },
      { name: "packet.proxy.plugin", type: "filepath", defaultValue: "", description: "ملف إضافة Go" },
    ],
    commands: [
      { command: "packet.proxy on", description: "تشغيل بروكسي الحزم" },
      { command: "packet.proxy off", description: "إيقاف بروكسي الحزم" },
    ],
  },
  {
    id: "caplets",
    name: "caplets",
    description: "إدارة الكابلتس — تحميل وتشغيل سكربتات Bettercap المحفوظة",
    category: "c2",
    icon: "FileCode",
    running: false,
    parameters: [],
    commands: [
      { command: "caplets.show", description: "عرض الكابلتس المتوفرة" },
      { command: "caplets.paths", description: "عرض مسارات البحث" },
      { command: "caplets.update", description: "تحديث الكابلتس من المستودع" },
      { command: "include", description: "تحميل وتنفيذ كابلت", example: "include http-ui" },
    ],
  },
];

/** تحويل فئة الوحدة إلى نص عربي */
export function getCategoryLabel(category: string): string {
  const labels: Record<string, string> = {
    core: "أساسية",
    network: "شبكة",
    spoofing: "انتحال",
    http: "HTTP/HTTPS",
    wifi: "واي فاي",
    bluetooth: "بلوتوث",
    c2: "C2 وأتمتة",
  };
  return labels[category] || category;
}

/** تحويل فئة الوحدة إلى لون */
export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    core: "bg-zinc-500",
    network: "bg-blue-500",
    spoofing: "bg-red-500",
    http: "bg-emerald-500",
    wifi: "bg-purple-500",
    bluetooth: "bg-cyan-500",
    c2: "bg-amber-500",
  };
  return colors[category] || "bg-zinc-500";
}
