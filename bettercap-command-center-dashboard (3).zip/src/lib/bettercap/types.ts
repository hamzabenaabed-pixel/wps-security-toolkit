/** أنواع TypeScript لـ Bettercap */

export type ParameterType = "string" | "bool" | "int" | "float" | "enum" | "filepath" | "color";

export type ModuleCategory = "core" | "network" | "spoofing" | "http" | "wifi" | "bluetooth" | "c2";

export interface ModuleParameter {
  name: string;
  type: ParameterType;
  defaultValue: string;
  description: string;
  options?: string[]; // للـ enum
}

export interface ModuleCommand {
  command: string;
  description: string;
  example?: string;
}

export interface BettercapModule {
  id: string;
  name: string;
  description: string;
  category: ModuleCategory;
  icon: string;
  running: boolean;
  parameters: ModuleParameter[];
  commands: ModuleCommand[];
}

export interface NetworkHost {
  ip: string;
  mac: string;
  hostname: string;
  vendor: string;
  os: string;
  ports: number[];
  firstSeen: string;
  lastSeen: string;
  meta?: Record<string, string>;
}

export interface WiFiAccessPoint {
  ssid: string;
  bssid: string;
  channel: number;
  rssi: number;
  encryption: string;
  wps: boolean;
  clientsCount: number;
  firstSeen: string;
  lastSeen: string;
  handshake: boolean;
}

export interface WiFiClient {
  mac: string;
  bssid: string;
  ssid: string;
  rssi: number;
  sent: number;
  received: number;
  firstSeen: string;
  lastSeen: string;
}

export interface BLEDevice {
  mac: string;
  name: string;
  vendor: string;
  rssi: number;
  connectable: boolean;
  services: string[];
  firstSeen: string;
  lastSeen: string;
}

export interface BettercapEvent {
  id: string;
  type: string;
  time: string;
  data: Record<string, unknown>;
  tag?: string;
}

export interface SessionState {
  interface: string;
  gateway: NetworkHost;
  hosts: NetworkHost[];
  modules: BettercapModule[];
  events: BettercapEvent[];
  wifi?: {
    aps: WiFiAccessPoint[];
    clients: WiFiClient[];
  };
  ble?: {
    devices: BLEDevice[];
  };
}

export interface TrafficDataPoint {
  time: string;
  sent: number;
  received: number;
}

export interface CapletFile {
  name: string;
  description: string;
  content: string;
  builtIn: boolean;
}
