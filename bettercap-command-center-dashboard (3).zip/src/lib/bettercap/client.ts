/** عميل Bettercap API - للاتصال الحقيقي */

export interface BettercapSession {
  interface: string;
  gateway?: {
    ip: string;
    mac: string;
    hostname: string;
    vendor: string;
  };
  lan?: {
    hosts: Array<{
      ip: string;
      mac: string;
      hostname: string;
      vendor: string;
      first_seen: string;
      last_seen: string;
      meta?: Record<string, string>;
    }>;
  };
  wifi?: {
    aps: Array<{
      ssid: string;
      bssid: string;
      channel: number;
      rssi: number;
      encryption: string;
      wps: boolean;
      clients: Array<{
        mac: string;
        rssi: number;
      }>;
    }>;
  };
  ble?: {
    devices: Array<{
      mac: string;
      name: string;
      vendor: string;
      rssi: number;
    }>;
  };
  modules: Array<{
    name: string;
    running: boolean;
  }>;
}

class BettercapClient {
  private baseUrl: string;
  private username: string;
  private password: string;

  constructor() {
    this.baseUrl = "http://127.0.0.1:8081";
    this.username = "user";
    this.password = "pass";
  }

  private getAuthHeader(): string {
    const credentials = Buffer.from(`${this.username}:${this.password}`).toString("base64");
    return `Basic ${credentials}`;
  }

  async getSession(): Promise<BettercapSession | null> {
    try {
      const response = await fetch(`${this.baseUrl}/api/session`, {
        headers: {
          Authorization: this.getAuthHeader(),
        },
        cache: "no-store",
      });

      if (!response.ok) {
        console.error("Bettercap API error:", response.status);
        return null;
      }

      return await response.json();
    } catch (error) {
      console.error("Failed to connect to Bettercap:", error);
      return null;
    }
  }

  async runCommand(command: string): Promise<string | null> {
    try {
      const response = await fetch(`${this.baseUrl}/api/session`, {
        method: "POST",
        headers: {
          Authorization: this.getAuthHeader(),
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cmd: command }),
      });

      if (!response.ok) {
        return null;
      }

      const data = await response.json();
      return data.output || "";
    } catch (error) {
      console.error("Command failed:", error);
      return null;
    }
  }

  async getEvents(): Promise<Array<{ tag: string; time: string; data: unknown }>> {
    try {
      const response = await fetch(`${this.baseUrl}/api/events`, {
        headers: {
          Authorization: this.getAuthHeader(),
        },
        cache: "no-store",
      });

      if (!response.ok) return [];
      return await response.json();
    } catch {
      return [];
    }
  }
}

export const bettercapClient = new BettercapClient();
