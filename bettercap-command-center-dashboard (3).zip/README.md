# 🎯 مركز قيادة Bettercap (BCC)

<div dir="rtl">

لوحة تحكم عربية احترافية لإدارة Bettercap — للتشغيل على Kali NetHunter (Android Root).

---

## 📱 التثبيت على NetHunter (كل شيء على الهاتف)

### الخطوة ١: تثبيت المتطلبات

افتح **NetHunter Terminal** ونفّذ:

```bash
apt update
apt install -y bettercap nodejs npm git
```

### الخطوة ٢: تحميل التطبيق

```bash
cd ~
git clone https://github.com/user/bettercap-command-center.git
cd bettercap-command-center
npm install
```

### الخطوة ٣: التشغيل

**افتح تبويبين في Terminal:**

**التبويب ١ - تشغيل Bettercap:**
```bash
bettercap -caplet http-ui
```

**التبويب ٢ - تشغيل التطبيق:**
```bash
cd ~/bettercap-command-center
npm run dev
```

### الخطوة ٤: الاستخدام

افتح متصفح الهاتف (Chrome/Firefox):
```
http://localhost:3000
```

---

## ⚡ أوامر سريعة

```bash
# تشغيل Bettercap فقط (بدون واجهة)
sudo bettercap

# تشغيل مع API للتطبيق
sudo bettercap -caplet http-ui

# تشغيل مع واجهة HTTPS
sudo bettercap -caplet https-ui
```

---

## 🔧 إعدادات الاتصال

| الإعداد | القيمة |
|---------|--------|
| رابط API | `http://127.0.0.1:8081` |
| اسم المستخدم | `user` |
| كلمة المرور | `pass` |

---

## 📁 الملفات المهمة

```
~/bettercap-command-center/
├── src/app/          # الصفحات
├── package.json      # الاعتماديات
└── README.md         # هذا الملف
```

---

## 🛠️ حل المشاكل

### مشكلة: "could not detect gateway"
```bash
ip route add default via 192.168.1.1 dev wlan0
```
(غيّر 192.168.1.1 إلى IP الراوتر عندك)

### مشكلة: التطبيق لا يعمل
```bash
# تأكد من تثبيت Node.js
node --version

# أعد تثبيت الاعتماديات
rm -rf node_modules
npm install
```

### مشكلة: لا يتصل بـ Bettercap
- تأكد أن Bettercap يعمل في Terminal آخر
- تأكد من الأمر: `bettercap -caplet http-ui`

---

## ⚠️ تحذير قانوني

**للاستخدام الأخلاقي فقط!**

استخدم هذه الأداة فقط على شبكات تملكها أو لديك إذن صريح لاختبارها.

</div>
